plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.khazanehdar"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.khazanehdar.sara"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-sara"
    }

    // کلید ثابت: هر نسخه‌ی جدید روی قبلی نصب می‌شه و داده‌ها می‌مونن
    signingConfigs {
        getByName("debug") {
            storeFile = file("khazane.keystore")
            storePassword = "khazane123"
            keyAlias = "khazane"
            keyPassword = "khazane123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}
