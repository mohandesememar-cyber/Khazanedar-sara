"use strict";
/* ===== بازی و ناظر نرم‌افزار (سارا) ===== */
var G=(function(){
  var d={coins:0,outfit:null,owned:{},claimed:{},badgeCoin:{},lvlCoin:1,games:{date:"",n:0,coins:0},base:null,lessonsSaved:[],lessonSeen:[],chartOff:{},name:"سارا"};
  try{var r=JSON.parse((window.Android&&window.Android.gstate&&window.Android.gstate())||"{}");for(var k in r)d[k]=r[k]}catch(e){}
  d.name="سارا";
  d.outfit=Object.assign({},DEFAULT_OUTFIT,d.outfit||{});
  return d;
})();
function gSave(){try{window.Android.setGstate(JSON.stringify(G))}catch(e){}}
function dayKey(){var t=todayJ();return t[0]+"-"+t[1]+"-"+t[2]}
function weekKey(){var t=todayJ();return t[0]+"-w"+Math.floor((t[1]*31+t[2])/7)}
function gLevel(){var g=getGame();return g?g.level:1}
function applyTheme(n){
  var t=THEMES[n]||THEMES.night;
  document.documentElement.style.setProperty("--bg1",t.b1);document.documentElement.style.setProperty("--bg2",t.b2);
}
applyTheme(G.outfit.theme);

/* ---------- ابزار ---------- */
function girl(mood,view){return '<div class="girl">'+avatar(G.outfit,mood||"happy",view||"bust")+'</div>'}
function dragon(mood){return girl(mood==="sad"?"sad":mood==="wow"?"wow":"happy","bust")} /* سازگاری با کدهای قبلی */
function R(a){return a[Math.floor(Math.random()*a.length)]}
function itemOf(slot,id){var l=CAT[slot];for(var i=0;i<l.length;i++)if(l[i].id===id)return l[i];return null}
function isOwned(slot,it){
  if(!it)return false;
  if(gLevel()<it.lvl)return false;
  return it.price===0||!!G.owned[slot+":"+it.id];
}
function coinsHtml(){return '<span class="coin">🪙 '+faN(G.coins)+'</span>'}

/* ---------- پیام‌های مثبت و ناظر ---------- */
var POS=[
 "امروز قراره یه روز عالی باشه؛ حتی اگه صبح قهوه‌ت سرد شده باشه ☕",
 "پولی که ثبت می‌کنی، پولیه که کنترلش دست خودته 💪",
 "هر ریالی که می‌شناسی، یه قدم به آزادی مالی نزدیک‌تری 🚀",
 "تو بهتر از اون چیزی هستی که فکر می‌کنی؛ حسابات هم همینطور! ✨",
 "بزرگ‌ترین ثروت‌ها با ثبت‌های کوچیک شروع شدن 🌱",
 "امروز یه کار کوچیک کن که فردای خودت ازت ممنون باشه 🙏",
 "پول مثل ماهی‌ه؛ تا نشناسی‌اش، از دستت می‌لغزه 🐟",
 "لبخند بزن! حتی تورم هم نمی‌تونه ارزش لبخندت رو کم کنه 😄",
 "هر مشتری راضی، یه فاکتور خوشگله 🧾",
 "تو سخت‌کوشی؛ فقط یادت نره به خودت هم یه قهوه مهمون کنی 😉",
 "امروز حواست به خرج‌های ریز باشه؛ قطره قطره دریا می‌شه 💧",
 "خدا رو شکر که تو رو داری که پولت رو جدی می‌گیری 🌟",
 "اگه امروز دلت می‌خواد دنیا رو عوض کنی، از حساب‌وکتاب خودت شروع کن 🌍",
 "هر تراکنشی که ثبت می‌کنی، به اژدهای پول می‌گی «تو دیگه ولم نمی‌کنی!» 🐉",
 "درآمدت بالا می‌ره؛ فقط ادامه بده، من ناظرتم و دارم می‌بینم 👀",
 "امروز به یه هدف مالی فکر کن و یه قدم کوچیک برای رسیدن بهش بردار 🎯",
 "آرامش یعنی بدونی پولت کجاست 🧘",
 "تو داری از خیلی‌ها جلوتری؛ چون حسابت رو داری 👏",
 "گاهی بهترین سرمایه‌گذاری، یه خواب خوب و یه صبحانه‌ی کامله 🍳",
 "پولدار شدن ماراتنه، نه دو سرعت؛ آروم و پیوسته 🏃",
 "امروز یه چیز خوب برای خودت و یه چیز خوب برای حسابت انجام بده 🎁",
 "مشتری‌ها خوب می‌پردازن، چون کارت خوبه 💎",
 "حواست باشه: هر «نه» به خرج بیهوده، یه «آره» به آرزوهاته 🌈",
 "امروز حال دلت خوب باشه؛ بقیه‌ش با من! 💖",
 "همین که اینجایی یعنی تصمیم گرفتی کنترل رو بگیری؛ این خودش برده 🏆"
];
if(window.CONTENT&&CONTENT.positive)POS=POS.concat(CONTENT.positive);
function fillTpl(t){
  var g=getGame()||{};
  return String(t).replace(/\{n\}/g,faN((S.pend||[]).length)).replace(/\{name\}/g,G.name).replace(/\{level\}/g,faN(g.level||1)).replace(/\{job\}/g,JOBS[(g.level||1)-1]);
}
function nagMsg(){
  var g=getGame()||{},p=(S.pend||[]).length,list=[];
  if(p>0)list.push({t:"هی! "+faN(p)+" تا تراکنش منتظر توضیحه. دلم می‌خواد بدونم این پول‌ها کجا رفتن 🕵️‍♀️",l:"بریم ببینیم",f:function(){openAllPending()}});
  var due=(S.debts||[]).filter(function(d){return !d.paid&&daysFrom(d.due)<0});
  if(due.length)list.push({t:"«"+esc(due[0].name)+"» هنوز پولت رو نداده! بزن بهش پیام بده، من پشتتم 😈",l:"طلب‌ها",f:function(){S.tab="debts";S.dtab="debt";render()}});
  var hist=[];try{hist=JSON.parse(window.Android.invHist())}catch(e){}
  if(!hist.length||Date.now()-hist[0].ts>7*864e5)list.push({t:"یه فاکتور نزدی این هفته! مشتریا که خودشون به یاد پرداخت نمی‌افتن 🧾",l:"بریم فاکتور",f:function(){S.tab="invoice";render()}});
  if(g.streak===0)list.push({t:"امروز هنوز چیزی ثبت نکردی. زنجیره‌ی روزهات داره خاموش می‌شه 🔥",l:"تراکنش‌ها",f:function(){S.tab="home";render()}});
  if(g.next&&g.level<10)list.push({t:"فقط "+faN(g.next-g.xp)+" امتیاز تا سطح بعد مونده؛ یه لباس جدید منتظرمه! 👗",l:"ببین چی باز می‌شه",f:function(){openGame("room")}});
  list.push({t:"من ناظر این نرم‌افزارم و دارم همه‌جا سرک می‌کشم 👀 حسابات رو مرتب کن تا خوشحالم کنی!",l:"کمد من",f:function(){openGame("wardrobe")}});
  list.push({t:"حوصله‌ت سر رفته؟ یه دست سنگ‌کاغذ‌قیچی بریم؟ حریفتم! ✌️",l:"بازی",f:function(){openGame("games")}});
  list.push({t:"ماموریت‌های امروزم رو دیدی؟ سکه‌ی خوبی داره 🪙",l:"ماموریت‌ها",f:function(){openGame("missions")}});
  if(window.CONTENT&&CONTENT.supervisor&&CONTENT.supervisor.peek){
    list.push({t:fillTpl(R(CONTENT.supervisor.peek)),l:"باشه، الان 😉",f:function(){S.tab="home";render()}});
    list.push({t:fillTpl(R(CONTENT.supervisor.peek)),l:"ماموریت‌ها",f:function(){openGame("missions")}});
  }
  return R(list);
}
var _peekT=0,_peekHide=null;
function peek(force){
  var pk=document.getElementById("peek");if(!pk)return;
  if(!force&&(Date.now()-_peekT<80000||document.getElementById("sheetBg").classList.contains("on")||document.getElementById("gscr")))return;
  _peekT=Date.now();
  var m=nagMsg(),side=Math.random()<.5?"l":"r";
  pk.className="peek "+side;
  pk.innerHTML='<div class="pa">'+girl(R(["happy","wink","wow"]),"bust")+'</div><div class="pb"><div>'+m.t+'</div><div class="row" style="margin-top:6px;gap:6px"><button class="btn sm gold" id="pkGo">'+m.l+'</button><button class="btn sm ghost" id="pkX">بعداً</button></div></div>';
  pk.classList.add("on");
  document.getElementById("pkGo").onclick=function(){pk.classList.remove("on");m.f()};
  document.getElementById("pkX").onclick=function(){pk.classList.remove("on")};
  clearTimeout(_peekHide);_peekHide=setTimeout(function(){pk.classList.remove("on")},11000);
  pk.style.transform="";pk.style.opacity="";pk.style.transition="";
  if(!pk._sw){
    pk._sw=1;var x0=null,dx=0;
    pk.addEventListener("touchstart",function(e){x0=e.touches[0].clientX;dx=0;pk.style.transition="none"},{passive:true});
    pk.addEventListener("touchmove",function(e){if(x0==null)return;dx=e.touches[0].clientX-x0;pk.style.transform="translateX("+dx+"px)";pk.style.opacity=String(Math.max(.2,1-Math.abs(dx)/260))},{passive:true});
    pk.addEventListener("touchend",function(){
      if(x0==null)return;x0=null;pk.style.transition="transform .2s,opacity .2s";
      if(Math.abs(dx)>60){pk.style.transform="translateX("+(dx>0?420:-420)+"px)";pk.style.opacity="0";setTimeout(function(){pk.classList.remove("on");pk.style.transform="";pk.style.opacity="";pk.style.transition=""},210)}
      else{pk.style.transform="";pk.style.opacity=""}
    });
  }
}
function speak(){peek(true)}
function renderPosBar(){
  var el=document.getElementById("posBar");if(!el)return;
  el.innerHTML='<div class="pbav">'+girl("happy","bust")+'</div><div class="pbt">'+R(POS)+'</div>';
  el.onclick=speak;
}

/* ---------- جایزه‌ها ---------- */
function ensureBase(){
  var g=getGame();if(!g)return;
  if(!G.base||G.base.day!==dayKey()){
    G.base={day:dayKey(),recorded:g.recorded,invoices:g.invoices||0,paid:(g.debtsPaid||0)+(g.instPaid||0)};
    G.games.date=dayKey();G.games.n=0;G.games.coins=0;gSave();
  }
}
function grantAuto(){
  var g=getGame();if(!g)return;
  var ch=false;
  if(g.level>G.lvlCoin){G.coins+=25*(g.level-G.lvlCoin);G.lvlCoin=g.level;ch=true}
  (g.badges||[]).forEach(function(b){if(b.ok&&!G.badgeCoin[b.id]){G.badgeCoin[b.id]=1;G.coins+=20;ch=true}});
  if(ch)gSave();
}
function missions(){
  var g=getGame()||{};ensureBase();
  var b=G.base||{recorded:0,invoices:0,paid:0};
  var dr=(g.recorded||0)-b.recorded,di=(g.invoices||0)-b.invoices,dp=((g.debtsPaid||0)+(g.instPaid||0))-b.paid;
  var dk=dayKey(),wk=weekKey();
  return [
    {id:"d_rec3:"+dk,t:"امروز ۳ تراکنش رو تأیید کن",cur:Math.max(0,dr),target:3,coins:10},
    {id:"d_inv:"+dk,t:"یه فاکتور بساز",cur:Math.max(0,di),target:1,coins:15},
    {id:"d_clear:"+dk,t:"همه‌ی تراکنش‌های منتظر رو تموم کن",cur:(g.pending===0&&(g.recorded||0)>0)?1:0,target:1,coins:12},
    {id:"d_paid:"+dk,t:"یه طلب وصول کن یا یه قسط بپرداز",cur:Math.max(0,dp),target:1,coins:15},
    {id:"d_game:"+dk,t:"یه دست با سارا بازی کن",cur:G.games.n,target:1,coins:5},
    {id:"w_streak:"+wk,t:"هفته‌ای: ۵ روز پشت‌سرهم ثبت کن",cur:g.streak||0,target:5,coins:50,weekly:1},
    {id:"w_income:"+wk,t:"هفته‌ای: درآمدت از ماه قبل بیشتر بشه",cur:g.growing?1:0,target:1,coins:60,weekly:1}
  ];
}
function gameDone(win,big){
  ensureBase();
  G.games.n++;
  var c=win?(big?15:6):(big?3:1);
  var room=Math.max(0,40-G.games.coins);c=Math.min(c,room);
  G.games.coins+=c;G.coins+=c;gSave();
  return c;
}

/* ---------- صفحه‌ی بازی ---------- */
var GTAB="room",WCAT="sets";
function openGame(tab){
  GTAB=tab||GTAB;
  var el=document.getElementById("gscr");
  if(!el){el=document.createElement("div");el.id="gscr";document.body.appendChild(el)}
  renderGame();
}
function closeGame(){var el=document.getElementById("gscr");if(el)el.remove();S.gameT=0;render()}
function renderGame(){
  var el=document.getElementById("gscr");if(!el)return;
  S.gameT=0;grantAuto();
  var g=getGame()||{level:1,xp:0,next:60,base:0,prog:0};
  var tabs=[["room","🏠","اتاق"],["wardrobe","👗","کمد"],["missions","🎯","ماموریت"],["games","🎮","بازی"],["pet","💩","پت"],["badges","🏅","نشان‌ها"]];
  var h='<div class="gh"><button class="btn sm ghost" id="gx">✕ بستن</button><b>'+esc(G.name)+' • سطح '+faN(g.level)+'</b>'+coinsHtml()+'</div><div class="gtabs">'+
    tabs.map(function(t){return '<button data-gt="'+t[0]+'" class="'+(GTAB===t[0]?"on":"")+'"><span>'+t[1]+'</span>'+t[2]+'</button>'}).join("")+'</div><div class="gb" id="gb"></div>';
  el.innerHTML=h;
  document.getElementById("gx").onclick=closeGame;
  el.querySelectorAll("[data-gt]").forEach(function(b){b.onclick=function(){GTAB=b.dataset.gt;renderGame()}});
  var body=document.getElementById("gb");
  ({room:gRoom,wardrobe:gWardrobe,missions:gMissions,games:gGames,pet:gPet,badges:gBadges})[GTAB](body,g);
}
function gRoom(el,g){
  var lv=g.level,job=JOBS[lv-1],house=HOUSES[lv-1];
  var nextUnlock=[];
  Object.keys(CAT).forEach(function(s){CAT[s].forEach(function(i){if(i.lvl===lv+1)nextUnlock.push(i.n)})});
  SETS.forEach(function(s){if(s.lvl===lv+1)nextUnlock.push("ست "+s.n+" و تم اپ")});
  var gif=R(["امروز چه خبره؟ 😏","من آماده‌ام؛ تو چی؟","دلم برای ثبت تراکنش تنگ شده 🥺","هیچ حسابی از زیر دست من در نمی‌ره 😎"]);
  el.innerHTML='<div class="room">'+sceneSVG(lv)+'<div class="rav">'+avatar(G.outfit,"happy","full")+'</div><div class="rbub" id="rbub">'+gif+'</div></div>'+
    '<div class="card" style="text-align:center"><b>«سارا سکه می‌خواد 😂»</b></div>'+
    '<div class="card"><div class="row sp"><b>'+esc(job)+'</b><span class="badge b-ok">سطح '+faN(lv)+'</span></div><div class="mut">🏠 '+esc(house)+'</div>'+
    '<div class="xpbar"><i style="width:'+Math.max(4,g.prog||0)+'%"></i></div><div class="mut">'+faN(g.xp||0)+' امتیاز'+(lv<10?' • '+faN((g.next||0)-(g.xp||0))+' امتیاز تا سطح بعد':' • بالاترین سطح!')+'</div>'+
    (nextUnlock.length?'<div class="mut" style="margin-top:6px">🎁 با رسیدن به سطح بعد باز می‌شه: <b>'+nextUnlock.join("، ")+'</b></div>':'')+'</div>'+
    '<div class="card"><b>چطوری رشد کنم؟</b><div class="mut" style="line-height:1.9;margin-top:4px">• هر تراکنشی که توضیحش رو بدی: ۵ امتیاز<br>• هر فاکتور: ۲۵ • هر طلب وصول‌شده: ۴۰ • هر قسط: ۳۰<br>• ماهی که درآمدت از خرجت بیشتر شد: ۱۰۰ • رشد درآمد نسبت به ماه قبل: امتیاز ویژه<br>• هر روز پشت‌سرهم ثبت: ۸ امتیاز</div></div>'+
    '<button class="btn gold full" id="rPeek">👋 سارا رو صدا بزن</button>';
  document.getElementById("rPeek").onclick=function(){closeGameForPeek()};
  document.getElementById("rbub").onclick=function(){this.textContent=nagMsg().t};
}
function closeGameForPeek(){var el=document.getElementById("gscr");if(el)el.remove();render();setTimeout(function(){peek(true)},300)}

function gWardrobe(el,g){
  var o=G.outfit,lv=g.level;
  var cats=[["sets","ست‌ها"],["top","بالاتنه"],["bottom","پایین‌تنه"],["one","یک‌تکه"],["shoes","کفش"],["hair","مو"],["acc","اکسسوری"],["col","رنگ‌ها"],["theme","تم اپ"]];
  var h='<div class="wprev">'+avatar(o,"happy","full")+'</div><div class="wcats">'+cats.map(function(c){return '<button data-wc="'+c[0]+'" class="'+(WCAT===c[0]?"on":"")+'">'+c[1]+'</button>'}).join("")+'</div><div class="witems" id="witems"></div>';
  el.innerHTML=h;
  el.querySelectorAll("[data-wc]").forEach(function(b){b.onclick=function(){WCAT=b.dataset.wc;gWardrobe(el,g)}});
  var w=document.getElementById("witems"),x='';
  function chip(slot,it,active){
    var own=isOwned(slot,it),lock=lv<it.lvl;
    var cls="wi"+(active?" on":"")+(lock?" lock":"");
    var sub=lock?"🔒 سطح "+faN(it.lvl):(own?"":"🪙 "+faN(it.price));
    return '<button class="'+cls+'" data-slot="'+slot+'" data-id="'+it.id+'"><b>'+esc(it.n)+'</b><small>'+sub+'</small></button>';
  }
  if(WCAT==="sets"){
    SETS.forEach(function(s){
      var lock=lv<s.lvl;
      var need=[];["top","bottom","one","shoes"].forEach(function(sl){var id=s.o[sl];if(id){var it=itemOf(sl,id);if(!isOwned(sl,it))need.push({sl:sl,it:it})}});
      (s.o.acc||[]).forEach(function(id){var it=itemOf("acc",id);if(!isOwned("acc",it))need.push({sl:"acc",it:it})});
      var cost=need.reduce(function(a,n){return a+(n.it.lvl<=lv?n.it.price:0)},0);
      x+='<div class="wset'+(lock?" lock":"")+'"><div class="row sp"><b>'+s.e+' ست '+esc(s.n)+'</b><span class="mut">'+(lock?"🔒 سطح "+faN(s.lvl):"تم اپ: "+THEMES[s.theme].n)+'</span></div>'+
        '<button class="btn sm '+(need.length?"":"gold")+'" data-set="'+s.id+'" '+(lock?"disabled":"")+'>'+(need.length?"خرید و پوشیدن ("+faN(cost)+" 🪙)":"بپوش")+'</button></div>';
    });
  }else if(WCAT==="col"){
    function sw(arr,key){return '<div class="swr">'+arr.map(function(c){return '<button class="sw'+(o[key]===c?" on":"")+'" style="background:'+c+'" data-key="'+key+'" data-c="'+c+'"></button>'}).join("")+'</div>'}
    x='<label>رنگ بالاتنه / لباس</label>'+sw(CLOTHC,"topc")+'<label>رنگ پایین‌تنه</label>'+sw(CLOTHC,"botc")+'<label>رنگ مو</label>'+sw(HAIRC,"hairc")+'<label>رنگ پوست</label>'+sw(SKINS,"skin")+'<label>رنگ چشم</label>'+sw(["#3d7a4a","#2b6cb0","#6b4423","#2d3142","#7a4bd6"],"eye");
  }else if(WCAT==="theme"){
    Object.keys(THEMES).forEach(function(k){
      var set=SETS.filter(function(s){return s.theme===k})[0],lock=set&&lv<set.lvl;
      x+='<button class="wi'+(o.theme===k?" on":"")+(lock?" lock":"")+'" data-theme="'+k+'"><b>'+THEMES[k].n+'</b><small>'+(lock?"🔒 سطح "+faN(set.lvl):"")+'</small></button>';
    });
  }else if(WCAT==="acc"){
    CAT.acc.forEach(function(it){x+=chip("acc",it,(o.acc||[]).indexOf(it.id)>=0)});
  }else if(WCAT==="one"){
    x+='<button class="wi'+(!o.one?" on":"")+'" data-slot="one" data-id=""><b>بدون</b></button>';
    CAT.one.forEach(function(it){x+=chip("one",it,o.one===it.id)});
  }else{
    CAT[WCAT].forEach(function(it){x+=chip(WCAT,it,o[WCAT]===it.id)});
  }
  w.innerHTML=x;
  w.querySelectorAll("[data-slot]").forEach(function(b){b.onclick=function(){
    var slot=b.dataset.slot,id=b.dataset.id;
    if(slot==="one"&&!id){G.outfit.one="";gSave();gWardrobe(el,g);return}
    var it=itemOf(slot,id);
    if(lv<it.lvl){toast("این لباس از سطح "+faN(it.lvl)+" باز می‌شه 🔒");return}
    if(!isOwned(slot,it)){
      if(G.coins<it.price){toast("سکه‌ات کمه! با ماموریت و بازی سکه جمع کن 🪙");return}
      G.coins-=it.price;G.owned[slot+":"+id]=1;toast("خریدی! "+it.n+" مال توئه 🎉");
    }
    if(slot==="acc"){var a=G.outfit.acc||[],i=a.indexOf(id);if(i>=0)a.splice(i,1);else a.push(id);G.outfit.acc=a}
    else{G.outfit[slot]=id;if(slot==="one"&&id)G.outfit.top=G.outfit.top;}
    gSave();renderGame();
  }});
  w.querySelectorAll("[data-key]").forEach(function(b){b.onclick=function(){G.outfit[b.dataset.key]=b.dataset.c;gSave();gWardrobe(el,g)}});
  w.querySelectorAll("[data-theme]").forEach(function(b){b.onclick=function(){
    var k=b.dataset.theme,set=SETS.filter(function(s){return s.theme===k})[0];
    if(set&&lv<set.lvl){toast("این تم از سطح "+faN(set.lvl)+" باز می‌شه 🔒");return}
    G.outfit.theme=k;applyTheme(k);gSave();gWardrobe(el,g)}});
  w.querySelectorAll("[data-set]").forEach(function(b){b.onclick=function(){
    var s=SETS.filter(function(x){return x.id===b.dataset.set})[0];
    var cost=0,buy=[];
    ["top","bottom","one","shoes"].forEach(function(sl){var id=s.o[sl];if(id){var it=itemOf(sl,id);if(!isOwned(sl,it)){cost+=it.price;buy.push([sl,id])}}});
    (s.o.acc||[]).forEach(function(id){var it=itemOf("acc",id);if(!isOwned("acc",it)){cost+=it.price;buy.push(["acc",id])}});
    if(G.coins<cost){toast("برای این ست "+faN(cost)+" سکه لازمه 🪙");return}
    G.coins-=cost;buy.forEach(function(p){G.owned[p[0]+":"+p[1]]=1});
    var oo=G.outfit;
    ["top","bottom","one","shoes"].forEach(function(sl){if(s.o[sl]!==undefined)oo[sl]=s.o[sl]});
    if(!s.o.one)oo.one="";
    oo.acc=(s.o.acc||[]).slice();if(oo.acc.indexOf("glasses")<0&&s.id==="casual")oo.acc.push("glasses");
    oo.theme=s.theme;applyTheme(s.theme);gSave();toast("ست "+s.n+" پوشیده شد و تم اپ عوض شد ✨");renderGame();
  }});
}
function gMissions(el){
  var ms=missions(),h='<div class="mut" style="margin-bottom:8px">با ماموریت‌ها سکه می‌گیری و با سکه لباس‌های ویژه می‌خری 🪙</div>';
  ms.forEach(function(m){
    var done=m.cur>=m.target,cl=!!G.claimed[m.id];
    h+='<div class="card"><div class="row sp"><b>'+(m.weekly?"📅 ":"☀️ ")+m.t+'</b><span class="coin">+'+faN(m.coins)+' 🪙</span></div><div class="xpbar"><i style="width:'+Math.min(100,Math.max(done?100:4,m.cur*100/m.target))+'%"></i></div><div class="row sp"><span class="mut">'+faN(Math.min(m.cur,m.target))+' از '+faN(m.target)+'</span>'+
      (cl?'<span class="badge b-ok">گرفتی ✅</span>':'<button class="btn sm '+(done?"gold":"ghost")+'" data-claim="'+m.id+'" '+(done?"":"disabled")+'>'+(done?"بگیر!":"هنوز نه")+'</button>')+'</div></div>';
  });
  el.innerHTML=h;
  el.querySelectorAll("[data-claim]").forEach(function(b){b.onclick=function(){
    var m=ms.filter(function(x){return x.id===b.dataset.claim})[0];
    if(!m||G.claimed[m.id])return;G.claimed[m.id]=1;G.coins+=m.coins;gSave();confetti();toast("+"+faN(m.coins)+" سکه! 🪙");renderGame();
  }});
}
function gBadges(el,g){
  var ok=(g.badges||[]).filter(function(b){return b.ok}).length;
  var h='<div class="mut">هر نشان جدید ۲۰ سکه جایزه داره. '+faN(ok)+' از '+faN((g.badges||[]).length)+' نشان رو گرفتی.</div><div class="bgrid">';
  (g.badges||[]).forEach(function(b){
    h+='<div class="bdg'+(b.ok?"":" lock")+'"><b>'+b.icon+' '+esc(b.title)+'</b>'+esc(b.desc)+(b.ok?'<div class="in">گرفتی ✅</div>':'<div class="mut">'+faN(b.cur)+' / '+faN(b.target)+'</div>')+'</div>';
  });
  el.innerHTML=h+'</div>';
}

/* ---------- بازی‌ها ---------- */
function gGames(el,g){
  var capLeft=Math.max(0,40-G.games.coins);
  el.innerHTML='<div class="hero">'+girl("wink","bust")+'<div class="bubble">با من بازی کن! هر روز تا ۴۰ سکه از بازی می‌تونی بگیری؛ ولی حواست باشه حسابات رو هم بکنی 😜</div></div>'+
    '<div class="card"><div class="row sp"><b>✌️ سنگ‌کاغذ‌قیچی</b><button class="btn sm gold" data-g="rps">بازی</button></div><div class="mut">۵ دست؛ هر کی بیشتر ببره برنده‌ست</div></div>'+
    '<div class="card"><div class="row sp"><b>✋ گل یا پوچ</b><button class="btn sm gold" data-g="gp">بازی</button></div><div class="mut">حدس بزن توی دستم سنگ هست یا نه؛ بعدش نوبت منه!</div></div>'+
    '<div class="card"><div class="row sp"><b>🎲 منچ</b><button class="btn sm gold" data-g="ludo">بازی</button></div><div class="mut">۴ مهره، تاس، ضربه‌زدن به مهره‌ی حریف؛ اولین کسی که هر ۴ مهره‌اش رو برسونه می‌بره (۶ بیاری دوباره می‌اندازی)</div></div>'+
    '<div class="card"><div class="row sp"><b>🐍 مار و پله</b><button class="btn sm gold" data-g="snake">بازی</button></div><div class="mut">تاس بنداز، از پله بالا برو و از مار فرار کن!</div></div>'+
    '<div class="card"><div class="row sp"><b>🎲 تخته‌نرد</b><button class="btn sm gold" data-g="bg">بازی</button></div><div class="mut">تخته‌نرد کامل با ضربه، میله و بیرون بردن مهره</div></div>'+
    '<div class="card"><div class="row sp"><b>♠️ حکم</b><button class="btn sm gold" data-g="hokm">بازی</button></div><div class="mut">چهارنفره: تو و هم‌تیمی در برابر دو حریف؛ ۷ دست ببر!</div></div>'+
    '<div class="mut" style="text-align:center">امروز از بازی '+faN(G.games.coins)+' سکه گرفتی • '+faN(capLeft)+' سکه‌ی دیگه می‌تونی بگیری</div>';
  el.querySelectorAll("[data-g]").forEach(function(b){b.onclick=function(){({rps:gRps,gp:gGolPooch,ludo:gLudo,snake:gSnake,bg:gBackgammon,hokm:gHokm})[b.dataset.g](el)}});
}
function gResult(el,win,big,line){
  var c=gameDone(win,big);
  el.innerHTML='<div class="card" style="text-align:center"><div style="width:120px;margin:0 auto">'+girl(win?"sad":"happy","bust")+'</div><h3>'+(win?"بردی! 🏆":"من بردم! 😎")+'</h3><div>'+line+'</div><div class="coin" style="margin:10px 0">'+(c?"+"+faN(c)+" 🪙":"سقف سکه‌ی امروز پر شد")+'</div><button class="btn gold full" id="gAgain">دوباره</button><button class="btn ghost full" id="gBack" style="margin-top:8px">برگشت</button></div>';
  if(win)confetti();
  document.getElementById("gBack").onclick=function(){renderGame()};
  return document.getElementById("gAgain");
}
function gRps(el){
  var st={r:0,you:0,her:0},E={r:"✊",p:"✋",s:"✌️"},names={r:"سنگ",p:"کاغذ",s:"قیچی"};
  function draw(msg){
    el.innerHTML='<div class="card" style="text-align:center"><div style="width:110px;margin:0 auto">'+girl("wink","bust")+'</div><b>دست '+faN(Math.min(st.r+1,5))+' از ۵</b><div class="mut">تو '+faN(st.you)+' — سارا '+faN(st.her)+'</div><div style="min-height:46px;margin:8px 0">'+(msg||"انتخاب کن!")+'</div>'+
      '<div class="row" style="justify-content:center">'+["r","p","s"].map(function(k){return '<button class="btn big" data-k="'+k+'" style="font-size:34px">'+E[k]+'</button>'}).join("")+'</div></div>';
    el.querySelectorAll("[data-k]").forEach(function(b){b.onclick=function(){play(b.dataset.k)}});
  }
  function play(k){
    var h=R(["r","p","s"]),beat={r:"s",p:"r",s:"p"},res;
    if(k===h)res="مساوی شد 😅";else if(beat[k]===h){st.you++;res="تو بردی این دست 😤"}else{st.her++;res="این دست مال منه 😎"}
    st.r++;
    var msg='تو: '+E[k]+' '+names[k]+' — سارا: '+E[h]+' '+names[h]+'<br><b>'+res+'</b>';
    if(st.r>=5){
      var win=st.you>st.her;
      if(st.you===st.her){draw(msg+"<br>مساوی شدیم! یه دست اضافه 😏");st.r=4;return}
      var b=gResult(el,win,false,"نتیجه "+faN(st.you)+" بر "+faN(st.her));b.onclick=function(){st={r:0,you:0,her:0};draw()};
    }else draw(msg);
  }
  draw();
}
function gGolPooch(el){
  var st={r:0,s:0,c:0};
  function draw(msg,mode,hid){
    var you=st.r%2===0; /* دور زوج: تو حدس می‌زنی */
    el.innerHTML='<div class="card" style="text-align:center"><div style="width:110px;margin:0 auto">'+girl("wow","bust")+'</div><b>دور '+faN(st.r+1)+' از ۶</b><div class="mut">امتیاز تو '+faN(st.s)+' — سارا '+faN(st.c)+'</div><div style="min-height:46px;margin:8px 0">'+(msg||(you?"سارا توی دستش رو بسته کرده. حدس بزن: گل یا پوچ؟":"این بار تو قایم کن! توی مشتت گل (سنگ) هست یا پوچ؟"))+'</div>'+
      '<div class="row" style="justify-content:center"><button class="btn gold" data-v="1">'+(you?"گل ✊🪨":"گل دارم 🪨")+'</button><button class="btn" data-v="0">'+(you?"پوچ ✋":"پوچ‌ه ✋")+'</button></div></div>';
    el.querySelectorAll("[data-v]").forEach(function(b){b.onclick=function(){turn(+b.dataset.v,you)}});
  }
  function turn(v,you){
    var other=Math.random()<.5?1:0,ok,msg;
    if(you){ok=(v===other);msg="توی دست سارا "+(other?"گل بود 🪨":"پوچ بود ✋")+" — "+(ok?"درست حدس زدی 🎯":"غلط حدس زدی 🙈");if(ok)st.s++}
    else{ok=(other===v);msg="سارا گفت "+(other?"گل":"پوچ")+" — "+(ok?"درست حدس زد 😎":"اشتباه کرد 🤭");if(ok)st.c++}
    st.r++;
    if(st.r>=6){
      if(st.s===st.c){st.r=4;draw(msg+"<br>مساوی! یه دور اضافه ⚔️");return}
      var b=gResult(el,st.s>st.c,false,"نتیجه "+faN(st.s)+" بر "+faN(st.c));b.onclick=function(){st={r:0,s:0,c:0};draw()};
    }else{
      el.innerHTML='<div class="card" style="text-align:center"><div style="width:110px;margin:0 auto">'+girl(ok&&you?"happy":"wink","bust")+'</div><div style="margin:8px 0">'+msg+'</div><button class="btn gold full" id="gNext">دور بعد</button></div>';
      document.getElementById("gNext").onclick=function(){draw()};
    }
  }
  draw();
}

/* منچ */
function gLudo(el){
  var START={you:0,her:20},SAFE=[0,20],N=40;
  var st={you:[-1,-1,-1,-1],her:[-1,-1,-1,-1],turn:"you",die:0,phase:"roll",msg:"تو شروع کن! تاس بنداز 🎲",over:false};
  function ringXY(i){var a=(i/N)*2*Math.PI-Math.PI/2;return [160+128*Math.cos(a),160+128*Math.sin(a)]}
  function laneXY(who,k){var a=(START[who]/N)*2*Math.PI-Math.PI/2;var r=128-(k+1)*21;return [160+r*Math.cos(a),160+r*Math.sin(a)]}
  function xy(who,i,p){
    if(p===-1){var bx=who==="you"?[52,52]:[268,268];return [bx[0]+(i%2)*26-13,bx[1]+Math.floor(i/2)*26-13]}
    if(p>=40)return laneXY(who,p-40);
    return ringXY((START[who]+p)%N);
  }
  function legal(who,d){
    var r=[];st[who].forEach(function(p,i){if(p===-1){if(d===6)r.push(i)}else if(p+d<=43)r.push(i)});return r;
  }
  function move(who,i,d){
    var arr=st[who],opp=who==="you"?"her":"you",p=arr[i],np=p===-1?0:p+d,cap=false;
    arr[i]=np;
    if(np<=39&&np>=0){
      var abs=(START[who]+np)%N;
      if(SAFE.indexOf(abs)<0)st[opp].forEach(function(q,j){if(q>=0&&q<=39&&(START[opp]+q)%N===abs){st[opp][j]=-1;cap=true}});
    }
    return cap;
  }
  function won(who){return st[who].every(function(p){return p===43})}
  function end(w){
    st.over=true;var b=gResult(el,w==="you",true,w==="you"?"همه‌ی مهره‌هات رو رسوندی! آفرین 👏":"مهره‌هام زودتر رسیدن 😜");b.onclick=function(){gLudo(el)};
  }
  function finishTurn(who,d,cap){
    if(won(who)){end(who);return}
    if(d===6){st.msg=(who==="you"?"۶ آوردی! دوباره بنداز 🎲":"سارا ۶ آورد و دوباره می‌اندازه 😈")}
    else st.turn=who==="you"?"her":"you";
    st.phase="roll";st.die=0;
    if(cap)st.msg=(who==="you"?"زدی به مهره‌ی سارا! 💥 ":"مهره‌ات رو زدم 😈 ")+st.msg;
    draw();
    if(st.turn==="her")setTimeout(herRoll,700);
  }
  function herRoll(){
    if(st.over||st.turn!=="her")return;
    var d=1+Math.floor(Math.random()*6);st.die=d;
    var l=legal("her",d);
    if(!l.length){st.msg="سارا "+d+" آورد و حرکتی نداره 😅";st.turn=d===6?"her":"you";st.phase="roll";draw();if(st.turn==="her")setTimeout(herRoll,700);return}
    var best=l[0],bs=-1e9;
    l.forEach(function(i){
      var p=st.her[i],np=p===-1?0:p+d,s=0;
      if(p===-1)s+=50;
      if(np===43)s+=60;if(np>=40)s+=30;
      if(np<=39&&np>=0){var abs=(START.her+np)%N;if(SAFE.indexOf(abs)<0)st.you.forEach(function(q){if(q>=0&&q<=39&&(START.you+q)%N===abs)s+=100})}
      s+=np;
      if(s>bs){bs=s;best=i}
    });
    st.msg="سارا "+d+" آورد 🎲";draw();
    setTimeout(function(){var cap=move("her",best,d);finishTurn("her",d,cap)},650);
  }
  function youRoll(){
    if(st.over||st.turn!=="you"||st.phase!=="roll")return;
    var d=1+Math.floor(Math.random()*6);st.die=d;
    var l=legal("you",d);
    if(!l.length){st.msg="تو "+d+" آوردی ولی حرکتی نداری 😅";st.phase="roll";if(d!==6)st.turn="her";draw();if(st.turn==="her")setTimeout(herRoll,800);return}
    st.phase="move";st.msg=l.length===1?"فقط یه حرکت داری…":"یکی از مهره‌های چشمک‌زن رو بزن 👆";draw();
    if(l.length===1)setTimeout(function(){doYou(l[0],d)},550);
  }
  function doYou(i,d){var cap=move("you",i,d);finishTurn("you",d,cap)}
  function draw(){
    var l=st.phase==="move"?legal("you",st.die):[];
    var s='<svg viewBox="0 0 320 320" class="ludo"><circle cx="160" cy="160" r="150" fill="#2a1d4a" stroke="#ffffff22"/>';
    for(var i=0;i<N;i++){var p=ringXY(i);s+='<circle cx="'+p[0].toFixed(1)+'" cy="'+p[1].toFixed(1)+'" r="8" fill="'+(i===0?"#ff6b8b55":i===20?"#4dabf755":"#ffffff1c")+'" stroke="#ffffff30"/>'}
    ["you","her"].forEach(function(w){for(var k=0;k<4;k++){var p=laneXY(w,k);s+='<circle cx="'+p[0].toFixed(1)+'" cy="'+p[1].toFixed(1)+'" r="7" fill="'+(w==="you"?"#ff6b8b33":"#4dabf733")+'" stroke="'+(w==="you"?"#ff6b8b":"#4dabf7")+'"/>'}});
    s+='<rect x="22" y="22" width="60" height="60" rx="12" fill="#ff6b8b22"/><rect x="238" y="238" width="60" height="60" rx="12" fill="#4dabf722"/><text x="160" y="166" text-anchor="middle" fill="#fff" font-size="22" opacity=".5">🏁</text>';
    ["you","her"].forEach(function(w){st[w].forEach(function(p,i){
      var q=xy(w,i,p),mv=w==="you"&&l.indexOf(i)>=0,col=w==="you"?"#ff6b8b":"#4dabf7";
      s+='<circle cx="'+q[0].toFixed(1)+'" cy="'+q[1].toFixed(1)+'" r="10" fill="'+col+'" stroke="#fff" stroke-width="2.5" '+(mv?'class="mv" data-pi="'+i+'" style="cursor:pointer"':'')+'/><text x="'+q[0].toFixed(1)+'" y="'+(q[1]+4).toFixed(1)+'" text-anchor="middle" font-size="11" fill="#fff" font-weight="800" pointer-events="none">'+(i+1)+'</text>';
    })});
    s+='</svg>';
    var dice=st.die?'<span class="dice">'+["","⚀","⚁","⚂","⚃","⚄","⚅"][st.die]+'</span>':'';
    el.innerHTML='<div class="card"><div class="row sp"><b>🎲 منچ</b><span class="mut">تو (صورتی) در برابر سارا (آبی)</span></div>'+s+'<div style="text-align:center;margin:6px 0;min-height:44px">'+dice+' <span>'+st.msg+'</span></div>'+
      (st.turn==="you"&&st.phase==="roll"&&!st.over?'<button class="btn gold full" id="lRoll">🎲 تاس بنداز</button>':'')+
      '<button class="btn ghost full" id="lBack" style="margin-top:8px">ترک بازی</button></div>';
    var rb=document.getElementById("lRoll");if(rb)rb.onclick=youRoll;
    document.getElementById("lBack").onclick=function(){st.over=true;renderGame()};
    el.querySelectorAll("[data-pi]").forEach(function(c){c.onclick=function(){doYou(+c.dataset.pi,st.die)}});
  }
  draw();
}

/* ---------- ظاهر ---------- */
(function(){
  var css=document.createElement("style");
  css.textContent=[
  ".girl{display:block;width:100%;height:100%}.girl svg,.av{width:100%;height:100%;display:block}",
  ".hero .girl{width:92px;height:92px;flex:0 0 92px;cursor:pointer;background:radial-gradient(circle at 50% 60%,#ffffff2a,transparent 70%);border-radius:50%;overflow:hidden}",
  "#posBar{display:flex;align-items:center;gap:10px;margin:0 16px 6px;padding:7px 12px;border-radius:18px;background:linear-gradient(135deg,#ffffff1c,#ffffff0a);border:1px solid var(--line);cursor:pointer}",
  "#posBar .pbav{width:44px;height:44px;flex:0 0 44px;border-radius:50%;overflow:hidden;background:#ffffff26}#posBar .pbt{font-size:13px;line-height:1.7;font-weight:600}",
  ".peek{position:fixed;bottom:86px;z-index:60;max-width:86vw;display:flex;gap:8px;align-items:flex-end;opacity:0;pointer-events:none;transition:transform .45s cubic-bezier(.2,1.3,.4,1),opacity .3s}",
  ".peek.l{left:6px;transform:translateX(-120%)}.peek.r{right:6px;transform:translateX(120%);flex-direction:row-reverse}",
  ".peek.on{opacity:1;pointer-events:auto;transform:none}",
  ".peek .pa{width:64px;height:64px;flex:0 0 64px;border-radius:50%;overflow:hidden;background:#ffffff33;border:2px solid #fff6}",
  ".peek .pb{background:#fff;color:#2b1a5e;border-radius:18px;padding:10px 12px;font-size:13px;line-height:1.7;font-weight:600;box-shadow:0 8px 24px #0006}",
  "#gscr{position:fixed;inset:0;z-index:80;background:linear-gradient(180deg,var(--bg2),var(--bg1));display:flex;flex-direction:column;overflow:hidden}",
  "#gscr .gh{display:flex;align-items:center;justify-content:space-between;padding:calc(env(safe-area-inset-top,0px) + 12px) 14px 8px}",
  "#gscr .gtabs{display:flex;gap:6px;padding:0 10px 8px;overflow-x:auto}#gscr .gtabs button{flex:1;min-width:64px;border-radius:14px;padding:7px 4px;background:var(--card2);border:1px solid var(--line);color:var(--text);font:inherit;font-size:12px}",
  "#gscr .gtabs button span{display:block;font-size:18px}#gscr .gtabs button.on{background:var(--gold);color:#3b2a00;font-weight:800}",
  "#gscr .gb{flex:1;overflow-y:auto;padding:4px 14px 30px;-webkit-overflow-scrolling:touch}",
  ".coin{background:#ffd54f26;border:1px solid #ffd54f66;border-radius:99px;padding:3px 10px;font-weight:800;color:#ffd54f;font-size:13px}",
  ".room{position:relative;height:360px;border-radius:22px;overflow:hidden;margin-bottom:12px;border:1px solid var(--line)}.room .scene{position:absolute;inset:0;width:100%;height:100%}",
  ".room .rav{position:absolute;left:50%;bottom:6px;height:92%;transform:translateX(-50%)}.room .rav .av{height:100%;width:auto}",
  ".rbub{position:absolute;top:12px;right:12px;max-width:62%;background:#fff;color:#2b1a5e;border-radius:16px;padding:8px 12px;font-size:13px;font-weight:700;line-height:1.6;cursor:pointer}",
  ".wprev{height:270px;border-radius:20px;background:radial-gradient(circle at 50% 40%,#ffffff22,#ffffff08);margin-bottom:10px;display:flex;justify-content:center}.wprev .av{height:100%;width:auto}",
  ".wcats{display:flex;gap:6px;overflow-x:auto;padding-bottom:8px}.wcats button{flex:0 0 auto;padding:7px 12px;border-radius:99px;background:var(--card2);border:1px solid var(--line);color:var(--text);font:inherit;font-size:13px}.wcats button.on{background:var(--gold);color:#3b2a00;font-weight:800}",
  ".witems{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.wi{padding:10px 4px;border-radius:14px;background:var(--card2);border:2px solid transparent;color:var(--text);font:inherit;display:flex;flex-direction:column;gap:2px;align-items:center}",
  ".wi.on{border-color:var(--gold)}.wi.lock{opacity:.45}.wi small{font-size:11px;color:var(--mut)}",
  ".wset{padding:12px;border-radius:16px;background:var(--card2);margin-bottom:8px;grid-column:1/-1;display:flex;flex-direction:column;gap:8px}.wset.lock{opacity:.5}.witems:has(.wset){display:block}",
  ".swr{display:flex;gap:8px;flex-wrap:wrap;grid-column:1/-1}.sw{width:34px;height:34px;border-radius:50%;border:3px solid #fff3}.sw.on{border-color:#fff}",
  ".ludo{width:100%;max-width:340px;display:block;margin:8px auto}.ludo .mv{animation:blink .8s infinite}@keyframes blink{50%{opacity:.4}}",
  ".dice{font-size:38px;vertical-align:middle}.btn.big{padding:10px 18px}",
  ".gscr .card{margin-bottom:10px}"
  ].join("\n");
  document.head.appendChild(css);
})();
document.addEventListener("DOMContentLoaded",function(){
  var pk=document.createElement("div");pk.id="peek";pk.className="peek l";document.body.appendChild(pk);
  setInterval(function(){peek(false)},45000);
});
