"use strict";
/* ===== سارا، خانم ناظر خزانه‌دار — شخصیت کاملاً اصلی (SVG) ===== */
var SKINS=["#fbe0c8","#f1c9a5","#e0a97d","#c68a5b","#8d5a3b"];
var HAIRC=["#2b1b17","#5a3320","#8a4b25","#b5651d","#d9a441","#c43c5b","#6b4bd6","#2fa7a0"];
var CLOTHC=["#e94f7a","#ff8a3d","#f4c430","#37b57a","#2b9bd6","#5b5bd6","#9b59b6","#2d3142","#f5f5f5","#c0392b"];

/* کاتالوگ لباس‌ها: lvl = حداقل سطح، price = سکه */
var CAT={
  top:[
    {id:"tee",n:"تی‌شرت",lvl:1,price:0},{id:"hoodie",n:"هودی",lvl:2,price:0},
    {id:"sport",n:"تاپ ورزشی",lvl:3,price:20},{id:"bikini",n:"بیکینی (بالا)",lvl:3,price:40},{id:"blazer",n:"کت کاری",lvl:4,price:40}
  ],
  bottom:[
    {id:"jeans",n:"شلوار جین",lvl:1,price:0},{id:"skirt",n:"دامن",lvl:2,price:0},
    {id:"trousers",n:"شلوار پارچه‌ای",lvl:3,price:20},{id:"leggings",n:"لگ ورزشی",lvl:3,price:20},{id:"bikini",n:"بیکینی (پایین)",lvl:3,price:40}
  ],
  one:[
    {id:"dress",n:"پیراهن",lvl:2,price:30},{id:"gown",n:"لباس مجلسی",lvl:5,price:80},
    {id:"robe",n:"ردای جادوگر",lvl:6,price:100},{id:"space",n:"لباس فضانوردی",lvl:7,price:120},
    {id:"royal",n:"لباس سلطنتی",lvl:9,price:200}
  ],
  shoes:[
    {id:"sneaker",n:"کتونی",lvl:1,price:0},{id:"heels",n:"پاشنه‌بلند",lvl:3,price:25},
    {id:"boots",n:"بوت",lvl:4,price:35},{id:"flats",n:"کفش تخت",lvl:1,price:0}
  ],
  hair:[
    {id:"long",n:"بلند",lvl:1,price:0},{id:"bob",n:"کوتاه",lvl:1,price:0},
    {id:"pony",n:"دم‌اسبی",lvl:2,price:0},{id:"bun",n:"جمع‌شده",lvl:3,price:10},{id:"braid",n:"بافت",lvl:4,price:15}
  ],
  acc:[
    {id:"glasses",n:"عینک",lvl:1,price:0},{id:"sunglasses",n:"عینک آفتابی",lvl:3,price:12},{id:"scarf",n:"شال‌گردن",lvl:2,price:10},
    {id:"beanie",n:"کلاه بافت",lvl:2,price:15},{id:"earrings",n:"گوشواره",lvl:3,price:15},
    {id:"necklace",n:"گردنبند",lvl:3,price:20},{id:"phones",n:"هدفون استودیو",lvl:4,price:30},
    {id:"wizhat",n:"کلاه جادوگری",lvl:6,price:50},{id:"crown",n:"تاج",lvl:8,price:150},
    {id:"wings",n:"بال",lvl:10,price:250}
  ]
};
/* ست‌ها: با پوشیدنشون تم اپ هم عوض می‌شه */
var SETS=[
  {id:"casual",n:"روزمره",lvl:1,e:"👕",o:{top:"tee",one:"",bottom:"jeans",shoes:"sneaker"},theme:"night"},
  {id:"office",n:"کاری",lvl:4,e:"💼",o:{top:"blazer",one:"",bottom:"trousers",shoes:"heels"},theme:"navy"},
  {id:"sporty",n:"ورزشی",lvl:3,e:"🏃",o:{top:"sport",one:"",bottom:"leggings",shoes:"sneaker"},theme:"green"},
  {id:"party",n:"مجلسی",lvl:5,e:"💃",o:{top:"tee",one:"gown",bottom:"jeans",shoes:"heels",acc:["earrings","necklace"]},theme:"rose"},
  {id:"beach",n:"ساحلی (بیکینی)",lvl:3,e:"🏖️",o:{top:"bikini",one:"",bottom:"bikini",shoes:"flats",acc:["sunglasses"]},theme:"ocean"},
  {id:"wizard",n:"جادوگر",lvl:6,e:"🧙",o:{one:"robe",shoes:"boots",acc:["wizhat"]},theme:"magic"},
  {id:"space",n:"فضانورد",lvl:7,e:"🚀",o:{one:"space",shoes:"boots"},theme:"space"},
  {id:"royal",n:"سلطنتی",lvl:9,e:"👑",o:{one:"royal",shoes:"heels",acc:["crown","earrings","necklace"]},theme:"gold"}
];
var THEMES={
  night:{n:"شب بنفش",b1:"#150b33",b2:"#2a1466"},navy:{n:"نیلی کاری",b1:"#071a33",b2:"#0f3a6b"},
  ocean:{n:"اقیانوسی",b1:"#04263a",b2:"#0b6b8a"},green:{n:"سبز ورزشی",b1:"#08241c",b2:"#0f5b44"},rose:{n:"گل‌بهی مجلسی",b1:"#33081f",b2:"#7a1a4a"},
  magic:{n:"جادویی",b1:"#1d0a3d",b2:"#4b1d8f"},space:{n:"فضایی",b1:"#02040f",b2:"#0b1f4a"},gold:{n:"طلایی سلطنتی",b1:"#2b1a02",b2:"#6b4a08"}
};
var JOBS=["کارآموز حسابداری","منشی مالی","حسابدار","کارشناس مالی","مدیر مالی","مشاور سرمایه‌گذاری","شریک شرکت","مدیرعامل","سرمایه‌دار","ملکه‌ی خزانه"];
var HOUSES=["اتاق اجاره‌ای","اتاق اجاره‌ای","آپارتمان کوچک","آپارتمان کوچک","آپارتمان نوساز","آپارتمان نوساز","ویلا","ویلا","برج","قصر"];
var DEFAULT_OUTFIT={top:"tee",one:"",bottom:"jeans",shoes:"sneaker",hair:"long",hairc:"#8a4b25",skin:"#f1c9a5",topc:"#e94f7a",botc:"#2b9bd6",acc:["glasses"],eye:"#3d7a4a",theme:"night"};

function _sh(c,a){ /* روشن/تیره کردن رنگ hex */
  var n=parseInt(c.slice(1),16),r=n>>16,g=(n>>8)&255,b=n&255;
  function f(v){return Math.max(0,Math.min(255,Math.round(v+a)))}
  return "#"+((1<<24)+(f(r)<<16)+(f(g)<<8)+f(b)).toString(16).slice(1);
}
function _mir(d){ /* آینه‌ی افقی یک path حول x=100 (فقط دستورهای مطلق M L Q C Z) */
  return d.replace(/([MLQCZ])([^MLQCZ]*)/g,function(_,c,args){
    if(c==="Z")return "Z";
    var nums=args.trim().split(/[\s,]+/).map(Number),o=[];
    for(var i=0;i<nums.length;i+=2){o.push((200-nums[i])+" "+nums[i+1])}
    return c+o.join(" ");
  });
}

function avatar(o,mood,view){
  o=Object.assign({},DEFAULT_OUTFIT,o||{});
  var skin=o.skin,skinD=_sh(skin,-22),hair=o.hairc,hairD=_sh(hair,-30),hairL=_sh(hair,28);
  var tc=o.topc,bc=o.botc,acc=o.acc||[];
  var s='';
  var has=function(a){return acc.indexOf(a)>=0};
  var one=o.one;
  /* پشت‌صحنه: بال، شنل، موی پشت */
  if(has("wings"))s+='<g opacity=".95"><path d="M64 128 Q8 90 14 40 Q40 70 70 112Z" fill="#fff" stroke="#cfd8ff" stroke-width="2"/><path d="M136 128 Q192 90 186 40 Q160 70 130 112Z" fill="#fff" stroke="#cfd8ff" stroke-width="2"/><path d="M62 134 Q14 118 10 80 Q40 96 68 120Z" fill="#e9eeff"/><path d="M138 134 Q186 118 190 80 Q160 96 132 120Z" fill="#e9eeff"/></g>';
  if(one==="royal")s+='<path d="M62 124 Q40 240 36 346 L164 346 Q160 240 138 124Z" fill="#7b1fa2"/><path d="M36 346 L164 346 L164 338 L36 338Z" fill="#fff" opacity=".9"/>';
  if(o.hair==="long")s+='<path d="M66 66 Q52 150 62 190 Q78 200 100 192 Q122 200 138 190 Q148 150 134 66Z" fill="'+hair+'"/>';
  if(o.hair==="bob")s+='<path d="M66 64 Q56 112 70 122 L130 122 Q144 112 134 64Z" fill="'+hair+'"/>';
  if(o.hair==="braid")s+='<path d="M132 70 Q150 100 146 130 Q142 160 138 190" stroke="'+hair+'" stroke-width="15" fill="none" stroke-linecap="round"/><g fill="'+hairD+'"><circle cx="144" cy="108" r="3"/><circle cx="145" cy="130" r="3"/><circle cx="143" cy="152" r="3"/><circle cx="141" cy="174" r="3"/></g><circle cx="138" cy="192" r="5" fill="#e94f7a"/>';
  if(o.hair==="pony")s+='<path d="M128 56 Q164 62 160 110 Q158 140 146 150 Q150 110 128 76Z" fill="'+hair+'"/><circle cx="130" cy="64" r="5" fill="#e94f7a"/>';
  if(o.hair==="bun")s+='<circle cx="100" cy="26" r="15" fill="'+hair+'"/><circle cx="100" cy="26" r="15" fill="none" stroke="'+hairD+'" stroke-width="2"/>';
  /* پاها */
  var legC=skin;
  s+='<path d="M69 212 L99 212 Q97 280 93 338 L75 338 Q71 280 69 212Z" fill="'+legC+'"/><path d="M101 212 L131 212 Q129 280 125 338 L107 338 Q103 280 101 212Z" fill="'+legC+'"/>';
  /* کفش */
  var sh=o.shoes,shc=(sh==="boots")?"#6b3e26":(sh==="heels")?"#c0392b":(sh==="flats")?"#2d3142":"#f5f5f5";
  if(one==="space")shc="#9aa4b2";if(one==="royal")shc="#f4c430";
  if(sh==="boots"||one==="space"){
    s+='<path d="M72 300 L96 300 L98 348 Q82 356 68 350Z" fill="'+shc+'"/><path d="M104 300 L128 300 L132 350 Q118 356 102 348Z" fill="'+shc+'"/>';
  }else if(sh==="heels"){
    s+='<path d="M70 338 L96 338 L99 348 Q82 354 66 348Z" fill="'+shc+'"/><rect x="92" y="346" width="3" height="10" fill="'+_sh(shc,-40)+'"/><path d="M104 338 L130 338 L134 348 Q118 354 101 348Z" fill="'+shc+'"/><rect x="105" y="346" width="3" height="10" fill="'+_sh(shc,-40)+'"/>';
  }else{
    s+='<path d="M68 340 L96 340 Q102 348 98 354 L64 354 Q62 346 68 340Z" fill="'+shc+'"/><path d="M104 340 L132 340 Q138 346 136 354 L102 354 Q98 348 104 340Z" fill="'+shc+'"/><path d="M64 352 L98 352M102 352 L136 352" stroke="#00000030" stroke-width="3"/>';
  }
  /* پایین‌تنه */
  var bot=o.bottom;
  if(!one){
    if(bot==="jeans"||bot==="trousers"){
      var pc=bot==="jeans"?bc:_sh(bc,-10);
      s+='<path d="M67 176 L133 176 Q136 196 134 214 Q130 280 126 336 L106 336 L100 232 L94 336 L74 336 Q70 280 66 214 Q64 196 67 176Z" fill="'+pc+'"/><path d="M100 200 L100 232" stroke="'+_sh(pc,-30)+'" stroke-width="1.5"/>';
      if(bot==="jeans")s+='<path d="M67 184 L133 184" stroke="'+_sh(pc,-35)+'" stroke-width="3"/><path d="M76 200 Q80 212 90 214M124 200 Q120 212 110 214" stroke="'+_sh(pc,40)+'" stroke-width="1.5" fill="none"/>';
    }else if(bot==="leggings"){
      s+='<path d="M67 176 L133 176 Q136 196 134 214 Q130 280 124 336 L108 336 L100 226 L92 336 L76 336 Q70 280 66 214 Q64 196 67 176Z" fill="'+_sh(bc,-25)+'"/><path d="M70 220 Q72 280 78 336M130 220 Q128 280 122 336" stroke="'+hairL+'" stroke-width="2" opacity=".5" fill="none"/>';
    }else if(bot==="bikini"){
      s+='<path d="M70 176 L130 176 Q134 196 132 212 L68 212 Q66 196 70 176Z" fill="'+skin+'"/><path d="M72 188 L128 188 L100 222Z" fill="'+bc+'"/><path d="M72 188 L128 188" stroke="'+_sh(bc,-30)+'" stroke-width="2.5"/><circle cx="100" cy="203" r="2.5" fill="#fff" opacity=".8"/>';
    }else if(bot==="skirt"){
      s+='<path d="M72 176 L128 176 Q136 200 150 262 Q100 276 50 262 Q64 200 72 176Z" fill="'+bc+'"/><path d="M78 190 Q74 230 66 262M100 190 L100 270M122 190 Q126 230 134 262" stroke="'+_sh(bc,-28)+'" stroke-width="1.5" fill="none"/>';
    }
  }
  /* لباس یک‌تکه */
  if(one==="dress"){
    s+='<path d="M66 122 Q100 112 134 122 Q140 142 128 168 Q124 176 126 182 Q150 232 156 270 Q100 286 44 270 Q50 232 74 182 Q76 176 72 168 Q60 142 66 122Z" fill="'+tc+'"/><path d="M74 182 Q100 192 126 182" stroke="'+_sh(tc,-35)+'" stroke-width="3" fill="none"/><path d="M60 270 Q100 282 140 270" stroke="#ffffff55" stroke-width="3" fill="none"/>';
  }
  if(one==="gown"){
    s+='<path d="M68 122 Q100 112 132 122 Q132 134 126 150 Q122 166 124 176 Q128 184 146 248 Q158 300 164 344 Q100 360 36 344 Q42 300 54 248 Q72 184 76 176 Q78 166 74 150 Q68 134 68 122Z" fill="'+tc+'"/><path d="M76 176 Q100 186 124 176" stroke="'+_sh(tc,-40)+'" stroke-width="4" fill="none"/><path d="M58 300 Q100 320 142 300" stroke="#ffffff40" stroke-width="3" fill="none"/><g fill="#fff" opacity=".85"><circle cx="86" cy="150" r="2"/><circle cx="116" cy="160" r="2"/><circle cx="70" cy="262" r="2.4"/><circle cx="104" cy="286" r="2.4"/><circle cx="132" cy="258" r="2.4"/><circle cx="96" cy="230" r="2"/><circle cx="60" cy="318" r="2.4"/><circle cx="140" cy="322" r="2.4"/></g><path d="M68 124 Q100 140 132 124" fill="'+skin+'"/>';
  }
  if(one==="robe"){
    s+='<path d="M62 122 Q100 110 138 122 L146 200 Q164 260 168 344 Q100 358 32 344 Q36 260 54 200Z" fill="'+tc+'"/><path d="M62 124 Q40 176 30 226 Q44 236 56 226 Q62 190 76 150Z" fill="'+_sh(tc,-12)+'"/><path d="M138 124 Q160 176 170 226 Q156 236 144 226 Q138 190 124 150Z" fill="'+_sh(tc,-12)+'"/><path d="M76 176 Q100 186 124 176 L124 190 Q100 200 76 190Z" fill="#f4c430"/><g fill="#ffe27a"><path d="M84 240 l3 7 7 1 -5 5 1 7 -6 -4 -6 4 1 -7 -5 -5 7 -1z"/><path d="M122 290 l3 7 7 1 -5 5 1 7 -6 -4 -6 4 1 -7 -5 -5 7 -1z"/><path d="M70 310 l2 5 5 1 -4 4 1 5 -4 -3 -4 3 1 -5 -4 -4 5 -1z"/></g><path d="M86 124 Q100 138 114 124" fill="'+skin+'"/>';
  }
  if(one==="space"){
    s+='<path d="M64 122 Q100 112 136 122 Q140 144 130 168 L134 214 Q132 280 126 336 L106 336 L100 236 L94 336 L74 336 Q68 280 66 214 L70 168 Q60 144 64 122Z" fill="#eef1f6"/><path d="M64 124 Q46 160 44 196 Q50 204 60 198 Q64 164 76 136Z" fill="#eef1f6"/><path d="M136 124 Q154 160 156 196 Q150 204 140 198 Q136 164 124 136Z" fill="#eef1f6"/><rect x="82" y="150" width="36" height="22" rx="5" fill="#2b9bd6"/><circle cx="92" cy="161" r="4" fill="#ff8a3d"/><circle cx="106" cy="161" r="4" fill="#37b57a"/><rect x="66" y="184" width="68" height="8" fill="#9aa4b2"/><path d="M84 124 Q100 136 116 124 L116 130 Q100 142 84 130Z" fill="#9aa4b2"/><circle cx="50" cy="196" r="8" fill="#9aa4b2"/><circle cx="150" cy="196" r="8" fill="#9aa4b2"/>';
  }
  if(one==="royal"){
    s+='<path d="M68 122 Q100 112 132 122 Q132 134 126 150 Q122 166 124 176 Q130 190 150 252 Q160 300 160 344 Q100 358 40 344 Q40 300 50 252 Q70 190 76 176 Q78 166 74 150 Q68 134 68 122Z" fill="#9c27b0"/><path d="M100 176 L100 350" stroke="#f4c430" stroke-width="3"/><path d="M76 176 Q100 186 124 176" stroke="#f4c430" stroke-width="5" fill="none"/><path d="M44 340 Q100 352 156 340" stroke="#f4c430" stroke-width="5" fill="none"/><g fill="#f4c430"><circle cx="88" cy="150" r="2.5"/><circle cx="112" cy="150" r="2.5"/><circle cx="76" cy="250" r="3"/><circle cx="124" cy="250" r="3"/><circle cx="64" cy="300" r="3"/><circle cx="136" cy="300" r="3"/></g><path d="M68 124 Q100 142 132 124 L132 130 Q100 150 68 130Z" fill="#f4c430"/>';
  }
  /* بازوها (پوست) */
  var armL='M64 124 Q49 150 47 192 Q47 202 56 202 Q63 202 63 192 Q64 162 76 136Z';
  var showSkinArms=!(o.top==="hoodie"||o.top==="blazer"||one==="robe"||one==="space");
  if(showSkinArms)s+='<path d="'+armL+'" fill="'+skin+'"/><path d="'+_mir(armL)+'" fill="'+skin+'"/>';
  s+='<circle cx="54" cy="206" r="7.5" fill="'+skin+'"/><circle cx="146" cy="206" r="7.5" fill="'+skin+'"/>';
  /* تاپ‌ها */
  if(!one){
    var torso='M64 122 Q100 112 136 122 Q140 140 130 160 Q124 172 126 180 Q134 196 134 214 L66 214 Q66 196 74 180 Q76 172 70 160 Q60 140 64 122Z';
    if(o.top==="tee"){
      s+='<path d="'+torso.replace("L66 214","L66 200").replace("134 214","134 200")+'" fill="'+tc+'"/><path d="M64 124 Q54 140 52 158 L68 162 Q70 144 76 134Z" fill="'+tc+'"/><path d="M136 124 Q146 140 148 158 L132 162 Q130 144 124 134Z" fill="'+tc+'"/><path d="M86 122 Q100 134 114 122" fill="'+skin+'"/><path d="M86 122 Q100 134 114 122" stroke="'+_sh(tc,-30)+'" stroke-width="2" fill="none"/>';
    }else if(o.top==="bikini"){
      s+='<path d="'+torso+'" fill="'+skin+'"/><path d="M78 150 Q88 136 98 152 Q90 166 78 150Z" fill="'+tc+'"/><path d="M122 150 Q112 136 102 152 Q110 166 122 150Z" fill="'+tc+'"/><path d="M80 146 Q100 126 120 146" stroke="'+_sh(tc,-30)+'" stroke-width="2" fill="none"/><path d="M98 152 Q100 154 102 152" stroke="'+_sh(tc,-30)+'" stroke-width="2" fill="none"/><path d="M90 178 Q100 184 110 178" stroke="'+_sh(skin,-30)+'" stroke-width="1.5" fill="none" opacity=".6"/>';
    }else if(o.top==="sport"){
      s+='<path d="M72 128 Q100 118 128 128 Q134 150 126 170 Q124 180 126 188 Q112 194 100 194 Q88 194 74 188 Q76 180 74 170 Q66 150 72 128Z" fill="'+tc+'"/><path d="M70 150 L130 150" stroke="#fff" stroke-width="3" opacity=".8"/><path d="M86 124 Q100 136 114 124" fill="'+skin+'"/>';
    }else if(o.top==="hoodie"){
      var hc=tc;
      s+='<path d="'+torso+'" fill="'+hc+'"/><path d="M64 124 Q46 156 44 196 Q50 206 62 200 Q64 166 78 138Z" fill="'+hc+'"/><path d="'+_mir('M64 124 Q46 156 44 196 Q50 206 62 200 Q64 166 78 138Z')+'" fill="'+hc+'"/><path d="M78 124 Q100 150 122 124 Q122 112 100 110 Q78 112 78 124Z" fill="'+_sh(hc,-18)+'"/><path d="M84 124 Q100 138 116 124" fill="'+skin+'" opacity="0"/><path d="M90 140 L90 160M110 140 L110 160" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/><path d="M78 184 Q100 198 122 184 L126 206 L74 206Z" fill="'+_sh(hc,-20)+'"/>';
    }else if(o.top==="blazer"){
      s+='<path d="'+torso+'" fill="#f5f5f5"/><path d="M64 122 Q100 112 136 122 Q140 140 130 160 Q124 172 126 180 Q134 196 134 214 L108 214 L100 150 L92 214 L66 214 Q66 196 74 180 Q76 172 70 160 Q60 140 64 122Z" fill="'+tc+'"/><path d="M92 126 L100 150 L108 126" fill="#f5f5f5"/><path d="M92 126 L100 150 L88 164 L78 130Z M108 126 L100 150 L112 164 L122 130Z" fill="'+_sh(tc,18)+'"/><path d="M64 124 Q46 156 44 196 Q50 206 62 200 Q64 166 78 138Z" fill="'+tc+'"/><path d="'+_mir('M64 124 Q46 156 44 196 Q50 206 62 200 Q64 166 78 138Z')+'" fill="'+tc+'"/><circle cx="100" cy="188" r="2.5" fill="#f4c430"/>';
    }
  }
  /* گردن */
  s+='<path d="M91 98 L109 98 L111 124 Q100 134 89 124Z" fill="'+skin+'"/><path d="M91 108 Q100 116 109 108 L109 114 Q100 122 91 114Z" fill="'+skinD+'" opacity=".5"/>';
  if(!one&&(o.top==="tee"||o.top==="sport")){ /* یقه روی گردن */ }
  /* شال‌گردن */
  if(has("scarf")){s+='<path d="M80 112 Q100 128 120 112 L124 124 Q100 142 76 124Z" fill="#e94f7a"/><path d="M110 126 L122 168 L108 166 L100 134Z" fill="#c2325c"/><path d="M104 150 L119 152M105 158 L120 160" stroke="#fff" stroke-width="2" opacity=".6"/>';}
  if(has("necklace")){s+='<path d="M86 124 Q100 148 114 124" stroke="#f4c430" stroke-width="2" fill="none"/><circle cx="100" cy="144" r="4" fill="#e94f7a" stroke="#f4c430" stroke-width="1.5"/>';}
  /* سر */
  s+='<circle cx="69" cy="76" r="5.5" fill="'+skin+'"/><circle cx="131" cy="76" r="5.5" fill="'+skin+'"/>';
  if(has("earrings")){s+='<circle cx="68" cy="86" r="3" fill="#f4c430"/><circle cx="132" cy="86" r="3" fill="#f4c430"/>';}
  s+='<defs><radialGradient id="gl" cx=".35" cy=".28" r=".85"><stop offset="0" stop-color="#fff" stop-opacity=".38"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#5a2a10" stop-opacity=".28"/></radialGradient></defs>';
  s+='<ellipse cx="100" cy="72" rx="31" ry="36" fill="'+skin+'"/><ellipse cx="100" cy="72" rx="31" ry="36" fill="url(#gl)"/>';
  s+='<path d="M70 86 Q100 118 130 86 Q128 100 100 108 Q72 100 70 86Z" fill="'+skinD+'" opacity=".18"/>';
  /* ابرو و چشم */
  var eyeY=76,browUp=mood==="wow",browSad=mood==="sad";
  var eyeC=o.eye;
  function eye(cx,sgn){
    var e='<ellipse cx="'+cx+'" cy="'+eyeY+'" rx="8" ry="'+(mood==="wow"?7.5:6.2)+'" fill="#fff"/>';
    if(mood==="wink"&&sgn>0){e='<path d="M'+(cx-8)+' '+eyeY+' Q'+cx+' '+(eyeY+7)+' '+(cx+8)+' '+eyeY+'" stroke="#2b1b17" stroke-width="2.6" fill="none" stroke-linecap="round"/>';return e}
    e+='<circle cx="'+cx+'" cy="'+(eyeY+0.5)+'" r="4.6" fill="'+eyeC+'"/><circle cx="'+cx+'" cy="'+(eyeY+0.5)+'" r="2.3" fill="#1a1a1a"/><circle cx="'+(cx+1.8)+'" cy="'+(eyeY-1.6)+'" r="1.5" fill="#fff"/>';
    e+='<path d="M'+(cx-9)+' '+(eyeY-1)+' Q'+cx+' '+(eyeY-9)+' '+(cx+9)+' '+(eyeY-1)+'" stroke="#2b1b17" stroke-width="2.4" fill="none" stroke-linecap="round"/>';
    e+='<path d="M'+(cx+(sgn>0?8:-8))+' '+(eyeY-2)+' l'+(sgn>0?3.5:-3.5)+' -3" stroke="#2b1b17" stroke-width="1.8" stroke-linecap="round"/>';
    return e;
  }
  s+=eye(87,1)+eye(113,-1);
  var by=browUp?58:(browSad?62:61);
  s+='<path d="M78 '+(by+(browSad?3:0))+' Q87 '+(by-5)+' 96 '+(by+(browSad?-2:0))+'" stroke="'+hairD+'" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M104 '+(by+(browSad?-2:0))+' Q113 '+(by-5)+' 122 '+(by+(browSad?3:0))+'" stroke="'+hairD+'" stroke-width="2.6" fill="none" stroke-linecap="round"/>';
  /* بینی و گونه */
  s+='<path d="M98 84 Q100 88 103 86" stroke="'+_sh(skin,-45)+'" stroke-width="1.8" fill="none" stroke-linecap="round"/><circle cx="80" cy="90" r="5.5" fill="#ff7b9c" opacity=".28"/><circle cx="120" cy="90" r="5.5" fill="#ff7b9c" opacity=".28"/>';
  /* دهان */
  var lip="#d6335a";
  if(mood==="wow")s+='<ellipse cx="100" cy="97" rx="5" ry="6" fill="#7a1f3a"/><ellipse cx="100" cy="99" rx="3" ry="2.2" fill="#ff8aa5"/>';
  else if(mood==="sad")s+='<path d="M92 99 Q100 92 108 99" stroke="'+lip+'" stroke-width="3" fill="none" stroke-linecap="round"/>';
  else s+='<path d="M90 94 Q100 106 110 94 Q100 98 90 94Z" fill="'+lip+'"/><path d="M92 96 Q100 102 108 96" fill="#fff" opacity=".85"/>';
  if(has("sunglasses")){s+='<g fill="#1b1b2b" stroke="#111" stroke-width="2"><path d="M74 70 L100 70 L98 84 Q86 90 76 82Z"/><path d="M100 70 L126 70 L124 82 Q114 90 102 84Z"/></g><path d="M98 72 L102 72" stroke="#111" stroke-width="2.5"/>';}
  if(has("glasses")){s+='<g fill="#ffffff22" stroke="#2d3142" stroke-width="2.4"><circle cx="87" cy="76" r="11"/><circle cx="113" cy="76" r="11"/></g><path d="M98 76 L102 76M76 74 L69 72M124 74 L131 72" stroke="#2d3142" stroke-width="2.2"/>';}
  /* موی جلو */
  s+='<path d="M68 76 Q64 34 100 32 Q138 34 132 76 Q128 56 112 50 Q92 56 74 60 Q70 66 68 76Z" fill="'+hair+'"/><path d="M74 58 Q88 46 112 50 Q96 48 84 60Z" fill="'+hairL+'" opacity=".5"/>';
  if(o.hair==="long")s+='<path d="M66 70 Q58 120 66 160 Q70 166 76 160 Q72 120 74 76Z" fill="'+hair+'"/><path d="M134 70 Q142 120 134 160 Q130 166 124 160 Q128 120 126 76Z" fill="'+hair+'"/>';
  if(o.hair==="bob")s+='<path d="M66 70 Q60 106 70 118 Q76 110 74 76Z" fill="'+hair+'"/><path d="M134 70 Q140 106 130 118 Q124 110 126 76Z" fill="'+hair+'"/>';
  /* کلاه و تاج و هدفون و هاله */
  if(has("beanie"))s+='<path d="M66 60 Q68 26 100 24 Q132 26 134 60 Z" fill="#ff8a3d"/><rect x="64" y="54" width="72" height="12" rx="6" fill="#e8741f"/><circle cx="100" cy="22" r="6" fill="#fff"/>';
  if(has("wizhat"))s+='<path d="M52 58 Q100 40 148 58 Q100 66 52 58Z" fill="#4b1d8f"/><path d="M72 54 Q92 4 128 -6 Q112 18 128 54Z" fill="#5b2fc4"/><path d="M76 50 Q100 58 124 50" stroke="#f4c430" stroke-width="4" fill="none"/><path d="M118 20 l2 5 5 1 -4 3 1 5 -4 -3 -4 3 1 -5 -4 -3 5 -1z" fill="#ffe27a"/>';
  if(has("crown"))s+='<path d="M72 40 L78 14 L90 30 L100 8 L110 30 L122 14 L128 40Z" fill="#f4c430" stroke="#c9a000" stroke-width="2" stroke-linejoin="round"/><circle cx="100" cy="30" r="3" fill="#e94f7a"/><circle cx="82" cy="34" r="2.2" fill="#2b9bd6"/><circle cx="118" cy="34" r="2.2" fill="#37b57a"/>';
  if(has("phones"))s+='<path d="M66 78 Q64 22 100 22 Q136 22 134 78" stroke="#2d3142" stroke-width="5" fill="none"/><rect x="58" y="70" width="12" height="22" rx="6" fill="#e94f7a"/><rect x="130" y="70" width="12" height="22" rx="6" fill="#e94f7a"/>';
  if(one==="space"&&false)s+='';
  var vb=view==="bust"?"46 4 108 128":"0 0 200 366";
  return '<svg class="av" viewBox="'+vb+'" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'+s+'</svg>';
}

/* صحنه‌ی خانه بر اساس سطح */
function sceneSVG(level){
  var h=level>=9?3:level>=7?2:level>=3?1:0, o='';
  var wall=['#3b2a66','#2c3e73','#245a5a','#6a3a5a'][h];
  o+='<rect width="360" height="400" fill="'+wall+'"/>';
  o+='<rect y="320" width="360" height="80" fill="'+(['#2a1d4a','#1f2c55','#183f3f','#4a2a40'][h])+'"/>';
  if(h===0){ /* اتاق اجاره‌ای: پنجره + تخت */
    o+='<rect x="236" y="60" width="90" height="110" rx="6" fill="#0d1b3d" stroke="#d9c7ff" stroke-width="4"/><path d="M281 60 V170 M236 115 H326" stroke="#d9c7ff" stroke-width="3"/><circle cx="262" cy="86" r="10" fill="#ffe27a"/><g fill="#fff"><circle cx="300" cy="140" r="1.6"/><circle cx="250" cy="150" r="1.4"/><circle cx="310" cy="80" r="1.4"/></g>';
    o+='<rect x="14" y="290" width="120" height="40" rx="8" fill="#5b4a8f"/><rect x="14" y="276" width="40" height="30" rx="8" fill="#e9e1ff"/><rect x="10" y="326" width="8" height="18" fill="#2a1d4a"/><rect x="130" y="326" width="8" height="18" fill="#2a1d4a"/>';
  }else if(h===1){ /* آپارتمان: مبل + گیاه + قاب */
    o+='<rect x="30" y="50" width="70" height="50" rx="4" fill="#0f1c3d" stroke="#f4c430" stroke-width="3"/><path d="M38 90 L56 66 L70 84 L82 72 L94 90Z" fill="#37b57a"/><circle cx="84" cy="66" r="5" fill="#ffe27a"/>';
    o+='<rect x="14" y="276" width="130" height="54" rx="12" fill="#c0392b"/><rect x="22" y="258" width="114" height="34" rx="12" fill="#d8503f"/><rect x="8" y="270" width="22" height="60" rx="8" fill="#a8301f"/><rect x="126" y="270" width="22" height="60" rx="8" fill="#a8301f"/>';
    o+='<rect x="300" y="262" width="26" height="40" rx="4" fill="#8a4b25"/><path d="M313 262 Q290 230 296 200 Q316 220 313 262Z M313 262 Q338 232 330 204 Q312 226 313 262Z" fill="#37b57a"/>';
  }else if(h===2){ /* ویلا: استخر + پنجره بزرگ */
    o+='<rect x="30" y="40" width="300" height="140" rx="8" fill="#7ad0ff"/><path d="M30 150 Q80 120 130 150 T230 150 T330 150 V180 H30Z" fill="#37b57a"/><circle cx="290" cy="76" r="16" fill="#ffe27a"/><path d="M180 40 V180 M30 110 H330" stroke="#f5f5f5" stroke-width="5"/>';
    o+='<rect x="0" y="326" width="360" height="74" fill="#1b9aaa"/><path d="M0 340 Q30 332 60 340 T120 340 T180 340 T240 340 T300 340 T360 340" stroke="#a5ecff" stroke-width="3" fill="none"/>';
  }else{ /* قصر: ستون + فرش */
    o+='<g fill="#f2e6c0"><rect x="14" y="40" width="34" height="300"/><rect x="312" y="40" width="34" height="300"/><rect x="8" y="30" width="46" height="14"/><rect x="306" y="30" width="46" height="14"/></g>';
    o+='<path d="M130 50 Q180 20 230 50 V150 H130Z" fill="#241046" stroke="#f4c430" stroke-width="4"/><circle cx="180" cy="90" r="14" fill="#ffe27a"/>';
    o+='<rect x="120" y="332" width="120" height="68" fill="#a3142f"/><path d="M120 332 H240" stroke="#f4c430" stroke-width="4"/>';
  }
  return '<svg class="scene" viewBox="0 0 360 400" preserveAspectRatio="xMidYMid slice">'+o+'</svg>';
}
