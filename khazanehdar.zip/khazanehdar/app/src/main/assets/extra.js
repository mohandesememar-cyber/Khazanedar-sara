"use strict";
/* ===== extra.js: صفحه‌ی خانه، بانک‌ها، گزارش (نمودارها و پیش‌بینی)، طلب/قسط، نرخ‌ها، ماشین‌حساب، درس روزانه ===== */
(function(){
  var c=document.createElement("style");
  c.textContent=[
  "#posBar{display:flex;gap:10px;align-items:center;background:linear-gradient(135deg,#ffffff22,#ffffff0d);border:1px solid var(--line);border-radius:20px;padding:8px 12px;margin-bottom:12px;cursor:pointer}",
  ".calcb{margin-right:8px;background:var(--card2);border:1px solid var(--line);border-radius:12px;font-size:20px;width:40px;height:40px;color:var(--text)}",
  ".ctypes{display:flex;gap:6px;overflow-x:auto;padding-bottom:6px;scrollbar-width:none}.ctypes::-webkit-scrollbar{display:none}",
  ".ctypes button,.cchips button{flex:0 0 auto;border:1px solid var(--line);background:var(--card);color:var(--text);border-radius:99px;padding:6px 12px;font-size:12.5px;font-family:inherit}",
  ".ctypes button.on{background:linear-gradient(135deg,#ffd54f,#ffb300);color:#3b2a00;font-weight:800;border-color:transparent}",
  ".cchips{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}.cchips button.off{opacity:.4;text-decoration:line-through}",
  ".chartbox svg{width:100%;height:auto;display:block;direction:ltr}.chartbox text{fill:#e9e2ff;font-size:9px;font-family:inherit}",
  ".fc{border:1px dashed var(--line);border-radius:18px;padding:10px 12px;margin-bottom:12px;background:linear-gradient(135deg,#9b7bff22,#2dd4bf11)}",
  ".fc table{width:100%;border-collapse:collapse;font-size:13px}.fc td{padding:3px 0}.fc td:last-child{text-align:left}",
  ".stat[data-tot]{cursor:pointer}.rt[data-rt]{cursor:pointer}",
  ".calc{direction:ltr}.calc .disp{background:#0004;border-radius:16px;padding:12px;text-align:right;min-height:74px;word-break:break-all}.calc .disp .ex{font-size:14px;opacity:.7;min-height:20px}.calc .disp .rs{font-size:28px;font-weight:800}",
  ".calc .kp{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px}.calc .kp button{height:52px;border-radius:14px;border:1px solid var(--line);background:var(--card2);color:var(--text);font-size:20px;font-family:inherit}",
  ".calc .kp button.op{background:#9b7bff44}.calc .kp button.eq{background:linear-gradient(135deg,#ffd54f,#ffb300);color:#3b2a00;font-weight:800}",
  ".lesson{border-radius:20px;padding:12px 14px;margin-bottom:12px;background:linear-gradient(135deg,#ffd54f26,#ff98001a);border:1px solid #ffd54f55}",
  ".lesson .lt{font-weight:800;margin-bottom:4px}.lesson .lw{font-size:11.5px;opacity:.75;margin-top:6px}",
  ".gcard .gav{width:84px;height:84px;flex:0 0 84px;border-radius:50%;overflow:hidden;background:radial-gradient(circle at 50% 60%,#ffffff33,transparent 70%)}",
  "details.grp{border-bottom:1px dashed var(--line);padding:6px 0}details.grp summary{cursor:pointer;display:flex;justify-content:space-between;gap:8px}"
  ].join("\n");
  document.head.appendChild(c);
})();

function avg(a){return a.length?a.reduce(function(x,y){return x+y},0)/a.length:0}
function shortN(n){
  var a=Math.abs(n);
  if(a>=1e9)return faN((n/1e9).toFixed(1).replace(/\.0$/,""))+"م‌م";
  if(a>=1e6)return faN((n/1e6).toFixed(1).replace(/\.0$/,""))+"م";
  if(a>=1e3)return faN(Math.round(n/1e3))+"ه";
  return faN(Math.round(n));
}
function lbl(t,n){t=String(t);return t.length>n?t.slice(0,n-1)+"…":t}

/* ---------- نمودارها ---------- */
var CHARTS=[["donut","🍩","دونات"],["pie","🥧","دایره‌ای"],["hbar","📊","میله‌ای"],["col","📶","ستونی"],["daily","📈","روزانه (دخل و خرج)"],["six","🗓️","۶ ماه اخیر"]];
function isOff(k,c){return !!(G.chartOff&&G.chartOff[k+":"+c])}
function pieSvg(data,total){
  var cx=50,cy=50,r=46,a0=-Math.PI/2,h='<svg viewBox="0 0 100 100" style="max-width:220px;margin:auto">';
  if(data.length===1)h+='<circle cx="50" cy="50" r="46" fill="'+COLORS[0]+'"/>';
  else data.forEach(function(d,i){
    var a1=a0+2*Math.PI*d[1]/total,x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1);
    h+='<path d="M50 50 L'+x0.toFixed(2)+' '+y0.toFixed(2)+' A46 46 0 '+(a1-a0>Math.PI?1:0)+' 1 '+x1.toFixed(2)+' '+y1.toFixed(2)+'Z" fill="'+COLORS[i%COLORS.length]+'" stroke="#150b33" stroke-width=".8"/>';
    a0=a1;
  });
  return h+'</svg>';
}
function colSvg(data){
  var d=data.slice(0,7),mx=Math.max.apply(null,d.map(function(r){return r[1]}))||1,W=320,H=190,bw=34,gap=(W-d.length*bw)/(d.length+1),h='<svg viewBox="0 0 '+W+' '+H+'">';
  d.forEach(function(r,i){
    var bh=Math.max(3,(r[1]/mx)*120),x=gap+i*(bw+gap),y=150-bh;
    h+='<rect x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+bw+'" height="'+bh.toFixed(1)+'" rx="6" fill="'+COLORS[i%COLORS.length]+'"/>'+
      '<text x="'+(x+bw/2).toFixed(1)+'" y="'+(y-4).toFixed(1)+'" text-anchor="middle">'+shortN(r[1])+'</text>'+
      '<text x="'+(x+bw/2).toFixed(1)+'" y="165" text-anchor="middle">'+esc(lbl(r[0],7))+'</text>';
  });
  return h+'</svg>';
}
function dailySvg(){
  var L=mlen(S.y,S.m),I=[],O=[],i;
  for(i=0;i<=L;i++){I.push(0);O.push(0)}
  S.tx.forEach(function(t){
    var c=t.category||"بدون دسته";
    if(isOff(t.kind,c))return;
    var d=jOf(t.ts)[2];
    if(t.kind==="in")I[d]+=t.amount;else O[d]+=t.amount;
  });
  var mx=Math.max(1,Math.max.apply(null,I),Math.max.apply(null,O)),W=320,H=190,px=function(d){return 14+(d-1)*(W-28)/(L-1)},py=function(v){return 150-(v/mx)*125};
  function path(a){var p="";for(var d=1;d<=L;d++)p+=(d===1?"M":"L")+px(d).toFixed(1)+" "+py(a[d]).toFixed(1)+" ";return p}
  var h='<svg viewBox="0 0 '+W+' '+H+'"><line x1="10" y1="150" x2="'+(W-6)+'" y2="150" stroke="#fff3"/>';
  h+='<path d="'+path(I)+'" fill="none" stroke="#2dd4bf" stroke-width="2.4" stroke-linejoin="round"/><path d="'+path(O)+'" fill="none" stroke="#ff6b8b" stroke-width="2.4" stroke-linejoin="round"/>';
  for(i=1;i<=L;i+=5)h+='<text x="'+px(i).toFixed(1)+'" y="165" text-anchor="middle">'+faN(i)+'</text>';
  h+='<text x="14" y="14" fill="#2dd4bf" style="fill:#2dd4bf">● دخل</text><text x="70" y="14" style="fill:#ff6b8b">● خرج</text><text x="'+(W-6)+'" y="14" text-anchor="end">اوج: '+shortN(mx)+'</text>';
  return h+'</svg>';
}
function sixSvg(){
  var tr=J(A.trend(S.y,S.m,6))||[],mx=Math.max.apply(null,[1].concat(tr.map(function(x){return Math.max(x.in,x.out)}))),W=320,H=190,gw=W/Math.max(1,tr.length),h='<svg viewBox="0 0 '+W+' '+H+'"><line x1="6" y1="150" x2="'+(W-6)+'" y2="150" stroke="#fff3"/>';
  tr.forEach(function(x,i){
    var x0=i*gw+gw/2,bi=(x.in/mx)*120,bo=(x.out/mx)*120;
    h+='<rect x="'+(x0-17)+'" y="'+(150-bi)+'" width="16" height="'+Math.max(2,bi)+'" rx="4" fill="#2dd4bf"/><rect x="'+(x0+1)+'" y="'+(150-bo)+'" width="16" height="'+Math.max(2,bo)+'" rx="4" fill="#ff6b8b"/>'+
      '<text x="'+x0+'" y="165" text-anchor="middle">'+MONTHS[x.m-1]+'</text><text x="'+(x0-9)+'" y="'+(146-bi)+'" text-anchor="middle">'+shortN(x.in)+'</text><text x="'+(x0+9)+'" y="'+(146-bo)+'" text-anchor="middle" style="fill:#ffc2cf">'+shortN(x.out)+'</text>';
  });
  h+='<text x="14" y="14" style="fill:#2dd4bf">● دخل</text><text x="70" y="14" style="fill:#ff6b8b">● خرج</text>';
  return h+'</svg>';
}
function chartHtml(s){
  var ct=S.ctype||"donut";
  if(ct==="daily")return '<div class="chartbox">'+dailySvg()+'</div>';
  if(ct==="six")return '<div class="chartbox">'+sixSvg()+'<div class="mut" style="font-size:11.5px">این نمودار همه‌ی تراکنش‌های ماه رو بدون فیلتر دسته‌ها نشون می‌ده.</div></div>';
  var k=S.rtab==="out"?"out":"in";
  var data=sortedObj(k==="out"?s.cats:s.srcs).filter(function(r){return !isOff(k,r[0])});
  var total=data.reduce(function(a,r){return a+r[1]},0);
  if(!data.length)return '<div class="empty"><div>همه‌ی دسته‌ها خاموشن یا داده‌ای نیست.</div></div>';
  if(ct==="donut")return '<div class="donut">'+donut(data,total)+'<div class="legend">'+data.slice(0,6).map(function(r,i){return '<div><i style="background:'+COLORS[i%COLORS.length]+'"></i>'+esc(r[0])+'</div>'}).join("")+'</div></div>';
  if(ct==="pie")return '<div class="chartbox">'+pieSvg(data,total)+'<div class="legend" style="margin-top:8px">'+data.slice(0,8).map(function(r,i){return '<div><i style="background:'+COLORS[i%COLORS.length]+'"></i>'+esc(r[0])+' '+faN(Math.round(r[1]*100/total))+'٪</div>'}).join("")+'</div></div>';
  if(ct==="col")return '<div class="chartbox">'+colSvg(data)+'</div>';
  return data.map(function(r,idx){
    var p=total?Math.round(r[1]*100/total):0;
    return '<div class="cat"><div class="row sp"><b>'+icon(r[0])+' '+esc(r[0])+'</b><span>'+fa(r[1])+' <span class="mut">('+faN(p)+'٪)</span></span></div><div class="bar"><i style="width:'+Math.max(p,3)+'%;background:'+COLORS[idx%COLORS.length]+'"></i></div></div>';
  }).join("");
}
function chipsOff(s){
  var h='<div class="mut" style="font-size:12px;margin-top:6px">دسته‌ای رو که نمی‌خوای توی نمودار حساب بشه خاموش کن (فقط نمودار رو تغییر می‌ده):</div><div class="cchips">';
  function add(k,obj){sortedObj(obj).forEach(function(r){h+='<button data-coff="'+k+':'+esc(r[0])+'" class="'+(isOff(k,r[0])?"off":"")+'">'+icon(r[0])+' '+esc(r[0])+'</button>'})}
  var ct=S.ctype||"donut";
  if(ct==="six")return "";
  if(ct==="daily"){add("out",s.cats);add("in",s.srcs)}
  else add(S.rtab==="out"?"out":"in",S.rtab==="out"?s.cats:s.srcs);
  return h+'</div>';
}

/* ---------- پیش‌بینی پایان ماه ---------- */
function forecastCard(s){
  var now=todayJ();
  if(S.y!==now[0]||S.m!==now[1])return "";
  var L=mlen(S.y,S.m),d=Math.max(1,now[2]),w=Math.min(1,d/L);
  var tr=J(A.trend(S.y,S.m,4))||[],prev=tr.slice(0,-1).filter(function(x){return x.in||x.out});
  var aI=prev.length?avg(prev.map(function(x){return x.in})):null,aO=prev.length?avg(prev.map(function(x){return x.out})):null;
  function proj(so,av){var run=so/d*L,f=av==null?run:(w*run+(1-w)*av);return Math.max(so,Math.round(f))}
  var fi=proj(s.i,aI),fo=proj(s.o,aO),net=fi-fo;
  var ni=prev.length?Math.round(avg(prev.map(function(x){return x.in}).concat([fi]))):null,no=prev.length?Math.round(avg(prev.map(function(x){return x.out}).concat([fo]))):null;
  var h='<div class="fc"><b>🔮 پیش‌بینی خزانه‌دار</b><table>'+
    '<tr><td>دخل تا آخر این ماه</td><td><b class="in">≈ '+fa(fi)+'</b></td></tr>'+
    '<tr><td>خرج تا آخر این ماه</td><td><b class="out">≈ '+fa(fo)+'</b></td></tr>'+
    '<tr><td>تراز پایان ماه</td><td><b class="'+(net>=0?"gold":"out")+'">'+(net>=0?"+":"−")+fa(Math.abs(net))+'</b></td></tr>';
  if(ni!=null)h+='<tr><td>ماه بعد (تخمین)</td><td>دخل ≈ '+fa(ni)+' • خرج ≈ '+fa(no)+'</td></tr>';
  return h+'</table><div class="mut" style="font-size:11.5px;margin-top:4px">بر پایه‌ی سرعت فعلی خرج و دخل و میانگین ماه‌های قبلت. حدودیه، نه قطعی.</div></div>';
}

/* ---------- جزئیات مجموع‌ها ---------- */
function openTotals(kind){
  var rows=S.tx.filter(function(t){return t.kind===kind}),g={},total=0;
  rows.forEach(function(t){var c=t.category||"بدون دسته";(g[c]=g[c]||{sum:0,list:[]});g[c].sum+=t.amount;g[c].list.push(t);total+=t.amount});
  var keys=Object.keys(g).sort(function(a,b){return g[b].sum-g[a].sum});
  var h='<h3>'+(kind==="in"?"🪙 دخل ":"💸 خرج ")+MONTHS[S.m-1]+' — '+fa(total)+' تومان</h3><div class="mut">'+faN(rows.length)+' تراکنش؛ روی هر دسته بزن تا ببینی شامل چیه.</div><div class="card" style="margin-top:8px">';
  if(!keys.length)h+='<div class="mut">چیزی نیست.</div>';
  keys.forEach(function(k){
    h+='<details class="grp"><summary><b>'+icon(k)+' '+esc(k)+'</b><span>'+fa(g[k].sum)+' <span class="mut">('+faN(g[k].list.length)+')</span></span></summary>'+g[k].list.map(txRow).join("")+'</details>';
  });
  openSheet(h+'</div>');
  document.querySelectorAll("#sheet .tx[data-id]").forEach(function(e){e.onclick=function(){openTx(+e.dataset.id)}});
}
function openBankTotals(){
  var l=S.banks.filter(function(b){return b.balance!=null}).sort(function(a,b){return b.balance-a.balance}),t=0;
  l.forEach(function(b){t+=b.balance});
  var h='<h3>🏦 جمع موجودی: '+fa(t)+' تومان</h3><div class="card">';
  l.forEach(function(b){
    var p=t?Math.max(2,Math.round(b.balance*100/t)):0;
    h+='<div class="cat"><div class="row sp"><b>'+esc(b.bank)+(b.acct?" • "+faN(b.acct):"")+'</b><span>'+fa(b.balance)+'</span></div><div class="bar"><i style="width:'+p+'%;background:var(--gold)"></i></div></div>';
  });
  if(!l.length)h+='<div class="mut">هنوز مانده‌ای از پیامک‌ها نخوندم.</div>';
  openSheet(h+'</div>');
}

/* ---------- خانه ---------- */
function gameCard(){
  var g=getGame();if(!g)return "";
  var lv=g.level,left=lv>=10?"سطح آخر!":faN(g.next-g.xp)+" امتیاز تا سطح بعد";
  return '<div class="card gcard"><div class="row" style="align-items:center"><div class="gav" data-go="room">'+girl("happy","bust")+'</div>'+
    '<div style="flex:1;min-width:0"><b>'+esc(G.name)+'</b> <span class="mut">سارا سکه می‌خواد 😂</span> <span class="badge b-ok">سطح '+faN(lv)+'</span> '+coinsHtml()+
    '<div class="mut">'+esc(JOBS[lv-1])+' • '+esc(HOUSES[lv-1])+'</div>'+
    '<div class="xpbar"><i style="width:'+Math.max(4,g.prog)+'%"></i></div><div class="mut">'+faN(g.xp)+' امتیاز • '+left+' • 🔥 '+faN(g.streak)+' روز</div></div></div>'+
    '<div class="row" style="margin-top:10px;flex-wrap:wrap"><button class="btn sm gold" data-go="room">🏠 دنیای سارا</button><button class="btn sm" data-go="missions">🎯 ماموریت‌ها</button><button class="btn sm" data-go="games">🎮 بازی</button><button class="btn sm" data-go="wardrobe">👗 کمد</button></div></div>';
}
function renderPosBar(){
  var el=document.getElementById("posBar");if(!el)return;
  if(!S.posMsg)S.posMsg=R(POS);
  el.innerHTML='<div class="pbav">'+girl("happy","bust")+'</div><div class="pbt">'+S.posMsg+'</div>';
  el.onclick=function(){S.posMsg=R(POS);renderPosBar();speak()};
}
function viewHome(){
  var s=sums();
  var h='<div id="posBar"></div>';
  h+=gameCard();
  if(S.unk.length){
    h+='<div class="card pend"><b>🏦 این شماره‌ها کدوم بانکن؟</b><div class="mut" style="margin:4px 0 8px">یه بار بگو تا برای همیشه بشناسمشون.</div>';
    S.unk.slice(0,3).forEach(function(u){
      h+='<div class="row sp" style="margin:6px 0"><span>'+esc(u.addr)+' <span class="mut">('+faN(u.count)+' پیامک)</span></span><button class="btn sm" data-askbank="'+esc(u.addr)+'">بانکش چیه؟</button></div>';
    });
    h+='</div>';
  }
  if(S.pend.length){
    h+='<div class="card pend"><div class="row sp"><b>🧐 '+faN(S.pend.length)+' تراکنش منتظر توضیحه</b></div><div class="mut" style="margin:2px 0 4px">از تازه‌ترین شروع می‌کنیم؛ فقط تا آخر همون ماه فرصت داری.</div>';
    S.pend.slice(0,3).forEach(function(t){h+=txRow(t)});
    if(S.pend.length>3)h+='<button class="btn sm ghost full" id="allPend" style="margin-top:8px">نمایش همه ('+faN(S.pend.length)+')</button>';
    h+='</div>';
  }
  h+=monthNav();
  h+='<div class="stats"><div class="stat i" data-tot="in"><div class="mut">دخل 🪙</div><div class="big in">'+fa(s.i)+'</div><div class="mut">تومان • ببین شامل چیه 👆</div></div>'+
     '<div class="stat o" data-tot="out"><div class="mut">خرج 💸</div><div class="big out">'+fa(s.o)+'</div><div class="mut">تومان • ببین شامل چیه 👆</div></div>'+
     '<div class="stat net"><div class="mut">'+(s.i>=s.o?"پس‌انداز این ماه ✨":"کسری این ماه 🕳️")+'</div><div class="big '+(s.i>=s.o?"gold":"out")+'">'+fa(s.i-s.o)+' تومان</div></div></div>';
  h+=lessonCard();
  h+='<h2 class="s">آخرین ماجراها</h2><div class="card">';
  var rec=S.tx.slice(0,8);
  h+=rec.length?rec.map(txRow).join(""):'<div class="empty">'+girl("happy","bust")+'<div>اینجا هنوز خالیه. با دکمه‌ی ＋ خودت یه چیزی ثبت کن!</div></div>';
  h+='</div><div class="mut" style="text-align:center">نکته: روی هر تراکنش انگشتت رو نگه دار تا گزینه‌های ویرایش، حذف و شماره‌ی فرستنده رو ببینی.</div>';
  return h;
}

/* ---------- بانک‌ها ---------- */
function viewBanks(){
  var list=S.banks.slice().sort(function(a,b){return (b.balance==null?-Infinity:b.balance)-(a.balance==null?-Infinity:a.balance)}),total=0;
  list.forEach(function(b){if(b.balance!=null)total+=b.balance});
  S.banks=list;
  var h='<div class="hero">'+girl("happy","bust")+'<div class="bubble">'+(list.length?"این هم موجودی حساب‌هات؛ از بیشترین به کمترین. از آخرین «مانده»‌ی پیامک‌ها برداشتم 🏦":"هنوز پیامک بانکی‌ای ندیدم. اجازه‌ی پیامک رو بده و پیامک‌های قدیمی رو بخون.")+'</div></div>';
  if(list.length)h+='<div class="stat net" id="bkTotal" style="margin-bottom:12px;cursor:pointer"><div class="mut">جمع موجودی • بزن تا ببینی کدوم بانک چقدره 👆</div><div class="big gold">'+fa(total)+' تومان</div></div>';
  list.forEach(function(b,i){
    var nm=b.bank+(b.acct?" • "+faN(b.acct):"");
    h+='<div class="bankcard" data-bank="'+i+'"><div class="bi">🏦</div><div style="flex:1;min-width:0"><b>'+esc(nm)+'</b><div class="mut">'+faN(b.count)+' تراکنش'+(b.balTs?' • آخرین مانده: '+fmtDay(b.balTs):'')+'</div></div>'+
      '<div style="text-align:left">'+(b.balance!=null?'<b class="gold">'+fa(b.balance)+'</b><div class="mut" style="font-size:11px">تومان</div>':'<span class="mut">مانده‌ای ندیدم</span>')+'</div></div>';
    if(b.bank==="بانک نامشخص")h+='<div style="margin:-4px 0 10px"><button class="btn sm gold" data-unkbank="1">این‌ها کدوم بانکن؟</button></div>';
  });
  h+='<div class="mut" style="text-align:center">روی هر بانک بزن تا آخرین تراکنش‌هاش رو ببینی. شماره‌های مسدودشده اینجا حساب نمی‌شن.</div>';
  return h;
}

/* ---------- گزارش ---------- */
function viewReport(){
  var s=sums(),h=monthNav();
  h+='<div class="stats"><div class="stat i" data-tot="in"><div class="mut">مجموع دخل</div><div class="big in">'+fa(s.i)+'</div><div class="mut">تومان • ببین شامل چیه 👆</div></div><div class="stat o" data-tot="out"><div class="mut">مجموع خرج</div><div class="big out">'+fa(s.o)+'</div><div class="mut">تومان • ببین شامل چیه 👆</div></div></div>';
  h+=forecastCard(s);
  h+='<div class="card"><b>📄 خروجی آمار این ماه</b><div class="mut" style="margin:4px 0 8px">PDF و Word شامل دخل‌وخرج، دسته‌ها و موجودی هر بانک. سر هر ماه هم خودکار ساخته می‌شه.</div><button class="btn gold full" id="expRep">ساخت PDF و Word</button></div>';
  h+='<div class="ctypes">'+CHARTS.map(function(c){return '<button data-ct="'+c[0]+'" class="'+((S.ctype||"donut")===c[0]?"on":"")+'">'+c[1]+' '+c[2]+'</button>'}).join("")+'</div>';
  var ct=S.ctype||"donut";
  if(ct!=="daily"&&ct!=="six")h+='<div class="tabs-sub"><button data-r="out" class="'+(S.rtab==="out"?"on":"")+'">خرج‌ها کجا رفتن؟</button><button data-r="in" class="'+(S.rtab==="in"?"on":"")+'">پول از کجا اومد؟</button></div>';
  h+='<div class="card">';
  if(!S.tx.length)h+='<div class="empty">'+girl("wow","bust")+'<div>داده‌ای برای این ماه نیست.</div></div>';
  else h+=chartHtml(s)+chipsOff(s);
  h+='</div>';
  if(s.i||s.o){
    var r=J(A.suggest(S.y,S.m))||{sug:[]};
    var verdict=s.i>=s.o?"آفرین! این ماه "+fa(s.i-s.o)+" تومان جلو افتادی 🎉":"این ماه "+fa(s.o-s.i)+" تومان بیشتر خرج کردی. اشکالی نداره، ماه بعد جبران می‌کنیم 💪";
    h+='<div class="card hero" style="align-items:center">'+girl(s.i>=s.o?"happy":"sad","bust")+'<div class="bubble" style="margin:0">'+verdict+'</div></div>';
    h+='<h2 class="s">💡 پیشنهاد خزانه‌دار</h2><div class="card">';
    if(r.sug&&r.sug.length){
      r.sug.forEach(function(o){
        h+='<div class="sug">'+icon(o.cat)+' برای «<b>'+esc(o.cat)+'</b>» '+fa(o.spent)+' تومان خرج کردی. برای رسیدن به ۲۰٪ پس‌انداز، <b>'+faN(o.pct)+'٪</b> کمش کن؛ ماهی <b class="in">'+fa(o.save)+'</b> تومان بیشتر پس‌انداز می‌کنی.</div>';
      });
      h+='<div class="sug"><b>جمعاً:</b> با همین چند تغییر ماهی <b class="gold">'+fa(r.totalSave)+'</b> و سالی <b class="gold">'+fa(r.yearSave)+'</b> تومان بیشتر توی جیبته 🐷</div>';
    }else h+='<div class="mut">'+(s.i>0?'پس‌اندازت به هدف ۲۰٪ رسیده یا خرج اختیاری قابل‌توجهی نمی‌بینم. آفرین 👏':'برای پیشنهاد دقیق، دخل‌ها رو هم ثبت کن.')+'</div>';
    (r.tips||[]).forEach(function(t){h+='<div class="sug">'+t.icon+' <b>'+esc(t.title)+':</b> '+esc(t.text)+'</div>'});
    h+='<div class="mut" style="font-size:11.5px;margin-top:6px">پیشنهادها بر پایه‌ی اصول رایج مدیریت مالی شخصی هستن و فقط از «خواسته‌ها» کم می‌کنن؛ توصیه‌ی سرمایه‌گذاری تخصصی نیستن.</div></div>';
  }
  h+=lessonCard();
  var lim=S.lim||40;
  h+='<h2 class="s">همه‌ی تراکنش‌های ماه</h2><div class="card">'+(S.tx.length?S.tx.slice(0,lim).map(txRow).join(""):'<div class="mut" style="text-align:center">خالیه</div>')+
    (S.tx.length>lim?'<button class="btn ghost full" id="moreTx" style="margin-top:8px">نمایش بیشتر ('+faN(S.tx.length-lim)+' تای دیگه)</button>':'')+'</div>';
  return h;
}

/* ---------- درس مالی روزانه ---------- */
function pickLesson(next){
  if(S.lesson&&!next)return S.lesson;
  var L=(window.CONTENT&&CONTENT.lessons)||[];if(!L.length)return null;
  var seen=G.lessonSeen||[],un=L.filter(function(l){return seen.indexOf(l.id)<0});
  if(!un.length){seen=[];un=L}
  var l=R(un);seen.push(l.id);G.lessonSeen=seen.slice(-200);gSave();S.lesson=l;return l;
}
function lessonText(l){return l.title+"\n"+l.text+"\n— "+l.who}
function lessonCard(){
  var l=pickLesson();if(!l)return "";
  var saved=(G.lessonsSaved||[]).indexOf(l.id)>=0;
  return '<div class="lesson"><div class="lt">📘 درس مالی امروز: '+esc(l.title)+'</div><div style="line-height:1.9;font-size:13.5px">'+esc(l.text)+'</div><div class="lw">'+esc(l.who)+' • '+esc(CONTENT.disclaimer||"")+'</div>'+
    '<div class="row" style="margin-top:8px;flex-wrap:wrap"><button class="btn sm gold" data-ls="save">'+(saved?"✅ ذخیره شده":"💾 ذخیره")+'</button><button class="btn sm" data-ls="copy">📋 کپی</button><button class="btn sm ghost" data-ls="next">درس بعدی</button><button class="btn sm ghost" data-ls="list">ذخیره‌شده‌ها ('+faN((G.lessonsSaved||[]).length)+')</button></div></div>';
}
function openSavedLessons(){
  var L=(window.CONTENT&&CONTENT.lessons)||[],ids=G.lessonsSaved||[];
  var h='<h3>💾 درس‌های ذخیره‌شده</h3>';
  if(!ids.length)h+='<div class="mut">هنوز چیزی ذخیره نکردی.</div>';
  ids.forEach(function(id,i){
    var l=L.filter(function(x){return x.id===id})[0];if(!l)return;
    h+='<div class="lesson"><div class="lt">'+esc(l.title)+'</div><div style="line-height:1.9;font-size:13.5px">'+esc(l.text)+'</div><div class="lw">'+esc(l.who)+'</div><div class="row" style="margin-top:6px"><button class="btn sm" data-lc="'+i+'">📋 کپی</button><button class="btn sm ghost" data-ld="'+i+'">حذف</button></div></div>';
  });
  openSheet(h);
  document.querySelectorAll("[data-lc]").forEach(function(b){b.onclick=function(){var l=L.filter(function(x){return x.id===ids[+b.dataset.lc]})[0];A.copyText(lessonText(l));toast("کپی شد 📋")}});
  document.querySelectorAll("[data-ld]").forEach(function(b){b.onclick=function(){G.lessonsSaved.splice(+b.dataset.ld,1);gSave();openSavedLessons();render()}});
}

/* ---------- طلب‌ها ---------- */
function counted(d){return d.mine>0?d.mine:d.amount}
function viewDebtList(){
  var open=S.debts.filter(function(d){return !d.paid}),done=S.debts.filter(function(d){return d.paid});
  var total=open.reduce(function(a,d){return a+counted(d)},0);
  var h='<div class="hero">'+girl(open.length?"wow":"happy","bust")+'<div class="bubble">'+(open.length?"جمعاً "+fa(total)+" تومان (سهم خودت) از مردم طلب داری. بریم پول‌ها رو از دل‌شون دربیاریم! 🕵️":"کسی بهت بدهکار نیست. یا همه آدم‌های خوبی‌ان یا هنوز ثبت نکردی 😄")+'</div></div>';
  h+='<button class="btn gold full" id="addDebt" style="margin-bottom:12px">＋ از کی طلب دارم؟</button>';
  var all=open.map(function(d){return {d:d,s:debtStatus(d)}}).sort(function(a,b){return a.s.sort-b.s.sort||a.d.due-b.d.due});
  if(all.length){
    h+='<div class="card">';
    all.forEach(function(x){
      var d=x.d;
      h+='<div class="tx"><div class="ico">👤</div><div class="m"><b>'+esc(d.name)+'</b><span class="mut">موعد: '+fmtDay(d.due)+(d.note?' • '+esc(d.note):'')+(d.mine>0?' • سهم من: '+fa(d.mine):'')+'</span></div>'+
        '<div style="text-align:left"><b class="gold">'+fa(d.amount)+'</b><div><span class="badge '+x.s.cls+'">'+x.s.txt+'</span></div></div></div>'+
        '<div class="row" style="padding:2px 0 10px;flex-wrap:wrap"><button class="btn sm" data-pay="'+d.id+'">پرداخت کرد ✅</button><button class="btn sm gold" data-dinv="'+d.id+'">🧾 فاکتور</button><button class="btn sm" data-edd="'+d.id+'">✏️ ویرایش</button><button class="btn sm ghost" data-del="'+d.id+'">حذف</button></div>';
    });
    h+='</div>';
  }
  if(done.length)h+='<h2 class="s">تسویه‌شده‌ها</h2><div class="card">'+done.map(function(d){
    return '<div class="tx"><div class="ico">✅</div><div class="m"><b>'+esc(d.name)+'</b><span class="mut">'+fmtDay(d.due)+'</span></div><b>'+fa(d.amount)+'</b><button class="btn sm ghost" data-del="'+d.id+'">حذف</button></div>';
  }).join("")+'</div>';
  h+='<div class="mut" style="text-align:center;margin-top:8px">هر روز در ساعتی که توی «تنظیم» انتخاب کردی، تا وقتی پول نیومده یادآوری می‌کنم 😈</div>';
  return h;
}
function viewInstList(){
  var open=S.insts.filter(function(d){return !d.done}),done=S.insts.filter(function(d){return d.done});
  var next=open.length?open[0]:null;
  var h='<div class="hero">'+girl(open.length?"wow":"happy","bust")+'<div class="bubble">'+(next?("نزدیک‌ترین قسط: «"+esc(next.title)+"» — "+instStatus(next).txt+". یه اعلان همیشگی هم تو نوار اعلان‌ها می‌ذارم که یادت نره 🔔"):"قسطی ثبت نکردی. خوش‌به‌حالت! یا شایدم یادت رفته 😄")+'</div></div>';
  h+='<button class="btn gold full" id="addInst" style="margin-bottom:12px">＋ ثبت قسط</button>';
  var all=open.map(function(d){return {d:d,s:instStatus(d)}}).sort(function(a,b){return a.d.due-b.d.due});
  if(all.length){
    h+='<div class="card">';
    all.forEach(function(x){
      var d=x.d,rep=d.rep?("هر ماه"+(d.left>0?" • "+faN(d.left)+" قسط مونده":"")):"یک‌باره";
      h+='<div class="tx"><div class="ico">🧾</div><div class="m"><b>'+esc(d.title)+'</b><span class="mut">موعد: '+fmtDay(d.due)+' • '+rep+'</span></div>'+
        '<div style="text-align:left"><b class="gold">'+fa(d.amount)+'</b><div><span class="badge '+x.s.cls+'">'+x.s.txt+'</span></div></div></div>'+
        '<div class="row" style="padding:2px 0 10px;flex-wrap:wrap"><button class="btn sm" data-paynst="'+d.id+'">پرداخت کردم ✅</button><button class="btn sm" data-edin="'+d.id+'">✏️ ویرایش</button><button class="btn sm ghost" data-delinst="'+d.id+'">حذف</button></div>';
    });
    h+='</div>';
  }
  if(done.length)h+='<h2 class="s">تمام‌شده‌ها</h2><div class="card">'+done.map(function(d){
    return '<div class="tx"><div class="ico">✅</div><div class="m"><b>'+esc(d.title)+'</b></div><button class="btn sm ghost" data-delinst="'+d.id+'">حذف</button></div>';
  }).join("")+'</div>';
  h+='<div class="mut" style="text-align:center;margin-top:8px">از یک هفته قبل از موعد هر روز یادآوری می‌کنم؛ روز موعد هم می‌گم «پرداخت کن!»</div>';
  return h;
}
function openDebtForm(d){
  d=(d&&d.id!==undefined)?d:null;
  var nxt=d?jOf(d.due):plusDays(todayJ(),7);
  openSheet('<h3>'+(d?"ویرایش طلب ✏️":"طلب جدید 💰")+'</h3><div class="mut">اسم بدهکار و مبلغ رو بنویس، بعد بگو کی باید پول رو بده. مبلغ می‌تونه صفر هم باشه.</div>'+
    '<label>اسم بدهکار</label><input id="dn" value="'+esc(d?d.name:"")+'" placeholder="مثلاً: آقای رضایی">'+
    '<label>چقدر باید بده؟ (تومان)</label><input id="da" inputmode="numeric" value="'+(d&&d.amount?fa(d.amount):"")+'" placeholder="۰">'+
    '<label>چقدرش مال خودته؟ (اختیاری)</label><input id="dm" inputmode="numeric" value="'+(d&&d.mine?fa(d.mine):"")+'" placeholder="خالی = همه‌ش مال منه">'+
    '<div class="mut" style="font-size:12px">اگه بخشی از این پول مال تو نیست (مثلاً امانته)، سهم خودت رو بنویس؛ فقط همون توی جمع طلب‌ها حساب می‌شه.</div>'+
    '<label>کی باید پول رو بده؟ 📅</label>'+dateSelects("dd",nxt)+
    '<label>توضیح (اختیاری)</label><input id="dt" value="'+esc(d?d.note:"")+'" placeholder="بابت چی؟">'+
    '<button class="btn gold full" id="sv" style="margin-top:16px">'+(d?"ذخیره‌ی تغییرات":"ثبت کن؛ از این به بعد من پیگیری می‌کنم 😈")+'</button>');
  money($("da"));money($("dm"));
  $("sv").onclick=function(){
    var n=$("dn").value.trim();
    if(!n){toast("اسم بدهکار رو بنویس 🙃");return}
    var a=String(parseNum($("da").value)||0),m=String(parseNum($("dm").value)||0);
    if(d)A.updateDebt(String(d.id),n,a,readDate("dd"),$("dt").value.trim(),m);
    else A.addDebt2(n,a,readDate("dd"),$("dt").value.trim(),m);
    closeSheet();toast(d?"ذخیره شد ✅":"ثبت شد. تا پول نیاد ول‌کن نیستم!");render();
  };
}
function openInstForm(d){
  d=(d&&d.id!==undefined)?d:null;
  var nxt=d?jOf(d.due):plusDays(todayJ(),30);
  openSheet('<h3>'+(d?"ویرایش قسط ✏️":"ثبت قسط 🧾")+'</h3><div class="mut">موعد قسط رو بنویس؛ از یک هفته قبل هر روز یادآوری می‌کنم. مبلغ می‌تونه صفر هم باشه.</div>'+
    '<label>عنوان قسط</label><input id="it" value="'+esc(d?d.title:"")+'" placeholder="مثلاً: قسط وام ماشین">'+
    '<label>مبلغ هر قسط (تومان)</label><input id="ia" inputmode="numeric" value="'+(d&&d.amount?fa(d.amount):"")+'" placeholder="۰">'+
    '<label>موعد قسط بعدی 📅</label>'+dateSelects("id",nxt)+
    '<div class="switch" style="margin-top:12px"><input type="checkbox" id="irep" style="width:22px;height:22px" '+((!d||d.rep)?"checked":"")+'><label style="margin:0">هر ماه تکرار بشه</label></div>'+
    '<label>چند قسط مونده؟ (۰ = نامحدود)</label><input id="il" inputmode="numeric" value="'+faN(d?d.left:0)+'">'+
    '<button class="btn gold full" id="sv" style="margin-top:16px">'+(d?"ذخیره‌ی تغییرات":"ثبت کن")+'</button>');
  money($("ia"));
  $("sv").onclick=function(){
    var t=$("it").value.trim();
    if(!t){toast("عنوان قسط رو بنویس 🙃");return}
    var a=String(parseNum($("ia").value)||0),l=parseNum($("il").value)||0;
    if(d)A.updateInst(String(d.id),t,a,readDate("id"),$("irep").checked,l);
    else A.addInst(t,a,readDate("id"),$("irep").checked,l);
    closeSheet();S.dtab="inst";toast(d?"ذخیره شد ✅":"قسط ثبت شد؛ اعلان همیشگی هم گذاشتم 🔔");render();
  };
}
function openDebtInvoice(id){
  var d=null;S.debts.forEach(function(x){if(String(x.id)===String(id))d=x});
  if(!d)return;
  var v=invDefaults();
  v.name=d.name;v.unit="تومان";
  v.items=[{desc:d.note||"",qty:"1",price:d.amount?fa(d.amount):""}];
  S.inv=v;S.invRes=null;S.tab="invoice";
  render();$("main").scrollTop=0;
  toast("مشخصات طلب توی فاکتور پر شد؛ بقیه رو کامل کن و بساز 🧾");
}

/* ---------- نرخ‌ها و پیش‌بینی ---------- */
function renderRates(){
  var r=J(A.rates())||{},el=$("rateBar");
  function cell(k,ico,name){
    var o=r[k];
    if(!o)return '<span class="rt">'+ico+' '+name+' <span class="mut">—</span></span>';
    var ar=o.dir>0?'<b class="up">▲ بالا رفت</b>':o.dir<0?'<b class="dn">▼ پایین اومد</b>':'<span class="mut">• ثابت</span>';
    return '<span class="rt" data-rt="'+k+'">'+ico+' '+name+' <b>'+fa(o.p)+'</b> '+ar+(o.chg&&o.dir?'<small>'+fa(o.chg)+'</small>':'')+'</span>';
  }
  el.innerHTML=cell("usd","💵","دلار")+cell("gold18","🥇","طلا ۱۸")+cell("coin","🪙","سکه")+
    (r.ts?'<span class="rt mut" data-rr="1">🔄 '+fmtTime(r.ts)+'</span>':'<span class="rt mut" data-rr="1">نرخ نیومد؛ اینترنت؟ بزن دوباره</span>');
}
var RATE_NAMES={usd:"دلار",gold18:"طلا ۱۸ عیار (هر گرم)",coin:"سکه"};
function newsAnalysis(key,N){
  var o={drift:0,sent:0,items:[],world:[],has:false};
  if(!N)return o;
  var g=N[key==="usd"?"usd":"gold18"],w=N.world;
  if(!g&&!w)return o;
  o.has=true;
  var sc=(g?g.score:0)+(w?0.5*w.score:0),n=Math.max(6,(g?g.n:0)+(w?w.n*0.5:0));
  o.sent=Math.max(-1,Math.min(1,sc/n*2));
  o.drift=o.sent*0.006;
  o.items=g?g.items.slice(0,6):[];o.world=w?w.items.slice(0,4):[];
  return o;
}
function newsHtml(nw,N,techDir){
  if(!nw.has)return '<div class="card" style="margin-top:10px"><b>📰 اخبار</b><div class="mut" style="margin-top:4px">فعلاً خبری نیومد (اینترنت یا منبع خبر در دسترس نبود). دوباره امتحان کن.</div></div>';
  var st=nw.sent>0.25?"صعودی ▲":nw.sent<-0.25?"نزولی ▼":"خنثی ▬";
  var comb=nw.sent*0.6+techDir*0.4,verdict=comb>0.25?"ترکیب خبر و روند قیمت: فشار صعودی. اگه داری، نگه‌دار؛ خرید با عجله و بدون برنامه نه.":comb<-0.25?"ترکیب خبر و روند قیمت: فشار نزولی. عجله برای خرید نکن؛ اگه داری، صبر کن و پله‌پله تصمیم بگیر.":"ترکیب خبر و روند قیمت: خنثی. روی پیش‌فرض بمون و نگه‌دار؛ تا خبر مهم جدید نیومده کاری نکن.";
  function li(x){return '<div style="margin:3px 0;font-size:12.5px">'+(x.s>0?'<b class="in">▲</b> ':x.s<0?'<b class="out">▼</b> ':'• ')+esc(x.t)+'</div>'}
  return '<div class="card" style="margin-top:10px"><b>📰 تحلیل فاندامنتال (اخبار)</b><div style="margin:6px 0">جهت خبرها: <b>'+st+'</b></div>'+nw.items.map(li).join("")+
    (nw.world.length?'<div class="mut" style="margin-top:8px">🌍 رویدادهای مهم جهانی:</div>'+nw.world.map(li).join(""):"")+
    '<div style="margin-top:8px;font-size:13px;line-height:1.9"><b>'+verdict+'</b></div></div>';
}
function rateForecast(key,_n){
  var idx={usd:1,gold18:2,coin:3}[key],r=J(A.rates())||{},o=r[key];
  if(!o){toast("هنوز نرخ نیومده؛ اینترنت رو چک کن");return}
  var DAY=864e5,now=Date.now(),p=o.p;
  var hist=(J(A.ratesHist())||[]).filter(function(x){return x[idx]>0&&now-x[0]<14*DAY}).map(function(x){return [x[0],Math.log(x[idx])]});
  var span=hist.length>1?(hist[hist.length-1][0]-hist[0][0])/DAY:0;
  var prior=Math.pow(1+0.30,1/365)-1,sig=key==="usd"?0.012:0.011,tech=null,used=hist.length;
  var mom=(o.dir&&o.chg&&p)?(o.dir*o.chg/p):0;
  if(hist.length>=4&&span>=0.25){
    var n=hist.length,mx=0,my=0,i;
    hist.forEach(function(x){mx+=(x[0]-hist[0][0])/DAY;my+=x[1]});mx/=n;my/=n;
    var sxy=0,sxx=0;
    hist.forEach(function(x){var t=(x[0]-hist[0][0])/DAY;sxy+=(t-mx)*(x[1]-my);sxx+=(t-mx)*(t-mx)});
    if(sxx>0)tech=sxy/sxx;
    var q=0,dt=0;
    for(i=1;i<n;i++){var d=(hist[i][0]-hist[i-1][0])/DAY,rr=hist[i][1]-hist[i-1][1];if(d>0){q+=rr*rr;dt+=d}}
    if(dt>0)sig=Math.max(0.004,Math.min(0.05,Math.sqrt(q/dt)));
  }
  var w=tech==null?0:Math.min(0.6,span/7*0.6);
  var drift=w*(tech==null?0:tech)+(1-w)*(prior+0.2*mom);
  var N=null;try{N=J(A.news&&A.news())||null}catch(e){}
  var nw=newsAnalysis(key,N);drift+=nw.drift;
  drift=Math.max(-0.03,Math.min(0.03,drift));
  var dnow=new Date(),endToday=(new Date(dnow.getFullYear(),dnow.getMonth(),dnow.getDate()+1)-dnow)/DAY;
  var toFri=(5-dnow.getDay()+7)%7,tj=todayJ(),toMonth=mlen(tj[0],tj[1])-tj[2];
  var hz=[["تا آخر امروز",endToday],["تا آخر این هفته (جمعه)",endToday+toFri],["تا آخر این ماه",endToday+toMonth]];
  function f(T,z){return Math.round(p*Math.exp(drift*T+z*sig*Math.sqrt(T)))}
  var h='<h3>'+(key==="usd"?"💵":key==="gold18"?"🥇":"🪙")+' '+RATE_NAMES[key]+'</h3><div class="big gold">'+fa(p)+' <span class="mut">تومان</span></div>'+
    '<div class="card" style="margin-top:10px"><b>🔮 پیش‌بینی (حدودی)</b><table style="width:100%;font-size:13px;margin-top:6px">';
  hz.forEach(function(x){h+='<tr><td>'+x[0]+'</td><td><b>≈ '+fa(f(x[1],0))+'</b></td><td class="mut" style="font-size:11.5px">'+fa(f(x[1],-1))+' تا '+fa(f(x[1],1))+'</td></tr>'});
  h+='</table></div><div class="mut" style="font-size:12px;line-height:1.9;margin-top:8px">روش: ترکیب «روند خودِ قیمت‌های ثبت‌شده» (تکنیکال: شیب روند و نوسان)، «تغییر امروز نسبت به قبل» و یک فرض بنیادی ثابت (کم‌ارزش‌شدن تدریجی پول ملی، حدود ۳۰٪ در سال). الان '+faN(used)+' نمونه‌ی ثبت‌شده دارم'+(tech==null?'؛ هنوز کمه، پس بیشتر به فرض بنیادی تکیه کردم. چند روز که اپ رو باز کنی دقیق‌تر می‌شه.':'.')+
    '<br>این‌ها فقط تخمینه؛ بازار به خبر و تصمیم‌های سیاسی و اقتصادی حساسه و هیچ‌کس نمی‌تونه دقیق پیش‌بینی کنه. براساسش تصمیم مالی بزرگ نگیر.</div>';
  var tdir=Math.max(-1,Math.min(1,(drift-nw.drift)*100));
  h=h.replace('<div class="mut" style="font-size:12px;line-height:1.9;margin-top:8px">',newsHtml(nw,N,tdir)+'<div class="mut" style="font-size:12px;line-height:1.9;margin-top:8px">');
  openSheet(h);
  if(!_n&&A.refreshNews&&(!N||Date.now()-N.ts>1800000)){
    A.refreshNews();
    var tmr=setInterval(function(){
      if(!A.newsBusy()){clearInterval(tmr);if($("sheet")&&document.getElementById("sheetBg").classList.contains("on"))rateForecast(key,1)}
    },900);
  }
}

/* ---------- ماشین‌حساب ---------- */
function openCalc(){
  var ex="";
  function fmt(n){
    if(!isFinite(n))return "خطا";
    var s=(Math.round(n*1e6)/1e6).toString(),p=s.split(".");
    p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,",");return p.join(".");
  }
  function ev(){
    var t=ex.replace(/×/g,"*").replace(/÷/g,"/").replace(/٪/g,"/100");
    if(!t||!/^[0-9+\-*/.() ]+$/.test(t))return null;
    try{var v=Function('"use strict";return ('+t+')')();return typeof v==="number"?v:null}catch(e){return null}
  }
  var keys=["C","(",")","÷","7","8","9","×","4","5","6","−","1","2","3","+","⌫","0",".","="];
  openSheet('<h3>🧮 ماشین‌حساب</h3><div class="calc"><div class="disp"><div class="ex" id="cEx"></div><div class="rs" id="cRs">0</div></div><div class="kp">'+
    keys.map(function(k){return '<button class="'+("÷×−+".indexOf(k)>=0?"op":k==="="?"eq":"")+'" data-k="'+k+'">'+k+'</button>'}).join("")+'</div></div>'+
    '<div class="row" style="margin-top:10px"><button class="btn sm ghost" id="cCopy">📋 کپی نتیجه</button></div>');
  function show(){
    $("cEx").textContent=ex;
    var v=ev();$("cRs").textContent=v==null?(ex?"…":"0"):fmt(v);
  }
  document.querySelectorAll(".calc [data-k]").forEach(function(b){b.onclick=function(){
    var k=b.dataset.k;
    if(k==="C")ex="";else if(k==="⌫")ex=ex.slice(0,-1);
    else if(k==="="){var v=ev();if(v!=null)ex=String(Math.round(v*1e6)/1e6)}
    else ex+=(k==="−"?"-":k);
    show();
  }});
  $("cCopy").onclick=function(){var v=ev();if(v!=null){A.copyText(String(Math.round(v*1e6)/1e6));toast("کپی شد 📋")}};
}

/* ---------- جشن سطح و نشان ---------- */
function gameCheck(){
  var g=getGame();if(!g)return;
  grantAuto();
  try{
    var old=JSON.parse(localStorage.getItem("badges")||"null"),now=g.badges.filter(function(b){return b.ok}).map(function(b){return b.id});
    if(old){
      var nw=g.badges.filter(function(b){return b.ok&&old.indexOf(b.id)<0});
      if(nw.length){toast("نشان جدید: "+nw[0].icon+" "+nw[0].title+" 🎉");confetti()}
    }
    localStorage.setItem("badges",JSON.stringify(now));
  }catch(e){}
  if(g.level>g.seen){
    A.gameAck(g.level);
    if(g.level>1){
      confetti();
      var unlock=[];
      Object.keys(CAT).forEach(function(sl){CAT[sl].forEach(function(i){if(i.lvl===g.level)unlock.push(i.n)})});
      SETS.forEach(function(st){if(st.lvl===g.level)unlock.push("ست "+st.n)});
      var line=(window.CONTENT&&CONTENT.supervisor&&CONTENT.supervisor.levelUp)?fillTpl(R(CONTENT.supervisor.levelUp)):"";
      openSheet('<div style="text-align:center"><div style="width:130px;height:130px;margin:auto">'+girl("happy","bust")+'</div><h3>🏆 سطح '+faN(g.level)+'!</h3>'+
        '<p style="line-height:1.9">'+esc(line)+'<br>شغل جدید: <b class="gold">'+esc(JOBS[g.level-1])+'</b><br>خونه: <b>'+esc(HOUSES[g.level-1])+'</b>'+(unlock.length?'<br>🎁 باز شد: '+esc(unlock.join("، ")):"")+'</p>'+
        '<div class="row"><button class="btn gold" id="cfW" style="flex:1">👗 برم کمد</button><button class="btn ghost" id="cfOk" style="flex:1">باشه</button></div></div>');
      $("cfOk").onclick=closeSheet;
      $("cfW").onclick=function(){closeSheet();openGame("wardrobe")};
    }
  }
}

/* ---------- اتصال رویدادها ---------- */
function bindExtra(){
  var e;
  if(e=$("expRep"))e.onclick=function(){
    var r=J(A.exportReport(S.y,S.m))||{};
    if(!r.ok){toast("ساخت فایل نشد");return}
    openSheet('<h3>📄 آمار '+MONTHS[S.m-1]+' آماده شد</h3><div class="mut">توی پوشه‌ی Download/KhazanehdarSara ذخیره شد.</div>'+
      '<div class="row" style="margin-top:12px;flex-wrap:wrap"><button class="btn gold" id="oP">باز کردن PDF</button><button class="btn" id="sP">ارسال PDF</button><button class="btn gold" id="oW">باز کردن Word</button><button class="btn" id="sW">ارسال Word</button></div>');
    var W="application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    $("oP").onclick=function(){A.openUri(r.pdf,"application/pdf")};$("sP").onclick=function(){A.shareUri(r.pdf,"application/pdf")};
    $("oW").onclick=function(){A.openUri(r.docx,W)};$("sW").onclick=function(){A.shareUri(r.docx,W)};
  };
  if(e=$("posBar"))renderPosBar();
  document.querySelectorAll("[data-go]").forEach(function(b){b.onclick=function(){openGame(b.dataset.go)}});
  document.querySelectorAll("[data-tot]").forEach(function(b){b.onclick=function(){openTotals(b.dataset.tot)}});
  if(e=$("bkTotal"))e.onclick=openBankTotals;
  document.querySelectorAll("[data-ct]").forEach(function(b){b.onclick=function(){S.ctype=b.dataset.ct;render()}});
  document.querySelectorAll("[data-coff]").forEach(function(b){b.onclick=function(){
    var k=b.dataset.coff;G.chartOff=G.chartOff||{};if(G.chartOff[k])delete G.chartOff[k];else G.chartOff[k]=1;gSave();render();
  }});
  document.querySelectorAll("[data-edd]").forEach(function(b){b.onclick=function(){var d=null;S.debts.forEach(function(x){if(String(x.id)===b.dataset.edd)d=x});if(d)openDebtForm(d)}});
  document.querySelectorAll("[data-edin]").forEach(function(b){b.onclick=function(){var d=null;S.insts.forEach(function(x){if(String(x.id)===b.dataset.edin)d=x});if(d)openInstForm(d)}});
  document.querySelectorAll("[data-ls]").forEach(function(b){b.onclick=function(){
    var l=pickLesson(),a=b.dataset.ls;
    if(a==="save"){G.lessonsSaved=G.lessonsSaved||[];if(G.lessonsSaved.indexOf(l.id)<0)G.lessonsSaved.push(l.id);gSave();toast("ذخیره شد 💾");render()}
    else if(a==="copy"){A.copyText(lessonText(l));toast("کپی شد 📋")}
    else if(a==="next"){pickLesson(true);render()}
    else openSavedLessons();
  }});
  var rb=$("rateBar");
  rb.onclick=function(ev){
    var t=ev.target.closest("[data-rt]");
    if(t)rateForecast(t.dataset.rt);else loadRates();
  };
}
document.addEventListener("DOMContentLoaded",function(){
  var h=document.querySelector("header");
  if(h&&!document.getElementById("calcBtn")){
    var b=document.createElement("button");b.id="calcBtn";b.className="calcb";b.textContent="🧮";b.onclick=openCalc;h.appendChild(b);
  }
});
