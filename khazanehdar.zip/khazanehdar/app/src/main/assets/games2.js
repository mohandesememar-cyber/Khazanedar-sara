"use strict";
/* ===== بازی‌های بیشتر: مار و پله، تخته‌نرد، حکم + پت سارا ===== */
(function(){
  var css=document.createElement("style");
  css.textContent=[
  ".sl{display:grid;grid-template-columns:repeat(10,1fr);gap:2px;direction:ltr;margin:8px 0}",
  ".sl div{aspect-ratio:1;background:#ffffff12;border-radius:5px;font-size:9px;position:relative;display:flex;align-items:center;justify-content:center;color:#fff9}",
  ".sl div.sn{background:#c0392b44}.sl div.ld{background:#2e9b5a44}",
  ".sl b{position:absolute;top:0;left:2px;font-size:8px;opacity:.6}.sl i{font-style:normal;font-size:13px}",
  ".bg{direction:ltr;margin:6px 0}.bgr{display:flex;gap:2px;margin-bottom:6px}",
  ".bgp{flex:1;min-width:0;height:104px;border-radius:6px;background:#ffffff12;display:flex;flex-direction:column;align-items:center;padding:2px 0;gap:1px;font-size:8px;color:#fff8;cursor:pointer;border:2px solid transparent}",
  ".bgp.b{justify-content:flex-end;flex-direction:column-reverse}.bgp.sel{border-color:#ffd54f}.bgp.dst{border-color:#37b57a;background:#37b57a33}",
  ".ck{width:13px;height:13px;border-radius:50%;flex:0 0 13px}.ck.y{background:#f4a8d0;box-shadow:inset 0 0 0 2px #c2325c}.ck.h{background:#7aa9ff;box-shadow:inset 0 0 0 2px #2b5bd6}",
  ".pcard{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;width:40px;height:58px;border-radius:7px;background:#fff;color:#222;font-weight:800;font-size:15px;margin:2px;border:2px solid transparent;font-family:inherit}",
  ".pcard.r{color:#c0392b}.pcard.ok{border-color:#ffd54f;transform:translateY(-6px)}.pcard.no{opacity:.45}",
  ".trk{display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:60px 60px 60px;gap:2px;text-align:center;align-items:center;justify-items:center;margin:8px 0}",
  ".pet{text-align:center;position:relative;height:210px;display:flex;align-items:flex-end;justify-content:center;border-radius:22px;background:linear-gradient(180deg,#ffffff14,#00000022);border:1px solid var(--line);margin-bottom:10px;overflow:hidden}",
  ".pet .pp{position:relative;line-height:1;animation:pbounce 2.2s ease-in-out infinite;transform-origin:50% 100%}",
  ".pet .ph{position:absolute;left:50%;transform:translateX(-50%);top:-.35em}.pet .pc{position:absolute;left:50%;transform:translateX(-50%);bottom:-.05em}",
  "@keyframes pbounce{0%,100%{transform:scale(1,1)}50%{transform:scale(1.06,.94)}}",
  ".bar{height:10px;border-radius:9px;background:#ffffff1c;overflow:hidden}.bar i{display:block;height:100%;border-radius:9px}"
  ].join("\n");
  document.head.appendChild(css);
})();

function _gcard(el){return el}

/* ---------------- مار و پله ---------------- */
function gSnake(el){
  var tag=String(Math.random());el.dataset.game=tag;
  var SN={16:6,47:26,49:11,56:53,62:19,64:60,87:24,93:73,95:75,98:78},LD={1:38,4:14,9:31,21:42,28:84,36:44,51:67,71:91,80:100};
  var st={you:0,her:0,turn:"you",msg:"تاس بنداز!",over:false,d:0};
  function cells(){
    var h="";
    for(var vr=0;vr<10;vr++)for(var vc=0;vc<10;vc++){
      var r=9-vr,n=r%2===0?r*10+vc+1:r*10+(9-vc)+1;
      var t=(st.you===n?"🟣":"")+(st.her===n?"🔴":"");
      h+='<div class="'+(SN[n]?"sn":LD[n]?"ld":"")+'"><b>'+n+'</b><i>'+(t||(SN[n]?"🐍":LD[n]?"🪜":""))+'</i></div>';
    }
    return h;
  }
  function draw(){
    if((!el.isConnected||el.dataset.game!==tag))return;
    el.innerHTML='<div class="card" style="text-align:center"><div class="row sp"><b>🐍 مار و پله</b><button class="btn sm ghost" id="sBack">خروج</button></div>'+
      '<div class="mut">تو 🟣 '+faN(st.you)+' — سارا 🔴 '+faN(st.her)+'</div><div class="sl">'+cells()+'</div>'+
      '<div style="min-height:40px">'+(st.d?'🎲 '+faN(st.d)+' — ':'')+st.msg+'</div>'+
      (st.turn==="you"&&!st.over?'<button class="btn gold big" id="sRoll">🎲 تاس بنداز</button>':'')+'</div>';
    document.getElementById("sBack").onclick=function(){st.over=true;renderGame()};
    var b=document.getElementById("sRoll");if(b)b.onclick=function(){move("you")};
  }
  function move(w){
    if(st.over)return;
    var d=1+Math.floor(Math.random()*6),p=st[w]+d,m="";
    if(p>100)p=st[w];
    if(SN[p]){m=(w==="you"?"مار گاززدت! 🐍":"مار منو گاز گرفت 😭");p=SN[p]}
    else if(LD[p]){m=(w==="you"?"از پله بالا رفتی 🪜":"از پله رفتم بالا 😎");p=LD[p]}
    st[w]=p;st.d=d;st.msg=(w==="you"?"تو: ":"سارا: ")+m;
    if(p>=100){st.over=true;var b=gResult(el,w==="you",true,w==="you"?"اول رسیدی به ۱۰۰ 🎉":"من اول رسیدم 😜");b.onclick=function(){gSnake(el)};return}
    st.turn=w==="you"?"her":"you";draw();
    if(st.turn==="her")setTimeout(function(){if(el.isConnected&&el.dataset.game===tag)move("her")},800);
  }
  draw();
}

/* ---------------- تخته‌نرد ---------------- */
function gBackgammon(el){
  var tag=String(Math.random());el.dataset.game=tag;
  var st;
  function init(){
    var p=[];for(var i=0;i<24;i++)p.push(0);
    p[23]=2;p[12]=5;p[7]=3;p[5]=5;      // تو (حرکت به سمت ۰)
    p[0]=-2;p[11]=-5;p[16]=-3;p[18]=-5; // سارا (حرکت به سمت ۲۳)
    st={p:p,bar:{you:0,her:0},off:{you:0,her:0},avail:[],turn:"you",sel:null,msg:"تاس بنداز!",over:false};
  }
  init();
  function sg(P){return P==="you"?1:-1}
  function allHome(P){
    if(st.bar[P]>0)return false;
    for(var i=0;i<24;i++){if(st.p[i]*sg(P)>0&&(P==="you"?i>5:i<18))return false}
    return true;
  }
  function moves(P){
    var s=sg(P),out=[],seen={};
    st.avail.forEach(function(d){
      if(seen[d])return;seen[d]=1;
      function open(t){return st.p[t]*s>-2}
      if(st.bar[P]>0){var t=P==="you"?24-d:d-1;if(open(t))out.push({f:-1,t:t,d:d});return}
      for(var i=0;i<24;i++){
        if(st.p[i]*s<=0)continue;
        var t=P==="you"?i-d:i+d;
        if(t>=0&&t<=23){if(open(t))out.push({f:i,t:t,d:d})}
        else if(allHome(P)){
          var dist=P==="you"?i+1:24-i,higher=false;
          for(var j=0;j<24;j++){if(st.p[j]*s>0&&(P==="you"?j>i:j<i))higher=true}
          if(d===dist||(d>dist&&!higher))out.push({f:i,t:"off",d:d});
        }
      }
    });
    return out;
  }
  function apply(P,m){
    var s=sg(P),O=P==="you"?"her":"you";
    if(m.f===-1)st.bar[P]--;else st.p[m.f]-=s;
    if(m.t==="off")st.off[P]++;
    else{
      if(st.p[m.t]*s===-1){st.p[m.t]=0;st.bar[O]++}
      st.p[m.t]+=s;
    }
    st.avail.splice(st.avail.indexOf(m.d),1);
  }
  function roll(){
    var a=1+Math.floor(Math.random()*6),b=1+Math.floor(Math.random()*6);
    st.avail=a===b?[a,a,a,a]:[a,b];st.dice=[a,b];
  }
  function checkEnd(){
    if(st.off.you>=15||st.off.her>=15){
      st.over=true;var w=st.off.you>=15;
      var b=gResult(el,w,true,w?"همه‌ی مهره‌هات رو بیرون بردی! 🏆":"من زودتر بیرون بردم 😎");b.onclick=function(){init();draw()};
      return true;
    }
    return false;
  }
  function endTurn(P){
    st.sel=null;st.avail=[];
    st.turn=P==="you"?"her":"you";
    st.msg=st.turn==="you"?"نوبت توئه؛ تاس بنداز":"سارا داره بازی می‌کنه…";
    draw();
    if(st.turn==="her")setTimeout(function(){if(el.isConnected&&el.dataset.game===tag)herTurn()},700);
  }
  function herTurn(){
    if(st.over)return;
    roll();draw();
    var guard=0;
    (function step(){
      if(st.over||(!el.isConnected||el.dataset.game!==tag))return;
      var l=moves("her");
      if(!l.length||!st.avail.length||guard++>8){endTurn("her");return}
      var best=null,bs=-1e9;
      l.forEach(function(m){
        var sc=Math.random()*2;
        if(m.t==="off")sc+=30;
        else{
          if(st.p[m.t]===1)sc+=50;
          if(st.p[m.t]<0)sc+=8;
          if(st.p[m.t]===0)sc-=2;
        }
        if(m.f>=0&&st.p[m.f]===-2)sc-=6;
        if(m.f>=0)sc+=m.d*0.3;
        if(sc>bs){bs=sc;best=m}
      });
      apply("her",best);draw();
      if(checkEnd())return;
      setTimeout(step,450);
    })();
  }
  function draw(){
    if((!el.isConnected||el.dataset.game!==tag))return;
    function col(i,top){
      var n=Math.abs(st.p[i]),cls=st.p[i]>0?"y":"h",dots="";
      for(var k=0;k<Math.min(n,6);k++)dots+='<span class="ck '+cls+'"></span>';
      var isSel=st.sel===i,isDst=st.sel!==null&&st.turn==="you"&&moves("you").some(function(m){return m.f===st.sel&&m.t===i});
      return '<div class="bgp '+(top?"t":"b")+(isSel?" sel":"")+(isDst?" dst":"")+'" data-pt="'+i+'">'+(top?'<span>'+(i+1)+'</span>':'')+dots+(n>6?'<span>+'+(n-6)+'</span>':'')+(top?'':'<span>'+(i+1)+'</span>')+'</div>';
    }
    var top="",bot="";
    for(var i=12;i<=23;i++)top+=col(i,true);
    for(var j=11;j>=0;j--)bot+=col(j,false);
    var mv=st.turn==="you"?moves("you"):[],canOff=st.sel!==null&&mv.some(function(m){return m.f===st.sel&&m.t==="off"});
    el.innerHTML='<div class="card"><div class="row sp"><b>🎲 تخته‌نرد</b><button class="btn sm ghost" id="bBack">خروج</button></div>'+
      '<div class="mut">تو (صورتی) از ۲۴ به ۱ می‌ری و خونه‌ات پایین راسته • سارا (آبی) برعکس</div>'+
      '<div class="bg"><div class="bgr">'+top+'</div><div class="bgr">'+bot+'</div></div>'+
      '<div class="row sp" style="font-size:12.5px"><span>روی میله: تو '+faN(st.bar.you)+' • من '+faN(st.bar.her)+'</span><span>بیرون: تو '+faN(st.off.you)+' • من '+faN(st.off.her)+'</span></div>'+
      '<div style="text-align:center;margin-top:8px;min-height:34px">'+(st.dice?'🎲 '+st.dice.map(faN).join(" • ")+(st.avail.length?' (مانده: '+st.avail.map(faN).join("، ")+')':'')+' — ':'')+st.msg+'</div>'+
      '<div class="row" style="justify-content:center;flex-wrap:wrap">'+
      (st.turn==="you"&&!st.avail.length&&!st.over?'<button class="btn gold big" id="bRoll">🎲 تاس بنداز</button>':'')+
      (st.turn==="you"&&st.bar.you>0&&st.avail.length?'<button class="btn" id="bBar'+(st.sel===-1?'" style="outline:2px solid #ffd54f':'')+'">از میله وارد کن</button>':'')+
      (canOff?'<button class="btn gold" id="bOff">🏁 بیرون ببر</button>':'')+'</div></div>';
    document.getElementById("bBack").onclick=function(){st.over=true;renderGame()};
    var r=document.getElementById("bRoll");
    if(r)r.onclick=function(){
      roll();var l=moves("you");
      if(!l.length){st.msg="حرکتی نداری 😅";draw();setTimeout(function(){endTurn("you")},900);return}
      st.msg="یه مهره انتخاب کن";draw();
    };
    var br=document.getElementById("bBar");if(br)br.onclick=function(){st.sel=-1;draw()};
    var of=document.getElementById("bOff");
    if(of)of.onclick=function(){var m=mv.filter(function(m){return m.f===st.sel&&m.t==="off"})[0];doYou(m)};
    el.querySelectorAll("[data-pt]").forEach(function(c){c.onclick=function(){
      if(st.turn!=="you"||!st.avail.length||st.over)return;
      var i=+c.dataset.pt,l=moves("you");
      if(st.sel!==null){
        var m=l.filter(function(m){return m.f===st.sel&&m.t===i}).sort(function(a,b){return a.d-b.d})[0];
        if(m){doYou(m);return}
      }
      if(st.bar.you>0){st.sel=-1;draw();return}
      if(l.some(function(m){return m.f===i}))st.sel=i;else st.sel=null;
      draw();
    }});
  }
  function doYou(m){
    apply("you",m);st.sel=null;
    if(checkEnd())return;
    var l=moves("you");
    if(!st.avail.length||!l.length){endTurn("you");return}
    st.msg="ادامه بده";draw();
  }
  draw();
}

/* ---------------- حکم ---------------- */
function gHokm(el){
  var tag=String(Math.random());el.dataset.game=tag;
  var SU=["♠","♥","♦","♣"],RK=["2","3","4","5","6","7","8","9","10","J","Q","K","A"],NM=["تو","حریف راست","هم‌تیمی","حریف چپ"];
  var st={};
  function deck(){var d=[];for(var s=0;s<4;s++)for(var r=0;r<13;r++)d.push({s:s,r:r});for(var i=d.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=d[i];d[i]=d[j];d[j]=t}return d}
  function start(){
    var d=deck();st={h:[[],[],[],[]],trump:null,hakem:Math.floor(Math.random()*4),trick:[],lead:0,turn:0,tk:[0,0],msg:"",over:false,done:0};
    for(var i=0;i<52;i++)st.h[i%4].push(d[i]);
    st.h.forEach(function(h){h.sort(function(a,b){return a.s-b.s||b.r-a.r})});
    if(st.hakem===0){st.phase="pick";draw();return}
    // حاکم هوشمند: خالی که بیشترین کارت و ارزش رو داره
    var h=st.h[st.hakem].slice(0,5),sc=[0,0,0,0];h.forEach(function(c){sc[c.s]+=1+c.r/13});
    st.trump=sc.indexOf(Math.max.apply(null,sc));st.phase="play";st.lead=st.turn=st.hakem;
    st.msg=NM[st.hakem]+" حاکمه و "+SU[st.trump]+" رو حکم کرد.";draw();next();
  }
  function legal(p){
    var h=st.h[p];if(!st.trick.length)return h;
    var ls=st.trick[0].c.s,f=h.filter(function(c){return c.s===ls});return f.length?f:h;
  }
  function winner(){
    var b=st.trick[0];
    st.trick.forEach(function(t){
      var tb=t.c.s===st.trump,bb=b.c.s===st.trump;
      if(tb&&!bb)b=t;else if(tb===bb&&t.c.s===b.c.s&&t.c.r>b.c.r)b=t;
    });
    return b.p;
  }
  function bot(p){
    var l=legal(p),cur=st.trick.length?curWin():null;
    function lo(a){return a.slice().sort(function(x,y){return x.r-y.r})[0]}
    function hi(a){return a.slice().sort(function(x,y){return y.r-x.r})[0]}
    if(!st.trick.length){
      var nt=l.filter(function(c){return c.s!==st.trump});
      return nt.length?hi(nt):lo(l);
    }
    var ls=st.trick[0].c.s,fol=l.filter(function(c){return c.s===ls}),part=(cur.p+p)%2===0;
    if(fol.length){
      if(part)return lo(fol);
      var beat=fol.filter(function(c){return cur.c.s===ls?c.r>cur.c.r:false});
      return beat.length?lo(beat):lo(fol);
    }
    var tr=l.filter(function(c){return c.s===st.trump});
    if(part||!tr.length)return lo(l.filter(function(c){return c.s!==st.trump}).length?l.filter(function(c){return c.s!==st.trump}):l);
    if(cur.c.s===st.trump){var bt=tr.filter(function(c){return c.r>cur.c.r});return bt.length?lo(bt):lo(l.filter(function(c){return c.s!==st.trump}).length?l.filter(function(c){return c.s!==st.trump}):l)}
    return lo(tr);
  }
  function curWin(){var b=st.trick[0];st.trick.forEach(function(t){var tb=t.c.s===st.trump,bb=b.c.s===st.trump;if(tb&&!bb)b=t;else if(tb===bb&&t.c.s===b.c.s&&t.c.r>b.c.r)b=t});return b}
  function play(p,c){
    var h=st.h[p];h.splice(h.indexOf(c),1);st.trick.push({p:p,c:c});
    if(st.trick.length===4){
      draw();
      setTimeout(function(){
        if((!el.isConnected||el.dataset.game!==tag)||st.over)return;
        var w=winner();st.tk[w%2]++;st.msg=(w===0?"تو":NM[w])+" این دست رو برد.";st.trick=[];st.turn=st.lead=w;st.done++;
        if(st.done===13){finish();return}
        draw();next();
      },1100);
      return;
    }
    st.turn=(p+1)%4;draw();next();
  }
  function next(){
    if(st.over||st.trick.length>=4||st.turn===0)return;
    var p=st.turn;setTimeout(function(){if((!el.isConnected||el.dataset.game!==tag)||st.over||st.turn!==p)return;play(p,bot(p))},650);
  }
  function finish(){
    st.over=true;var w=st.tk[0]>=7;
    var b=gResult(el,w,true,"تیم تو "+faN(st.tk[0])+" دست، حریف‌ها "+faN(st.tk[1])+" دست");b.onclick=function(){gHokm(el)};
  }
  function cardHtml(c,cls,attr){return '<button class="pcard '+(c.s===1||c.s===2?"r ":"")+(cls||"")+'" '+(attr||"")+'><span>'+RK[c.r]+'</span><span>'+SU[c.s]+'</span></button>'}
  function draw(){
    if((!el.isConnected||el.dataset.game!==tag))return;
    if(st.phase==="pick"){
      var five=st.h[0].slice(0,5);
      el.innerHTML='<div class="card" style="text-align:center"><div class="row sp"><b>♠️ حکم</b><button class="btn sm ghost" id="hBack">خروج</button></div><div>تو حاکمی! از روی ۵ کارت اولت خال حکم رو انتخاب کن:</div><div>'+five.map(function(c){return cardHtml(c)}).join("")+'</div>'+
        '<div class="row" style="justify-content:center;margin-top:8px">'+SU.map(function(s,i){return '<button class="btn big" data-ts="'+i+'" style="font-size:26px">'+s+'</button>'}).join("")+'</div></div>';
      document.getElementById("hBack").onclick=function(){st.over=true;renderGame()};
      el.querySelectorAll("[data-ts]").forEach(function(b){b.onclick=function(){st.trump=+b.dataset.ts;st.phase="play";st.lead=st.turn=0;st.msg="حکم: "+SU[st.trump]+" — تو شروع می‌کنی";draw()}});
      return;
    }
    var spots={0:7,1:4,2:1,3:4};
    var tr=[0,0,0,0,0,0,0,0,0].map(function(){return ""});
    var pos={2:1,3:3,1:5,0:7};
    st.trick.forEach(function(t){tr[pos[t.p]]=cardHtml(t.c,"")});
    var my=st.h[0],lg=st.turn===0&&st.trick.length<4?legal(0):[];
    el.innerHTML='<div class="card" style="text-align:center"><div class="row sp"><b>♠️ حکم • حکم: <span style="font-size:20px">'+SU[st.trump]+'</span></b><button class="btn sm ghost" id="hBack">خروج</button></div>'+
      '<div class="mut">دست‌های تیم تو: '+faN(st.tk[0])+' • حریف‌ها: '+faN(st.tk[1])+' (۷ دست ببر تا برنده بشی)</div>'+
      '<div class="trk"><span class="mut">'+NM[2]+' ('+faN(st.h[2].length)+')</span>'+tr[1]+'<span></span>'+tr[3]+'<span></span>'+tr[5]+'<span class="mut">'+NM[3]+' ('+faN(st.h[3].length)+')</span>'+tr[7]+'<span class="mut">'+NM[1]+' ('+faN(st.h[1].length)+')</span></div>'+
      '<div style="min-height:24px" class="mut">'+(st.turn===0&&st.trick.length<4?"نوبت توئه 👇":st.msg)+'</div>'+
      '<div>'+my.map(function(c,i){var ok=lg.indexOf(c)>=0;return cardHtml(c,ok?"ok":lg.length?"no":"",'data-pc="'+i+'"')}).join("")+'</div></div>';
    document.getElementById("hBack").onclick=function(){st.over=true;renderGame()};
    el.querySelectorAll("[data-pc]").forEach(function(b){b.onclick=function(){
      if(st.turn!==0||st.trick.length>=4)return;
      var c=my[+b.dataset.pc];if(legal(0).indexOf(c)<0){toast("باید از همون خال بیاری");return}
      play(0,c);
    }});
  }
  start();
}

/* ---------------- پت سارا ---------------- */
var PET_HATS=[["","بدون",0],["🎩","کلاه شیک",10],["👑","تاج",25],["🧢","کپ",8],["🎀","پاپیون",6],["🕶️","عینک",8]];
var PET_CLO=[["","بدون",0],["👕","تی‌شرت",10],["🧥","کت",15],["🦺","جلیقه",8],["👗","لباس",12]];
function petGet(){
  if(!G.pet)G.pet={name:"پوپو",born:Date.now(),hunger:80,clean:80,fun:80,last:Date.now(),care:0,hat:"",clo:"",own:{},freeFeed:0};
  var p=G.pet,h=(Date.now()-p.last)/3600000;
  if(h>0.02){
    p.hunger=Math.max(0,p.hunger-4*h);p.clean=Math.max(0,p.clean-3*h);p.fun=Math.max(0,p.fun-5*h);p.last=Date.now();
  }
  return p;
}
function petStage(care){
  var S=[[0,"نوزاد 🍼"],[15,"بچه 🧒"],[50,"نوجوان 🧑"],[120,"جوان 💪"],[250,"بزرگسال 😎"],[500,"بزرگ‌تر خونواده 👑"]],r=S[0][1];
  S.forEach(function(x){if(care>=x[0])r=x[1]});return r;
}
function gPet(el){
  var p=petGet();
  var age=1+Math.floor(p.care/12),size=40+Math.min(60,p.care/6),mood=(p.hunger+p.clean+p.fun)/3;
  function bar(v,c,l){return '<div style="margin:6px 0"><div class="row sp mut" style="font-size:12px"><span>'+l+'</span><span>'+faN(Math.round(v))+'٪</span></div><div class="bar"><i style="width:'+Math.max(2,v)+'%;background:'+c+'"></i></div></div>'}
  var face=mood<25?"😭":mood<50?"😕":mood>80?"😍":"🙂";
  var flies=p.clean<35?'<span style="position:absolute;top:10px;right:20%;font-size:22px">🪰</span><span style="position:absolute;top:50px;left:18%;font-size:18px">🪰</span>':"";
  var cl=p.clo?'<span class="pc" style="font-size:'+(size*.5)+'px">'+p.clo+'</span>':"";
  var ht=p.hat?'<span class="ph" style="font-size:'+(size*.45)+'px">'+p.hat+'</span>':"";
  el.innerHTML='<div class="pet"><div class="pp" style="font-size:'+size+'px">💩'+ht+cl+'</div>'+flies+'<span style="position:absolute;top:8px;left:10px;font-size:26px">'+face+'</span></div>'+
    '<div class="card"><div class="row sp"><b>'+esc(p.name)+'</b><span class="badge b-ok">'+faN(age)+' ساله • '+petStage(p.care)+'</span></div>'+
    bar(p.hunger,"#f4a73d","🍽️ سیری")+bar(p.clean,"#4bb7e8","🛁 تمیزی")+bar(p.fun,"#e0559e","🎮 سرگرمی")+
    '<div class="mut" style="font-size:12px;margin-top:4px">هر مراقبت یه امتیاز رشد می‌ده: '+faN(p.care)+' • هرچی بیشتر مراقبت کنی بزرگ‌تر و مسن‌تر می‌شه. (سارا: «این پت منه، ولی تو نگهش‌دار 😂»)</div></div>'+
    '<div class="card"><b>🍽️ غذا</b><div class="row" style="flex-wrap:wrap;margin-top:6px"><button class="btn sm" data-f="apple">🍎 سیب (۳🪙)</button><button class="btn sm" data-f="kebab">🍖 کباب (۸🪙)</button><button class="btn sm" data-f="cake">🍰 کیک (۶🪙)</button><button class="btn sm ghost" data-f="free">🥣 غذای ساده (رایگان)</button></div></div>'+
    '<div class="card"><div class="row" style="flex-wrap:wrap"><button class="btn sm gold" data-a="clean">🛁 حمومش کن</button><button class="btn sm gold" data-a="play">⚽ بازیش بده</button><button class="btn sm gold" data-a="pat">🤗 نوازشش کن</button><button class="btn sm ghost" data-a="name">✏️ اسم</button></div></div>'+
    '<div class="card"><b>🎩 کلاه</b><div class="row" style="flex-wrap:wrap;margin-top:6px">'+PET_HATS.map(function(h,i){return '<button class="btn sm '+(p.hat===h[0]?"gold":"ghost")+'" data-h="'+i+'">'+(h[0]||"✖")+' '+h[1]+(h[2]&&!p.own["h"+i]?" ("+faN(h[2])+"🪙)":"")+'</button>'}).join("")+'</div>'+
    '<b style="display:block;margin-top:10px">👕 لباس</b><div class="row" style="flex-wrap:wrap;margin-top:6px">'+PET_CLO.map(function(h,i){return '<button class="btn sm '+(p.clo===h[0]?"gold":"ghost")+'" data-c="'+i+'">'+(h[0]||"✖")+' '+h[1]+(h[2]&&!p.own["c"+i]?" ("+faN(h[2])+"🪙)":"")+'</button>'}).join("")+'</div></div>';
  function done(m){gSave();toast(m);renderGame()}
  var FD={apple:[3,20,0,"ممنون! 🍎"],kebab:[8,40,0,"خوشمزه بود! 🍖"],cake:[6,30,10,"جیغ‌جیغ‌شادی! 🍰"]};
  el.querySelectorAll("[data-f]").forEach(function(b){b.onclick=function(){
    var k=b.dataset.f;
    if(k==="free"){if(Date.now()-p.freeFeed<3*3600000){toast("هنوز گشنه نیست؛ بعد از چند ساعت دوباره");return}p.freeFeed=Date.now();p.hunger=Math.min(100,p.hunger+12);p.care++;done("خورد 🥣");return}
    var f=FD[k];if(G.coins<f[0]){toast("سکه‌ات کمه 🪙");return}
    G.coins-=f[0];p.hunger=Math.min(100,p.hunger+f[1]);p.fun=Math.min(100,p.fun+f[2]);p.care++;done(f[3]);
  }});
  el.querySelectorAll("[data-a]").forEach(function(b){b.onclick=function(){
    var k=b.dataset.a;
    if(k==="clean"){p.clean=100;p.care++;done("برق می‌زنه! ✨")}
    else if(k==="play"){if(p.hunger<15){toast("گشنه‌ست؛ اول غذا بده 🍽️");return}p.fun=Math.min(100,p.fun+25);p.hunger=Math.max(0,p.hunger-6);p.care++;done("کلی خندید ⚽")}
    else if(k==="pat"){p.fun=Math.min(100,p.fun+8);p.care+=0.3;done("نازش کردی 🤗")}
    else if(k==="name"){var n=prompt?null:null;openSheet('<h3>اسم پت</h3><input id="pn" value="'+esc(p.name)+'"><button class="btn gold full" id="pnOk" style="margin-top:10px">ذخیره</button>');document.getElementById("pnOk").onclick=function(){var v=document.getElementById("pn").value.trim();if(v){p.name=v.slice(0,16);gSave()}closeSheet();renderGame()}}
  }});
  function buy(prefix,list,i,field){
    var it=list[i];
    if(it[2]&&!p.own[prefix+i]){if(G.coins<it[2]){toast("سکه‌ات کمه 🪙");return}G.coins-=it[2];p.own[prefix+i]=1;p.care+=2}
    p[field]=it[0];done(it[0]?"پوشید! "+it[0]:"درآورد");
  }
  el.querySelectorAll("[data-h]").forEach(function(b){b.onclick=function(){buy("h",PET_HATS,+b.dataset.h,"hat")}});
  el.querySelectorAll("[data-c]").forEach(function(b){b.onclick=function(){buy("c",PET_CLO,+b.dataset.c,"clo")}});
  gSave();
}
