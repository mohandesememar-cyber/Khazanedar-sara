package app.khazanehdar

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import java.util.Locale

object Notifier {
    const val CH = "khazane"
    const val CH_ON = "khazane_on"
    const val EXTRA_ID = "txid"
    const val EXTRA_CAT = "cat"
    const val EXTRA_SENDER = "sender"
    const val EXTRA_MODE = "mode"
    const val KEY_REPLY = "reply"

    const val NOTIF_TX = 1000
    const val NOTIF_DEBT = 50
    const val NOTIF_REPORT = 51
    const val NOTIF_INST = 60
    const val NOTIF_ONGOING = 70

    fun fa(n: Long): String {
        val s = String.format(Locale.US, "%,d", Math.abs(n))
        val sb = StringBuilder()
        if (n < 0) sb.append('−')
        for (ch in s) sb.append(if (ch in '0'..'9') ('۰' + (ch - '0')) else if (ch == ',') '٬' else ch)
        return sb.toString()
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH) == null) {
                val ch = NotificationChannel(CH, "خزانه‌دار", NotificationManager.IMPORTANCE_HIGH)
                ch.description = "سوال‌های خزانه‌دار و یادآوری طلب‌ها و اقساط"
                nm.createNotificationChannel(ch)
            }
            if (nm.getNotificationChannel(CH_ON) == null) {
                val ch = NotificationChannel(CH_ON, "یادآور دائمی قسط", NotificationManager.IMPORTANCE_LOW)
                ch.description = "همیشه نشون می‌ده چند روز تا قسط بعدی مونده"
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun builder(ctx: Context, channel: String): android.app.Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(ctx, channel)
        else @Suppress("DEPRECATION") android.app.Notification.Builder(ctx)
    }

    private fun immutableFlag() = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    private fun mutableFlag() = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0

    private fun openApp(ctx: Context, code: Int, report: IntArray?, txId: Long = -1): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        if (report != null) {
            i.putExtra("open", "report").putExtra("y", report[0]).putExtra("m", report[1])
        } else if (txId >= 0) {
            // ضربه روی اعلان تراکنش: مستقیم برگه‌ی همون تراکنش باز می‌شه
            i.putExtra("open", "tx").putExtra("id", txId)
        }
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag())
    }

    private fun typedAction(ctx: Context, code: Int, label: String, hint: String, extras: Intent): android.app.Notification.Action? {
        if (Build.VERSION.SDK_INT < 24) return null
        val ri = RemoteInput.Builder(KEY_REPLY).setLabel(hint).build()
        val pi = PendingIntent.getBroadcast(ctx, code, extras, PendingIntent.FLAG_UPDATE_CURRENT or mutableFlag())
        return android.app.Notification.Action.Builder(null, label, pi).addRemoteInput(ri).build()
    }

    /** اعلان «این پول برای چی بود؟» با دکمه‌های سریع و کادر پاسخ */
    fun askReason(ctx: Context, id: Long, bank: String, kind: String, amount: Long) {
        ensureChannel(ctx)
        val isIn = kind == "in"
        val title = if (isIn) "🪙 ${fa(amount)} تومان رسید به $bank!" else "💸 ${fa(amount)} تومان از $bank پرید!"
        val text = if (isIn) "خوشحالیم! ولی از کجا اومد؟ بگو تا ثبت کنم." else "پول که بی‌دلیل پر نمی‌کشه. این خرج چی بود؟"

        val b = builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx, id.toInt(), null, id))
            .setAutoCancel(true)

        val dflt = if (isIn) listOf("حقوق", "مشتری", "متفرقه") else listOf("خورد و خوراک", "حمل‌ونقل", "خرید")
        val quick = try { Db.get(ctx).topCats(if (isIn) "in" else "out", 3).ifEmpty { dflt } } catch (e: Exception) { dflt }
        for ((n, cat) in quick.withIndex()) {
            val i = Intent(ctx, ActionReceiver::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_CAT, cat)
            val pi = PendingIntent.getBroadcast(ctx, (id * 10 + n).toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag())
            b.addAction(android.app.Notification.Action.Builder(null, cat, pi).build())
        }
        typedAction(ctx, (id * 10 + 9).toInt(), "✍️ بنویس", "علتش چی بود؟", Intent(ctx, ActionReceiver::class.java).putExtra(EXTRA_ID, id))
            ?.let { b.addAction(it) }
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_TX + id.toInt(), b.build())
    }

    /** بانک معلوم نیست: می‌پرسه و برای همیشه اون شماره رو یاد می‌گیره */
    fun askBank(ctx: Context, id: Long, sender: String, kind: String, amount: Long) {
        ensureChannel(ctx)
        val title = "🏦 این پیامک از کدوم بانکه؟"
        val text = "یه ${if (kind == "in") "واریز" else "برداشت"} ${fa(amount)} تومانی از شماره‌ی $sender رسید. اسم بانک رو بنویس تا از این به بعد بشناسمش."
        val b = builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx, id.toInt(), null, id))
            .setAutoCancel(true)
        val extras = Intent(ctx, ActionReceiver::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_SENDER, sender).putExtra(EXTRA_MODE, "bank")
        typedAction(ctx, (id * 10 + 8).toInt(), "✍️ اسم بانک", "مثلاً: ملی", extras)?.let { b.addAction(it) }
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_TX + id.toInt(), b.build())
    }

    fun simple(ctx: Context, nid: Int, title: String, text: String, report: IntArray? = null) {
        ensureChannel(ctx)
        val n = builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx, nid, report))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(nid, n)
    }

    fun cancel(ctx: Context, nid: Int) {
        ctx.getSystemService(NotificationManager::class.java).cancel(nid)
    }

    /** اعلان همیشگی: چند روز تا نزدیک‌ترین قسط مونده */
    fun refreshOngoing(ctx: Context) {
        ensureChannel(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val list = Db.get(ctx).insts(true)
        if (list.length() == 0) {
            nm.cancel(NOTIF_ONGOING)
            return
        }
        val o = list.getJSONObject(0)
        val today = Jalali.startOfDay(System.currentTimeMillis())
        val due = Jalali.startOfDay(o.getLong("due"))
        val days = Math.round((due - today) / 86400000.0).toInt()
        val title = o.getString("title")
        val amt = fa(o.getLong("amount"))
        val (head, body) = when {
            days > 1 -> "⏳ ${fa(days.toLong())} روز مانده تا قسط «$title»" to "مبلغ: $amt تومان • موعد: ${dateFa(o.getLong("due"))}"
            days == 1 -> "⏰ فردا قسط «$title» رو باید بدی" to "مبلغ: $amt تومان"
            days == 0 -> "💳 امروز قسط «$title» رو پرداخت کن!" to "مبلغ: $amt تومان؛ دیرتر شه جریمه می‌شی 😬"
            else -> "😱 قسط «$title» ${fa((-days).toLong())} روز عقب افتاده!" to "مبلغ: $amt تومان؛ هرچه زودتر پرداخت کن"
        }
        val n = builder(ctx, CH_ON)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(head)
            .setContentText(body)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx, NOTIF_ONGOING, null))
            .build()
        nm.notify(NOTIF_ONGOING, n)
    }

    fun dateFa(ms: Long): String {
        val j = Jalali.fromMillis(ms)
        return "${fa(j[2].toLong())} ${Jalali.MONTHS[j[1] - 1]}"
    }

    // ---------- آلارم‌های روزانه (ساعت دلخواه): طلب‌ها و اقساط ----------

    fun scheduleDaily(ctx: Context) {
        schedule(ctx, 7, "debt", Prefs.debtH(ctx), Prefs.debtM(ctx))
        schedule(ctx, 8, "inst", Prefs.instH(ctx), Prefs.instM(ctx))
    }

    private fun schedule(ctx: Context, code: Int, kind: String, h: Int, m: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        val pi = PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, AlarmReceiver::class.java).putExtra("k", kind),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        else am.set(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }
}
