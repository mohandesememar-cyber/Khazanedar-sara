package app.khazanehdar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone

/** حالت بازی: امتیاز، سطح، شخصیت، نشان‌ها. همه از روی داده‌های واقعی حساب می‌شه. */
object Game {
    private val TITLES = arrayOf(
        "تخم اژدها 🥚", "اژدهای نوزاد 🐣", "اژدهای کنجکاو 🐲", "اژدهای زرنگ 🐉", "جنگجوی جوان ⚔️",
        "نگهبان خزانه 🛡️", "جادوگر پول 🔮", "سلطان طلا 👑", "اژدهای افسانه‌ای 🌟", "خدای خزانه ✨"
    )
    private val GEAR = arrayOf(
        "", "🧣 شال گردن", "🎒 کوله‌پشتی", "⚔️ شمشیر", "🛡️ سپر", "🔮 گوی جادویی", "👑 تاج", "🪽 بال‌های طلایی", "🌈 هاله‌ی رنگین‌کمان"
    )

    private fun dayIdx(ts: Long) = (ts + TimeZone.getDefault().getOffset(ts)) / 86400000L

    fun stats(ctx: Context): JSONObject {
        val db = Db.get(ctx)
        val now = System.currentTimeMillis()
        val recorded = db.recordedCount()
        val debtsPaid = db.paidDebtsCount()
        val instPaid = Prefs.instPaid(ctx)
        val invoices = try { JSONArray(Prefs.invHist(ctx)).length() } catch (e: Exception) { 0 }
        val pending = db.pendingCount()

        val rows = db.gameRows(now - 400L * 86400000L)
        // روزهای پشت‌سرهم ثبت (تراکنش تأییدشده)
        val days = HashSet<Long>()
        val inM = HashMap<Int, Long>()
        val outM = HashMap<Int, Long>()
        for (r in rows) {
            if (r[3] == 0L) days.add(dayIdx(r[0]))
            val j = Jalali.fromMillis(r[0])
            val k = j[0] * 100 + j[1]
            if (r[1] == 1L) inM[k] = (inM[k] ?: 0L) + r[2] else outM[k] = (outM[k] ?: 0L) + r[2]
        }
        var streak = 0
        var d = dayIdx(now)
        if (!days.contains(d)) d-- // امروز هنوز ثبت نشده؟ دیروز رو بشمار
        while (days.contains(d)) { streak++; d-- }

        val cj = Jalali.fromMillis(now)
        val curKey = cj[0] * 100 + cj[1]
        val pj = if (cj[1] == 1) intArrayOf(cj[0] - 1, 12) else intArrayOf(cj[0], cj[1] - 1)
        val prevKey = pj[0] * 100 + pj[1]
        var green = 0
        var growth = 0
        val keys = (inM.keys + outM.keys).toSortedSet()
        var prevIn = 0L
        for (k in keys) {
            val i = inM[k] ?: 0L
            val o = outM[k] ?: 0L
            if (i > 0 && i > o && k != curKey) green++
            if (prevIn > 0 && i > prevIn && k != curKey) growth++
            prevIn = i
        }
        val curIn = inM[curKey] ?: 0L
        val prevInM = inM[prevKey] ?: 0L
        val growing = prevInM > 0 && curIn > prevInM

        val xp = recorded * 5L + debtsPaid * 40L + instPaid * 30L + invoices * 25L +
            green * 100L + growth * 60L + streak * 8L + (if (growing) 50L else 0L)
        var level = 1
        while (level < 10 && xp >= 60L * level * level) level++
        val base = if (level == 1) 0L else 60L * (level - 1) * (level - 1)
        val next = if (level >= 10) base else 60L * level * level
        val prog = if (level >= 10) 100 else (((xp - base) * 100) / (next - base)).toInt()

        val badges = JSONArray()
        fun badge(id: String, icon: String, title: String, desc: String, cur: Long, target: Long) {
            badges.put(JSONObject().put("id", id).put("icon", icon).put("title", title).put("desc", desc)
                .put("cur", minOf(cur, target)).put("target", target).put("ok", cur >= target))
        }
        badge("r1", "🧾", "اولین فیش", "اولین تراکنش رو تأیید کن", recorded.toLong(), 1)
        badge("r2", "📒", "فیش‌باز", "۵۰ تراکنش ثبت کن", recorded.toLong(), 50)
        badge("r3", "📚", "بایگان کل", "۲۵۰ تراکنش ثبت کن", recorded.toLong(), 250)
        badge("s1", "🔥", "سه روز پشت‌هم", "سه روز پشت‌سرهم ثبت کن", streak.toLong(), 3)
        badge("s2", "⚡", "هفته‌ی آتشین", "هفت روز پشت‌سرهم", streak.toLong(), 7)
        badge("s3", "🌋", "ماه آتشفشانی", "سی روز پشت‌سرهم", streak.toLong(), 30)
        badge("d1", "🕵️", "طلبکار موفق", "یه طلب رو وصول کن", debtsPaid.toLong(), 1)
        badge("d2", "🦈", "کوسه‌ی وصول", "۱۰ طلب رو وصول کن", debtsPaid.toLong(), 10)
        badge("i1", "🧮", "قسط‌پرداز", "۳ قسط رو به‌موقع پرداخت کن", instPaid.toLong(), 3)
        badge("v1", "🖋️", "فاکتورساز", "اولین فاکتور رو بساز", invoices.toLong(), 1)
        badge("v2", "🏭", "کارخانه‌ی فاکتور", "۱۰ فاکتور بساز", invoices.toLong(), 10)
        badge("g1", "🟢", "ماه سبز", "یه ماه درآمدت از خرجت بیشتر باشه", green.toLong(), 1)
        badge("g2", "📈", "رشد درآمد", "درآمد یه ماه از ماه قبل بیشتر بشه", (growth + (if (growing) 1 else 0)).toLong(), 1)
        badge("c1", "🧹", "اتاق تمیز", "همه‌ی تراکنش‌ها رو تأیید کن (و حداقل ۵ تا ثبت داشته باش)", if (pending == 0 && recorded >= 5) 1L else 0L, 1)

        val gear = JSONArray()
        for (i in 1 until minOf(level, GEAR.size + 1)) if (i < GEAR.size) gear.put(GEAR[i])

        return JSONObject()
            .put("xp", xp).put("level", level).put("title", TITLES[level - 1])
            .put("base", base).put("next", next).put("prog", prog)
            .put("streak", streak).put("recorded", recorded).put("pending", pending)
            .put("growing", growing).put("badges", badges).put("gear", gear)
            .put("invoices", invoices).put("debtsPaid", debtsPaid).put("instPaid", instPaid)
            .put("seen", Prefs.lvlSeen(ctx))
    }
}
