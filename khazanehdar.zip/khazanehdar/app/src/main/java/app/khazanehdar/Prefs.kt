package app.khazanehdar

import android.content.Context

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("khz", Context.MODE_PRIVATE)

    fun lastReport(ctx: Context): String = p(ctx).getString("lastReport", "") ?: ""
    fun setLastReport(ctx: Context, v: String) = p(ctx).edit().putString("lastReport", v).apply()

    /** شمارنده‌ای که UI بررسی می‌کنه تا بفهمه داده عوض شده */
    fun bumpUi(ctx: Context) {
        val n = p(ctx).getLong("uiVer", 0) + 1
        p(ctx).edit().putLong("uiVer", n).apply()
    }

    fun uiVer(ctx: Context): Long = p(ctx).getLong("uiVer", 0)

    fun imported(ctx: Context): Boolean = p(ctx).getBoolean("imported2", false)
    fun setImported(ctx: Context) = p(ctx).edit().putBoolean("imported2", true).apply()

    // ساعت یادآوری طلب‌ها و اقساط (هر کدوم جدا)
    fun debtH(ctx: Context) = p(ctx).getInt("debtH", 9)
    fun debtM(ctx: Context) = p(ctx).getInt("debtM", 0)
    fun instH(ctx: Context) = p(ctx).getInt("instH", 9)
    fun instM(ctx: Context) = p(ctx).getInt("instM", 0)
    fun setDebtTime(ctx: Context, h: Int, m: Int) = p(ctx).edit().putInt("debtH", h).putInt("debtM", m).apply()
    fun setInstTime(ctx: Context, h: Int, m: Int) = p(ctx).edit().putInt("instH", h).putInt("instM", m).apply()

    // اطلاعات ثابت فاکتور (JSON)
    fun invoiceCfg(ctx: Context): String = p(ctx).getString("invCfg", "{}") ?: "{}"
    fun setInvoiceCfg(ctx: Context, j: String) = p(ctx).edit().putString("invCfg", j).apply()

    // تاریخچه‌ی فاکتورها (JSON آرایه)
    fun invHist(ctx: Context): String = p(ctx).getString("invHist", "[]") ?: "[]"
    fun setInvHist(ctx: Context, j: String) = p(ctx).edit().putString("invHist", j).apply()

    // بازی
    fun instPaid(ctx: Context) = p(ctx).getInt("instPaid", 0)
    fun bumpInstPaid(ctx: Context) = p(ctx).edit().putInt("instPaid", instPaid(ctx) + 1).apply()
    fun lvlSeen(ctx: Context) = p(ctx).getInt("lvlSeen", 0)
    fun setLvlSeen(ctx: Context, n: Int) = p(ctx).edit().putInt("lvlSeen", n).apply()

    // نرخ دلار و طلا
    fun news(ctx: Context): String = p(ctx).getString("news", "") ?: ""
    fun setNews(ctx: Context, v: String) { p(ctx).edit().putString("news", v).apply() }

    fun rates(ctx: Context): String = p(ctx).getString("rates", "") ?: ""
    fun setRates(ctx: Context, j: String) = p(ctx).edit().putString("rates", j).apply()

    fun gstate(ctx: Context): String = p(ctx).getString("gstate", "{}") ?: "{}"
    fun setGstate(ctx: Context, j: String) = p(ctx).edit().putString("gstate", j).apply()
    fun ratesHist(ctx: Context): String = p(ctx).getString("rhist", "[]") ?: "[]"
    fun setRatesHist(ctx: Context, j: String) = p(ctx).edit().putString("rhist", j).apply()
}
