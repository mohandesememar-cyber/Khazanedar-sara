package app.khazanehdar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * اخبار فاندامنتال برای پیش‌بینی: تیتر خبرهای فارسی و جهانی از Google News RSS خونده می‌شه
 * و با کلیدواژه‌های صعودی/نزولی امتیاز می‌گیره (تحلیل ساده، نه هوش مصنوعی).
 */
object News {
    @Volatile var running = false

    private class Q(val key: String, val label: String, val q: String, val fa: Boolean)

    private val QUERIES = listOf(
        Q("usd", "دلار", "قیمت دلار بازار آزاد", true),
        Q("usd", "دلار (جهانی)", "Iran rial sanctions talks", false),
        Q("gold18", "طلا", "قیمت طلا و سکه", true),
        Q("gold18", "طلا (جهانی)", "gold price Federal Reserve", false),
        Q("world", "رویدادهای جهانی", "Middle East oil Fed inflation war", false)
    )

    // امتیاز مثبت = فشار صعودی روی قیمت (دلار/طلا/سکه به تومان)
    private val UP = listOf(
        "افزایش", "صعود", "جهش", "رکورد", "گران", "بحران", "تنش", "تحریم", "جنگ", "حمله", "اسنپ‌بک", "نگرانی", "تورم", "کاهش ارزش",
        "surge", "record", "rally", "jump", "soar", "war", "attack", "tension", "sanction", "escalat", "safe-haven", "safe haven",
        "rate cut", "weak dollar", "inflation fears", "missile", "strike"
    )
    private val DOWN = listOf(
        "کاهش قیمت", "ریزش", "نزول", "افت", "ارزان", "مذاکره", "توافق", "برجام", "رفع تحریم", "آرامش", "آتش‌بس", "کاهش تنش", "ثبات",
        "plunge", "drop", "fall", "slump", "ceasefire", "deal", "talks", "agreement", "rate hike", "strong dollar", "easing", "de-escalat"
    )

    private fun fetch(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 9000; c.readTimeout = 9000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return try { if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun clean(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").trim()

    private fun score(t: String): Int {
        val l = t.lowercase()
        var s = 0
        for (k in UP) if (l.contains(k)) s++
        for (k in DOWN) if (l.contains(k)) s--
        return s.coerceIn(-2, 2)
    }

    fun refresh(ctx: Context) {
        if (running) return
        running = true
        Thread {
            try {
                val res = HashMap<String, JSONArray>()
                val ITEM = Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL)
                val TT = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
                for (q in QUERIES) {
                    try {
                        val u = "https://news.google.com/rss/search?q=" + URLEncoder.encode(q.q, "UTF-8") +
                            (if (q.fa) "&hl=fa&gl=IR&ceid=IR:fa" else "&hl=en-US&gl=US&ceid=US:en")
                        val body = fetch(u) ?: continue
                        val arr = res.getOrPut(q.key) { JSONArray() }
                        var n = 0
                        for (m in ITEM.findAll(body)) {
                            if (n >= 8) break
                            val t = TT.find(m.groupValues[1])?.groupValues?.get(1)?.let { clean(it) } ?: continue
                            arr.put(JSONObject().put("t", t).put("s", score(t)).put("g", q.label))
                            n++
                        }
                    } catch (e: Exception) { }
                }
                if (res.isEmpty()) return@Thread
                val out = JSONObject()
                for ((k, arr) in res) {
                    var sum = 0
                    for (i in 0 until arr.length()) sum += arr.getJSONObject(i).getInt("s")
                    out.put(k, JSONObject().put("score", sum).put("n", arr.length()).put("items", arr))
                }
                out.put("ts", System.currentTimeMillis())
                Prefs.setNews(ctx, out.toString())
            } catch (e: Throwable) {
            } finally { running = false }
        }.start()
    }
}
