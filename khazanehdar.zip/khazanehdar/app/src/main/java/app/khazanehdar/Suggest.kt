package app.khazanehdar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * گزارش ماهانه + پیشنهاد صرفه‌جویی بر پایه‌ی اصول رایج مدیریت مالی شخصی:
 *  - قانون ۵۰/۳۰/۲۰ (نیازها / خواسته‌ها / پس‌انداز و سرمایه‌گذاری)
 *  - اول به خودت بپرداز (Pay yourself first)
 *  - صندوق اضطراری ۳ تا ۶ ماه هزینه
 *  - سقف حدود ۳۰ تا ۳۵ درصد درآمد برای اقساط
 *  - تنوع‌بخشی دارایی در برابر تورم
 * فقط از «خواسته‌ها» کم می‌کنه، نه از نیازهای ضروری.
 */
object Suggest {
    private val NEEDS = setOf(
        "خورد و خوراک", "خرید خونه", "قسط", "ماشین", "داروخانه", "حمل‌ونقل", "قبوض",
        "سلامت", "اجاره/خانه", "آموزش", "خرید دفتر", "کار"
    )
    private val WANTS = setOf(
        "رستوران", "کافی‌شاپ", "اسنپ‌فود", "خرید", "لباس", "آرایشی بهداشتی", "تفریح",
        "خرج پشمک", "هدیه", "پول توجیبی", "باشگاه"
    )
    private val SAVE = setOf("پس‌انداز", "طلا")

    fun forMonth(ctx: Context, jy: Int, jm: Int): JSONObject {
        val db = Db.get(ctx)
        val ny = if (jm == 12) jy + 1 else jy
        val nm = if (jm == 12) 1 else jm + 1
        val from = Jalali.monthStart(jy, jm)
        val to = Jalali.monthStart(ny, nm)
        val s = db.summary(from, to)
        val inc = s.getLong("in")
        val out = s.getLong("out")
        val outs = db.catSums(from, to, "out")
        val ins = db.catSums(from, to, "in")
        val cats = JSONArray()
        for ((n, v) in outs) cats.put(JSONObject().put("name", n).put("sum", v))
        val srcs = JSONArray()
        for ((n, v) in ins) srcs.put(JSONObject().put("name", n).put("sum", v))

        var needs = 0L; var wants = 0L; var saved = 0L; var other = 0L
        for ((n, v) in outs) when {
            n in SAVE -> saved += v
            n in NEEDS -> needs += v
            n in WANTS -> wants += v
            else -> other += v
        }
        val spent = needs + wants + other
        val savings = saved + maxOf(0L, inc - out)
        val rate = if (inc > 0) (savings * 100 / inc).toInt() else 0

        // اقساط ماهانه‌ی باز
        var inst = 0L
        val ia = db.insts(true)
        for (i in 0 until ia.length()) inst += ia.getJSONObject(i).getLong("amount")

        // کم‌کردن فقط از «خواسته‌ها» تا رسیدن به ۲۰٪ پس‌انداز
        val sug = ArrayList<JSONObject>()
        var total = 0L
        if (inc > 0 && wants > 0) {
            val gap = inc / 5 - savings
            if (gap > 0) {
                val cap = minOf(gap, wants * 35 / 100)
                for ((n, v) in outs) {
                    if (n !in WANTS || v <= 0) continue
                    var cut = cap * v / wants
                    cut = minOf(cut, v * 40 / 100)
                    if (cut < 1000) continue
                    val pct = (cut * 100 / v).toInt().coerceAtLeast(1)
                    sug.add(JSONObject().put("cat", n).put("spent", v).put("pct", pct).put("save", cut))
                    total += cut
                }
                sug.sortByDescending { it.getLong("save") }
            }
        }
        val top = sug.take(4)
        total = top.sumOf { it.getLong("save") }
        val arr = JSONArray()
        for (o in top) arr.put(o)

        // نکته‌های آموزشی
        val tips = JSONArray()
        fun tip(icon: String, title: String, text: String) {
            tips.put(JSONObject().put("icon", icon).put("title", title).put("text", text))
        }
        if (inc > 0) {
            val np = needs * 100 / inc
            val wp = wants * 100 / inc
            tip("⚖️", "قانون ۵۰/۳۰/۲۰",
                "این ماه: نیازها ${Notifier.fa(np)}٪ (هدف حدود ۵۰)، خواسته‌ها ${Notifier.fa(wp)}٪ (هدف حدود ۳۰)، پس‌انداز ${Notifier.fa(rate.toLong())}٪ (هدف حداقل ۲۰).")
            if (rate < 20) {
                tip("🥇", "اول به خودت بپرداز",
                    "به‌جای اینکه بعد از خرج‌ها ببینی چی مونده، همون روز دریافت درآمد ۲۰٪ (حدود ${Notifier.fa(inc / 5)} تومان) رو جدا کن؛ مثل یه قسط به خودت.")
            } else {
                tip("🌱", "نرخ پس‌اندازت عالیه",
                    "پس‌انداز بالای ۲۰٪ یعنی مسیرت درسته. حالا مهم اینه که منظم و بلندمدت ادامه بدی.")
            }
            if (inst > 0 && inst * 100 / inc > 30) {
                tip("🧾", "اقساط سنگینه",
                    "اقساطت حدود ${Notifier.fa(inst * 100 / inc)}٪ درآمده؛ معمولاً توصیه می‌شه از ۳۰ تا ۳۵٪ بالاتر نره. قسط جدید نگیر و اگه می‌شه زودتر یکی رو تسویه کن.")
            }
        }
        if (spent > 0) {
            val fund = spent * 3
            tip("🛟", "صندوق اضطراری",
                "حداقل ۳ ماه هزینه‌ی ضروری (الان حدود ${Notifier.fa(fund)} تومان) به‌صورت نقدشونده کنار بذار؛ ۶ ماه امن‌تره، مخصوصاً با درآمد نامنظم.")
        }
        if (savings > 0) {
            tip("🧺", "تنوع و تورم",
                "پول نقد بی‌سود با تورم ارزشش کم می‌شه. مبنای معمول اینه که پس‌انداز رو یک‌جا نذاری: بخشی نقد برای اضطرار، بخشی دارایی حفظ‌کننده‌ی ارزش (مثل طلا، صندوق درآمد ثابت یا سهام) با افق زمانی بلندتر، و هیچ‌وقت همه‌چیز در یک دارایی. (توصیه‌ی مالی شخصی نیست؛ برای مبلغ بزرگ با مشاور مجاز حرف بزن.)")
        }
        if (spent > 0 && other * 100 / spent > 30) {
            tip("🏷️", "دسته‌بندی کن",
                "بیش از ${Notifier.fa(other * 100 / spent)}٪ خرجت بدون دسته‌ست؛ دسته‌بندی کامل‌تر یعنی پیشنهادهای دقیق‌تر.")
        }

        return JSONObject()
            .put("in", inc).put("out", out)
            .put("cats", cats).put("srcs", srcs).put("sug", arr).put("tips", tips)
            .put("rate", rate).put("needs", needs).put("wants", wants)
            .put("totalSave", total).put("yearSave", total * 12)
    }

    /** متن کوتاه برای اعلان */
    fun text(r: JSONObject): String {
        val inc = r.getLong("in")
        val out = r.getLong("out")
        val sb = StringBuilder()
        sb.append("دخل: ${Notifier.fa(inc)} • خرج: ${Notifier.fa(out)} تومان\n")
        sb.append(if (inc >= out) "آفرین! ${Notifier.fa(inc - out)} تومان پس‌انداز کردی 🎉"
        else "این ماه ${Notifier.fa(out - inc)} تومان بیشتر خرج کردی 🙈")
        if (inc > 0) sb.append("\nنرخ پس‌انداز: ${Notifier.fa(r.getLong("rate"))}٪ (هدف حداقل ۲۰٪)")
        val cats = r.getJSONArray("cats")
        if (cats.length() > 0) {
            val c = cats.getJSONObject(0)
            sb.append("\nبیشترین خرج: ${c.getString("name")} (${Notifier.fa(c.getLong("sum"))})")
        }
        val sug = r.getJSONArray("sug")
        if (sug.length() > 0) {
            val o = sug.getJSONObject(0)
            sb.append("\n💡 برای رسیدن به ۲۰٪ پس‌انداز، ${Notifier.fa(o.getLong("pct"))}٪ از «${o.getString("cat")}» رو کم کن (ماهی ${Notifier.fa(o.getLong("save"))} تومان)")
        }
        return sb.toString()
    }
}
