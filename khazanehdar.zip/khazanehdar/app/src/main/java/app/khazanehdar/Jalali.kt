package app.khazanehdar

import java.util.Calendar

/** تبدیل تاریخ میلادی <-> شمسی (الگوریتم جلالی). همه‌ی مقادیر مثبت‌اند پس تقسیم صحیح درسته. */
object Jalali {
    val MONTHS = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun g2j(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + (if (days < 186) days % 31 else (days - 186) % 30)
        return intArrayOf(jy, jm, jd)
    }

    fun j2g(jyIn: Int, jm: Int, jd: Int): IntArray {
        val jy = jyIn + 1595
        var days = -355668 + (365 * jy) + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
            (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days -= 1
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days += 1
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]
            gm++
        }
        return intArrayOf(gy, gm, gd)
    }

    fun fromMillis(ms: Long): IntArray {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        return g2j(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** نیمه‌شب محلی روز اول ماه شمسی */
    fun monthStart(jy: Int, jm: Int): Long {
        val g = j2g(jy, jm, 1)
        val c = Calendar.getInstance()
        c.clear()
        c.set(g[0], g[1] - 1, g[2], 0, 0, 0)
        return c.timeInMillis
    }

    fun isLeap(jy: Int): Boolean {
        val g = j2g(jy, 12, 30)
        val back = g2j(g[0], g[1], g[2])
        return back[0] == jy && back[1] == 12 && back[2] == 30
    }

    fun monthLen(jy: Int, jm: Int): Int = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        else -> if (isLeap(jy)) 30 else 29
    }

    /** یک ماه شمسی جلوتر (روز ماه در صورت نیاز کوتاه می‌شه)؛ ساعت ۱۲ ظهر */
    fun addMonth(ms: Long): Long {
        val j = fromMillis(ms)
        var y = j[0]
        var m = j[1] + 1
        if (m > 12) { m = 1; y++ }
        val d = minOf(j[2], monthLen(y, m))
        val g = j2g(y, m, d)
        val c = Calendar.getInstance()
        c.clear()
        c.set(g[0], g[1] - 1, g[2], 12, 0, 0)
        return c.timeInMillis
    }

    fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
}
