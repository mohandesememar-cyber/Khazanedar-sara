package app.khazanehdar

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** عدد → حروف فارسی */
object NumWords {
    private val ONES = arrayOf("", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه")
    private val TEENS = arrayOf("ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده")
    private val TENS = arrayOf("", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود")
    private val HUND = arrayOf("", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد")
    private val SCALE = arrayOf("", "هزار", "میلیون", "میلیارد", "تریلیون")

    private fun chunk(n: Int): String {
        val parts = ArrayList<String>()
        val h = n / 100
        val t = (n / 10) % 10
        val o = n % 10
        if (h > 0) parts.add(HUND[h])
        if (t == 1) parts.add(TEENS[o])
        else {
            if (t > 1) parts.add(TENS[t])
            if (o > 0) parts.add(ONES[o])
        }
        return parts.joinToString(" و ")
    }

    fun words(num: Long): String {
        if (num == 0L) return "صفر"
        var n = num
        val groups = ArrayList<Int>()
        while (n > 0) {
            groups.add((n % 1000).toInt())
            n /= 1000
        }
        val parts = ArrayList<String>()
        for (i in groups.indices.reversed()) {
            val g = groups[i]
            if (g == 0) continue
            val s = chunk(g)
            parts.add(if (i == 0) s else "$s ${SCALE[i]}")
        }
        return parts.joinToString(" و ")
    }
}

object Invoice {
    private const val W = 1240f
    private const val H = 1754f

    private fun faDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(if (c in '0'..'9') ('۰' + (c - '0')) else c)
        return sb.toString()
    }

    private fun money(n: Long): String = faDigits(String.format(Locale.US, "%,d", n)).replace(",", "٬")

    private fun fit(p: Paint, text: String, maxW: Float, start: Float, min: Float) {
        var s = start
        p.textSize = s
        while (p.measureText(text) > maxW && s > min) { s -= 2f; p.textSize = s }
    }

    private fun wrap(p: Paint, text: String, maxW: Float): List<String> {
        val out = ArrayList<String>()
        var cur = ""
        for (w in text.split(" ")) {
            val cand = if (cur.isEmpty()) w else "$cur $w"
            if (p.measureText(cand) <= maxW || cur.isEmpty()) cur = cand else { out.add(cur); cur = w }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    /** فاکتور معمولی A4؛ همه‌چیز با کد کشیده می‌شه (برای PNG و PDF) */
    private fun draw(ctx: Context, c: Canvas, d: JSONObject) {
        val tf = fontFace(ctx)
        val ink = Color.parseColor("#1B1B1B")
        val accent = Color.parseColor("#1F3A5F")
        val grey = Color.parseColor("#6B7280")
        val line = Color.parseColor("#CBD2DC")
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.typeface = tf
        val R = W - 70f
        val L = 70f
        fun txt(t: String, x: Float, y: Float, size: Float, color: Int, al: Paint.Align, bold: Boolean = false, maxW: Float = 9999f) {
            if (t.isEmpty()) return
            p.color = color; p.textAlign = al
            p.typeface = if (bold) Typeface.create(tf, Typeface.BOLD) else tf
            fit(p, t, maxW, size, 18f)
            c.drawText(t, x, y, p)
        }
        val unit = d.optString("unit", "تومان")

        // سربرگ
        val bar = Paint(); bar.color = accent
        c.drawRect(0f, 0f, W, 200f, bar)
        txt("فاکتور فروش", R, 118f, 78f, Color.WHITE, Paint.Align.RIGHT, true)
        val shop = d.optString("shop")
        if (shop.isNotEmpty()) txt(shop, R, 168f, 40f, Color.parseColor("#DCE6F5"), Paint.Align.RIGHT, false, 700f)
        val no = d.optString("no")
        txt("تاریخ: " + faDigits(d.optString("date")), L, 100f, 38f, Color.WHITE, Paint.Align.LEFT)
        if (no.isNotEmpty()) txt("شماره: " + faDigits(no), L, 156f, 38f, Color.WHITE, Paint.Align.LEFT)

        // فروشنده / خریدار
        val box = Paint(); box.color = Color.parseColor("#F3F6FB")
        c.drawRoundRect(RectF(L, 240f, W - 70f, 440f), 18f, 18f, box)
        txt("فروشنده", R - 24f, 290f, 34f, grey, Paint.Align.RIGHT)
        txt(shop.ifEmpty { "—" }, R - 24f, 340f, 44f, ink, Paint.Align.RIGHT, true, 520f)
        val tel = d.optString("tel")
        if (tel.isNotEmpty()) txt("تلفن: " + faDigits(tel), R - 24f, 388f, 34f, ink, Paint.Align.RIGHT, false, 520f)
        val nid = d.optString("nid")
        if (nid.isNotEmpty()) txt("کد ملی / شناسه: " + faDigits(nid), R - 24f, 424f, 30f, grey, Paint.Align.RIGHT, false, 520f)
        val mid = W / 2f
        c.drawLine(mid, 262f, mid, 418f, Paint().apply { color = line; strokeWidth = 2f })
        txt("خریدار", mid - 24f, 290f, 34f, grey, Paint.Align.RIGHT)
        txt(faDigits(d.optString("name")).ifEmpty { "—" }, mid - 24f, 340f, 44f, ink, Paint.Align.RIGHT, true, 460f)

        // جدول
        val top = 480f
        val rowH = 78f
        val cx = floatArrayOf(R, R - 80f, R - 550f, R - 660f, R - 875f) // راست هر ستون: ردیف، شرح، تعداد، قیمت واحد، مبلغ
        val hdr = Paint(); hdr.color = accent
        c.drawRoundRect(RectF(L, top, R, top + 70f), 10f, 10f, hdr)
        txt("ردیف", cx[0] - 12f, top + 48f, 32f, Color.WHITE, Paint.Align.RIGHT, true)
        txt("شرح", cx[1] - 12f, top + 48f, 32f, Color.WHITE, Paint.Align.RIGHT, true)
        txt("تعداد", cx[2] - 12f, top + 48f, 32f, Color.WHITE, Paint.Align.RIGHT, true)
        txt("قیمت واحد ($unit)", cx[3] - 12f, top + 48f, 30f, Color.WHITE, Paint.Align.RIGHT, true)
        txt("مبلغ ($unit)", cx[4] - 12f, top + 48f, 30f, Color.WHITE, Paint.Align.RIGHT, true)

        val items = d.optJSONArray("items")
        val n = minOf(items?.length() ?: 0, 14)
        var total = 0L
        var y = top + 70f
        val zebra = Paint(); zebra.color = Color.parseColor("#F8FAFD")
        val lp = Paint(); lp.color = line; lp.strokeWidth = 1.5f
        for (i in 0 until n) {
            val it = items!!.getJSONObject(i)
            val qty = it.optDouble("qty", 1.0).let { q -> if (q <= 0.0) 1.0 else q }
            val price = it.optLong("price", it.optLong("amount", 0))
            val amt = it.optLong("amount", Math.round(qty * price))
            total += amt
            if (i % 2 == 1) c.drawRect(L, y, R, y + rowH, zebra)
            val base = y + 52f
            txt(faDigits((i + 1).toString()), cx[0] - 12f, base, 32f, grey, Paint.Align.RIGHT)
            txt(faDigits(it.optString("desc")), cx[1] - 12f, base, 34f, ink, Paint.Align.RIGHT, false, 446f)
            val qs = if (qty == Math.floor(qty)) qty.toLong().toString() else qty.toString()
            txt(faDigits(qs), cx[2] - 12f, base, 32f, ink, Paint.Align.RIGHT, false, 96f)
            txt(if (price > 0) money(price) else "", cx[3] - 12f, base, 32f, ink, Paint.Align.RIGHT, false, 196f)
            txt(if (amt > 0) money(amt) else "", cx[4] - 12f, base, 34f, ink, Paint.Align.RIGHT, true, 206f)
            c.drawLine(L, y + rowH, R, y + rowH, lp)
            y += rowH
        }
        if (n == 0) y += 20f

        // جمع‌ها
        val discount = d.optLong("discount", 0)
        val prepaid = d.optLong("prepaid", 0)
        val fin = maxOf(0L, total - discount - prepaid)
        y += 24f
        val yStart = y
        val bx = L
        val bw = 520f
        fun sumRow(label: String, v: String, bold: Boolean, fill: Boolean) {
            if (fill) { val fp = Paint(); fp.color = accent; c.drawRoundRect(RectF(bx, y, bx + bw, y + 70f), 10f, 10f, fp) }
            val col = if (fill) Color.WHITE else ink
            txt(label, bx + bw - 16f, y + 48f, 34f, col, Paint.Align.RIGHT, bold)
            txt(v, bx + 16f, y + 48f, 36f, col, Paint.Align.LEFT, true, 280f)
            y += 78f
        }
        sumRow("جمع کل", money(total), false, false)
        if (discount > 0) sumRow("تخفیف", money(discount), false, false)
        if (prepaid > 0) sumRow("پیش‌پرداخت", money(prepaid), false, false)
        sumRow("مبلغ قابل پرداخت ($unit)", money(fin), true, true)
        // جمع به حروف سمت راست
        val words = NumWords.words(fin) + " " + unit
        p.typeface = tf; p.textSize = 36f; p.color = ink; p.textAlign = Paint.Align.RIGHT
        val ws = wrap(p, "مبلغ به حروف: $words", 560f)
        var wy = yStart + 44f
        for (l in ws.take(3)) { c.drawText(l, R, wy, p); wy += 50f }

        y = maxOf(y, wy) + 30f
        // توضیحات
        val note = d.optString("note").trim()
        if (note.isNotEmpty()) {
            txt("توضیحات", R, y + 30f, 32f, grey, Paint.Align.RIGHT)
            p.textSize = 34f; p.color = ink; p.textAlign = Paint.Align.RIGHT
            var ny = y + 78f
            for (l in wrap(p, faDigits(note), R - L).take(3)) { c.drawText(l, R, ny, p); ny += 46f }
            y = ny + 10f
        }

        // پایین: اطلاعات پرداخت + مهر و امضا
        val fy = maxOf(y + 20f, 1330f)
        c.drawLine(L, fy, R, fy, Paint().apply { color = line; strokeWidth = 2f })
        var py = fy + 56f
        val card = d.optString("card").replace(" ", "")
        if (card.isNotEmpty()) { txt("شماره کارت: " + faDigits(card.chunked(4).joinToString(" ")), R, py, 38f, ink, Paint.Align.RIGHT, true, 640f); py += 52f }
        val holder = d.optString("holder")
        if (holder.isNotEmpty()) { txt("به نام: " + faDigits(holder), R, py, 32f, ink, Paint.Align.RIGHT, false, 640f); py += 48f }
        val iban = d.optString("iban").replace(" ", "")
        if (iban.isNotEmpty()) { txt("شبا: IR" + faDigits(iban.removePrefix("IR").removePrefix("ir")), R, py, 32f, ink, Paint.Align.RIGHT, false, 640f); py += 48f }
        val addr = faDigits(d.optString("addr").trim())
        if (addr.isNotEmpty()) {
            p.typeface = tf; p.textSize = 32f; p.color = ink; p.textAlign = Paint.Align.RIGHT
            for (l in wrap(p, "آدرس: $addr", 700f).take(3)) { c.drawText(l, R, py, p); py += 44f }
        }
        // مهر و امضا (فقط اگه کاربر خودش انتخاب کرده باشه)
        txt("مهر و امضا", L + 250f, fy + 56f, 32f, grey, Paint.Align.CENTER)
        if (d.optBoolean("stamp", true) && hasStamp(ctx)) {
            val sb = BitmapFactory.decodeFile(File(ctx.filesDir, "stamp.png").absolutePath)
            if (sb != null) {
                val sp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                sp.xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
                val bw2 = 480f
                val bh2 = minOf(260f, bw2 * sb.height / sb.width)
                val bw3 = bh2 * sb.width / sb.height
                c.drawBitmap(sb, null, RectF(L + 250f - bw3 / 2, fy + 80f, L + 250f + bw3 / 2, fy + 80f + bh2), sp)
            }
        }
        // کف
        txt("ساخته‌شده با خزانه‌دار سارا", W / 2f, H - 40f, 24f, grey, Paint.Align.CENTER)
    }

    fun fontFace(ctx: Context): Typeface {
        val f = File(ctx.filesDir, "nastaliq.ttf")
        if (f.exists()) {
            try {
                return Typeface.createFromFile(f)
            } catch (e: Exception) {
            }
        }
        return Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    fun hasFont(ctx: Context) = File(ctx.filesDir, "nastaliq.ttf").exists()
    fun hasStamp(ctx: Context) = File(ctx.filesDir, "stamp.png").exists()

    fun save(ctx: Context, name: String, mime: String, images: Boolean, dir: String, write: (OutputStream) -> Unit): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
                val col = if (images) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val uri = ctx.contentResolver.insert(col, v) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { write(it) }
                uri
            } else {
                val f = File(ctx.getExternalFilesDir(null), name)
                f.outputStream().use { write(it) }
                Uri.fromFile(f)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** فاکتور رو می‌سازه و PNG و PDF ذخیره می‌کنه */
    fun make(ctx: Context, d: JSONObject): JSONObject {
        val res = JSONObject()
        try {
            val base = Bitmap.createBitmap(W.toInt(), H.toInt(), Bitmap.Config.ARGB_8888)
            val bc = Canvas(base)
            bc.drawColor(Color.WHITE)
            draw(ctx, bc, d)
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val png = save(ctx, "invoice-$stamp.png", "image/png", true, "Pictures/KhazanehdarSara") {
                base.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
            val pc = page.canvas
            pc.scale(595f / W, 842f / H)
            pc.drawColor(Color.WHITE)
            draw(ctx, pc, d)
            doc.finishPage(page)
            val pdf = save(ctx, "invoice-$stamp.pdf", "application/pdf", false, "Download/KhazanehdarSara") { doc.writeTo(it) }
            doc.close()
            val ph = Math.round(700f * H / W)
            val small = Bitmap.createScaledBitmap(base, 700, ph, true)
            val bo = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            res.put("preview", "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))
            res.put("ok", png != null || pdf != null)
            res.put("png", png?.toString() ?: "")
            res.put("pdf", pdf?.toString() ?: "")
            base.recycle(); small.recycle()
        } catch (e: Throwable) {
            res.put("ok", false).put("err", e.toString())
        }
        return res
    }
}
