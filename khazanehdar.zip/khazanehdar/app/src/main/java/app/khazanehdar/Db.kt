package app.khazanehdar

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/** مبلغ‌ها همه به «تومان» ذخیره می‌شن. */
class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "khazane.db", null, 3) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_sender ON tx(sender)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_bank ON tx(bank, acct, ts)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_pend ON tx(pending, ts)")
            db.execSQL("DELETE FROM tx WHERE sender='TEST'")
            db.execSQL("DELETE FROM sender WHERE addr='TEST'")
            db.execSQL("CREATE TABLE IF NOT EXISTS balfix(bank TEXT NOT NULL, acct TEXT NOT NULL DEFAULT '', balance INTEGER NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(bank, acct))")
            migrateAlphaSenders(db)
            makeView(db)
        }
    }

    /** نام فرستنده‌های حرفی به شکل یکسان (بدون فاصله و حروف کوچک) برمی‌گردن */
    private fun migrateAlphaSenders(db: SQLiteDatabase) {
        try {
            val l = ArrayList<String>()
            val c = db.rawQuery("SELECT addr FROM sender", null)
            while (c.moveToNext()) { val a = c.getString(0) ?: continue; if (a.any { it.isLetter() }) l.add(a) }
            c.close()
            for (a in l) {
                val n = Sender.norm(a)
                if (n.isEmpty() || n == a) continue
                db.execSQL("UPDATE OR IGNORE sender SET addr=? WHERE addr=?", arrayOf<Any>(n, a))
                db.execSQL("DELETE FROM sender WHERE addr=?", arrayOf<Any>(a))
                db.execSQL("UPDATE tx SET sender=? WHERE sender=?", arrayOf<Any>(n, a))
            }
        } catch (e: Exception) { }
    }

    /** اصلاح دستی موجودی یک بانک/کارت؛ تا پیامک جدیدتری نیاد همین نشون داده می‌شه */
    @Synchronized
    fun setBalance(bank: String, acct: String, balance: Long) {
        val v = ContentValues()
        v.put("bank", bank); v.put("acct", acct); v.put("balance", balance); v.put("ts", System.currentTimeMillis())
        writableDatabase.insertWithOnConflict("balfix", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun fixOf(bank: String, acct: String): Pair<Long, Long>? {
        val c = readableDatabase.rawQuery("SELECT balance, ts FROM balfix WHERE bank=? AND acct=?", arrayOf(bank, acct))
        val r = if (c.moveToFirst()) Pair(c.getLong(0), c.getLong(1)) else null
        c.close()
        return r
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tx(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "ts INTEGER NOT NULL," +
                "bank TEXT," +
                "acct TEXT," +
                "sender TEXT," +
                "kind TEXT NOT NULL," +
                "amount INTEGER NOT NULL," +
                "balance INTEGER," +
                "category TEXT," +
                "reason TEXT," +
                "pending INTEGER NOT NULL DEFAULT 1," +
                "raw TEXT)"
        )
        db.execSQL("CREATE INDEX idx_tx_ts ON tx(ts)")
        db.execSQL(
            "CREATE TABLE debt(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "amount INTEGER NOT NULL," +
                "note TEXT," +
                "due INTEGER NOT NULL," +
                "paid INTEGER NOT NULL DEFAULT 0," +
                "mine INTEGER NOT NULL DEFAULT 0," +
                "created INTEGER NOT NULL)"
        )
        createV2Tables(db)
    }

    private fun createV2Tables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS inst(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "amount INTEGER NOT NULL," +
                "due INTEGER NOT NULL," +
                "rep INTEGER NOT NULL DEFAULT 1," +
                "left INTEGER NOT NULL DEFAULT 0," +
                "done INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS sender(" +
                "addr TEXT PRIMARY KEY," +
                "bank TEXT," +
                "enabled INTEGER NOT NULL DEFAULT 1)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS cat(" +
                "name TEXT PRIMARY KEY," +
                "icon TEXT," +
                "kind TEXT NOT NULL," +
                "sort INTEGER NOT NULL DEFAULT 0)"
        )
        seedCats(db)
    }

    private fun seedCats(db: SQLiteDatabase) {
        val list = listOf(
            Triple("خورد و خوراک", "🍜", "out"), Triple("خرید خونه", "🏠", "out"),
            Triple("خرید دفتر", "🗂️", "out"), Triple("خرج پشمک", "🍭", "out"),
            Triple("قسط", "🧾", "out"), Triple("رستوران", "🍽️", "out"),
            Triple("ماشین", "🚗", "out"), Triple("آرایشی بهداشتی", "💄", "out"),
            Triple("لباس", "👕", "out"), Triple("هدیه", "🎁", "both"),
            Triple("کافی‌شاپ", "☕", "out"), Triple("طلا", "🪙", "both"),
            Triple("پس‌انداز", "🐷", "both"), Triple("اسنپ‌فود", "🛵", "out"),
            Triple("داروخانه", "💊", "out"), Triple("پول توجیبی", "👛", "both"),
            Triple("قرض", "🤝", "both"), Triple("باشگاه", "🏋️", "out"),
            Triple("حمل‌ونقل", "🚕", "out"), Triple("قبوض", "💡", "out"),
            Triple("خرید", "🛍️", "out"), Triple("تفریح", "🎮", "out"),
            Triple("سلامت", "🩺", "out"), Triple("اجاره/خانه", "🏡", "out"),
            Triple("آموزش", "📚", "out"), Triple("کار", "💼", "both"),
            Triple("حقوق", "💎", "in"), Triple("مشتری", "🧑‍💼", "in"),
            Triple("برگشتی", "↩️", "in"), Triple("متفرقه", "🧩", "both")
        )
        for ((i, t) in list.withIndex()) {
            val v = ContentValues()
            v.put("name", t.first)
            v.put("icon", t.second)
            v.put("kind", t.third)
            v.put("sort", i)
            db.insertWithOnConflict("cat", null, v, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE tx ADD COLUMN acct TEXT")
            db.execSQL("ALTER TABLE tx ADD COLUMN sender TEXT")
            createV2Tables(db)
        }
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE debt ADD COLUMN mine INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) { }
        }
    }

    /** تراکنش‌هایی که فقط شماره‌ی مسدودشده ندارن؛ همه‌ی گزارش‌ها از این نما می‌خونن */
    private fun makeView(db: SQLiteDatabase) {
        db.execSQL("DROP VIEW IF EXISTS tv")
        db.execSQL(
            "CREATE VIEW tv AS SELECT * FROM tx WHERE COALESCE(sender,'') NOT IN " +
                "(SELECT addr FROM sender WHERE enabled=0)"
        )
    }

    /** تراکنش‌های ماه‌های قبلی که هنوز بی‌جواب مونده‌ن، دیگه پرسیده نمی‌شن */
    fun expireOldPending() {
        val j = Jalali.fromMillis(System.currentTimeMillis())
        val start = Jalali.monthStart(j[0], j[1])
        writableDatabase.execSQL("UPDATE tx SET pending=0 WHERE pending=1 AND ts<?", arrayOf<Any>(start))
    }

    // ---------- تراکنش‌ها ----------

    /** اگه همین پیامک قبلاً (با اختلاف کمتر از ۳ دقیقه) ثبت شده باشه، -1 برمی‌گردونه */
    @Synchronized
    fun insertSms(
        ts: Long, bank: String, acct: String?, sender: String, kind: String,
        amount: Long, balance: Long?, raw: String, pending: Int
    ): Long {
        val d = writableDatabase
        val c = d.rawQuery(
            "SELECT 1 FROM tx WHERE raw=? AND ts BETWEEN ? AND ? LIMIT 1",
            arrayOf(raw, (ts - 180000).toString(), (ts + 180000).toString())
        )
        val exists = c.moveToFirst()
        c.close()
        if (exists) return -1
        val v = ContentValues()
        v.put("ts", ts)
        v.put("bank", bank)
        if (acct != null) v.put("acct", acct)
        v.put("sender", sender)
        v.put("kind", kind)
        v.put("amount", amount)
        if (balance != null) v.put("balance", balance)
        v.put("pending", pending)
        v.put("raw", raw)
        return d.insert("tx", null, v)
    }

    @Synchronized
    fun insertManual(ts: Long, kind: String, amount: Long, category: String, reason: String): Long {
        val v = ContentValues()
        v.put("ts", ts)
        v.put("bank", "دستی")
        v.put("kind", kind)
        v.put("amount", amount)
        v.put("category", category)
        v.put("reason", reason)
        v.put("pending", 0)
        return writableDatabase.insert("tx", null, v)
    }

    @Synchronized
    fun setReason(id: Long, category: String, reason: String) {
        val v = ContentValues()
        v.put("category", category)
        v.put("reason", reason)
        v.put("pending", 0)
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun updateTx(id: Long, ts: Long, bank: String, kind: String, amount: Long, category: String, reason: String) {
        val v = ContentValues()
        v.put("ts", ts)
        v.put("bank", bank)
        v.put("kind", kind)
        v.put("amount", amount)
        v.put("category", category)
        v.put("reason", reason)
        v.put("pending", 0)
        writableDatabase.update("tx", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun deleteTx(id: Long) {
        writableDatabase.delete("tx", "id=?", arrayOf(id.toString()))
    }

    fun getTx(id: Long): JSONObject? {
        val c = readableDatabase.rawQuery("SELECT * FROM tx WHERE id=?", arrayOf(id.toString()))
        val r = if (c.moveToFirst()) txRow(c, true) else null
        c.close()
        return r
    }

    fun txRange(from: Long, to: Long): JSONArray {
        val c = readableDatabase.rawQuery(
            "SELECT * FROM tv WHERE ts>=? AND ts<? ORDER BY ts DESC",
            arrayOf(from.toString(), to.toString())
        )
        val a = JSONArray()
        while (c.moveToNext()) a.put(txRow(c, false))
        c.close()
        return a
    }

    fun txByBank(bank: String, acct: String): JSONArray {
        val c = readableDatabase.rawQuery(
            "SELECT * FROM tv WHERE bank=? AND COALESCE(acct,'')=? ORDER BY ts DESC LIMIT 60",
            arrayOf(bank, acct)
        )
        val a = JSONArray()
        while (c.moveToNext()) a.put(txRow(c, false))
        c.close()
        return a
    }

    fun pending(): JSONArray {
        expireOldPending()
        val c = readableDatabase.rawQuery("SELECT * FROM tv WHERE pending=1 ORDER BY ts DESC", null)
        val a = JSONArray()
        while (c.moveToNext()) a.put(txRow(c, false))
        c.close()
        return a
    }

    fun pendingCount(): Int {
        expireOldPending()
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM tv WHERE pending=1", null)
        c.moveToFirst()
        val n = c.getInt(0)
        c.close()
        return n
    }

    /** بعد از خواندن همه‌ی پیامک‌های قدیمی: فقط ۱۰۰ تای آخر منتظر سوال می‌مونن */
    @Synchronized
    fun keepLastPending(n: Int) {
        val d = writableDatabase
        d.execSQL("UPDATE tx SET pending=0 WHERE pending=1 AND category IS NULL")
        d.execSQL(
            "UPDATE tx SET pending=1 WHERE category IS NULL AND COALESCE(reason,'')<>'__forgot' AND id IN " +
                "(SELECT id FROM tx WHERE category IS NULL AND COALESCE(reason,'')<>'__forgot' ORDER BY ts DESC LIMIT $n)"
        )
    }

    /** جمع ورودی/خروجی و بیشترین دسته‌ی خرج در یک بازه */
    fun summary(from: Long, to: Long): JSONObject {
        val d = readableDatabase
        var inc = 0L
        var out = 0L
        val c = d.rawQuery(
            "SELECT kind, SUM(amount) FROM tv WHERE ts>=? AND ts<? GROUP BY kind",
            arrayOf(from.toString(), to.toString())
        )
        while (c.moveToNext()) {
            if (c.getString(0) == "in") inc = c.getLong(1) else out = c.getLong(1)
        }
        c.close()
        return JSONObject().put("in", inc).put("out", out)
    }

    fun catSums(from: Long, to: Long, kind: String): List<Pair<String, Long>> {
        val c = readableDatabase.rawQuery(
            "SELECT COALESCE(NULLIF(category,''),'بدون دسته'), SUM(amount) s FROM tv " +
                "WHERE kind=? AND ts>=? AND ts<? GROUP BY 1 ORDER BY s DESC",
            arrayOf(kind, from.toString(), to.toString())
        )
        val r = ArrayList<Pair<String, Long>>()
        while (c.moveToNext()) r.add(Pair(c.getString(0), c.getLong(1)))
        c.close()
        return r
    }

    private fun txRow(c: Cursor, withRaw: Boolean): JSONObject {
        val o = JSONObject()
        o.put("id", c.getLong(c.getColumnIndexOrThrow("id")))
        o.put("ts", c.getLong(c.getColumnIndexOrThrow("ts")))
        o.put("bank", c.getString(c.getColumnIndexOrThrow("bank")) ?: "")
        o.put("acct", c.getString(c.getColumnIndexOrThrow("acct")) ?: "")
        o.put("sender", c.getString(c.getColumnIndexOrThrow("sender")) ?: "")
        o.put("kind", c.getString(c.getColumnIndexOrThrow("kind")))
        o.put("amount", c.getLong(c.getColumnIndexOrThrow("amount")))
        val bi = c.getColumnIndexOrThrow("balance")
        if (!c.isNull(bi)) o.put("balance", c.getLong(bi))
        o.put("category", c.getString(c.getColumnIndexOrThrow("category")) ?: "")
        o.put("reason", c.getString(c.getColumnIndexOrThrow("reason")) ?: "")
        o.put("pending", c.getInt(c.getColumnIndexOrThrow("pending")))
        if (withRaw) o.put("raw", c.getString(c.getColumnIndexOrThrow("raw")) ?: "")
        return o
    }

    // ---------- بانک‌ها ----------

    fun bankSummary(): JSONArray {
        val d = readableDatabase
        val c = d.rawQuery(
            "SELECT bank, COALESCE(acct,'') a, COUNT(*) FROM tv WHERE bank IS NOT NULL AND bank<>'دستی' " +
                "GROUP BY bank, a ORDER BY bank",
            null
        )
        val a = JSONArray()
        val rows = ArrayList<Triple<String, String, Int>>()
        while (c.moveToNext()) rows.add(Triple(c.getString(0), c.getString(1), c.getInt(2)))
        c.close()
        for ((bank, acct, n) in rows) {
            val o = JSONObject()
            o.put("bank", bank)
            o.put("acct", acct)
            o.put("count", n)
            val b = d.rawQuery(
                "SELECT balance, ts FROM tv WHERE bank=? AND COALESCE(acct,'')=? AND balance IS NOT NULL " +
                    "ORDER BY ts DESC LIMIT 1",
                arrayOf(bank, acct)
            )
            if (b.moveToFirst()) {
                o.put("balance", b.getLong(0))
                o.put("balTs", b.getLong(1))
            }
            b.close()
            fixOf(bank, acct)?.let { f ->
                if (!o.has("balTs") || f.second > o.getLong("balTs")) { o.put("balance", f.first); o.put("balTs", f.second); o.put("manual", true) }
            }
            a.put(o)
        }
        // بانک با موجودی بیشتر بالاتر؛ بدون مانده آخر
        val list = ArrayList<JSONObject>()
        for (i in 0 until a.length()) list.add(a.getJSONObject(i))
        list.sortWith(compareByDescending<JSONObject> { if (it.has("balance")) it.getLong("balance") else Long.MIN_VALUE })
        val out = JSONArray()
        for (o in list) out.put(o)
        return out
    }

    // ---------- شماره‌های فرستنده ----------

    fun getSender(addr: String): Pair<String?, Int>? {
        val c = readableDatabase.rawQuery("SELECT bank, enabled FROM sender WHERE addr=?", arrayOf(addr))
        val r = if (c.moveToFirst()) Pair(c.getString(0), c.getInt(1)) else null
        c.close()
        return r
    }

    @Synchronized
    fun upsertSender(addr: String, bank: String?, enabled: Int) {
        val v = ContentValues()
        v.put("addr", addr)
        if (bank != null) v.put("bank", bank)
        v.put("enabled", enabled)
        writableDatabase.insertWithOnConflict("sender", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    fun setSenderBankIfEmpty(addr: String, bank: String) {
        writableDatabase.execSQL(
            "UPDATE sender SET bank=? WHERE addr=? AND (bank IS NULL OR bank='' OR bank='بانک نامشخص')",
            arrayOf(bank, addr)
        )
    }

    @Synchronized
    fun setSenderEnabled(addr: String, enabled: Boolean) {
        writableDatabase.execSQL("UPDATE sender SET enabled=? WHERE addr=?", arrayOf(if (enabled) 1 else 0, addr))
    }

    @Synchronized
    fun deleteSenderRow(addr: String) {
        writableDatabase.delete("sender", "addr=?", arrayOf(addr))
    }

    /** بانک یک شماره رو عوض می‌کنه و همه‌ی تراکنش‌های اون شماره رو هم اصلاح می‌کنه */
    @Synchronized
    fun setBankForSender(addr: String, bank: String) {
        val d = writableDatabase
        val ex = getSender(addr)
        if (ex == null) upsertSender(addr, bank, 1)
        else d.execSQL("UPDATE sender SET bank=? WHERE addr=?", arrayOf(bank, addr))
        d.execSQL("UPDATE tx SET bank=? WHERE sender=?", arrayOf(bank, addr))
    }

    @Synchronized
    fun deleteTxBySender(addr: String) {
        writableDatabase.delete("tx", "sender=?", arrayOf(addr))
    }

    fun senders(): JSONArray {
        val c = readableDatabase.rawQuery(
            "SELECT s.addr, s.bank, s.enabled, IFNULL(t.n,0) n FROM sender s " +
                "LEFT JOIN (SELECT sender, COUNT(*) n FROM tx GROUP BY sender) t ON t.sender=s.addr " +
                "ORDER BY s.enabled DESC, n DESC",
            null
        )
        val a = JSONArray()
        while (c.moveToNext()) {
            val o = JSONObject()
            o.put("addr", c.getString(0))
            o.put("bank", c.getString(1) ?: "")
            o.put("enabled", c.getInt(2))
            o.put("count", c.getInt(3))
            a.put(o)
        }
        c.close()
        return a
    }

    /** شماره‌هایی که تراکنش دارن ولی بانکشون معلوم نیست */
    fun unknownSenders(): JSONArray {
        val c = readableDatabase.rawQuery(
            "SELECT s.addr, t.n FROM sender s " +
                "JOIN (SELECT sender, COUNT(*) n FROM tx GROUP BY sender) t ON t.sender=s.addr " +
                "WHERE s.enabled=1 AND (s.bank IS NULL OR s.bank='' OR s.bank='بانک نامشخص')",
            null
        )
        val a = JSONArray()
        while (c.moveToNext()) a.put(JSONObject().put("addr", c.getString(0)).put("count", c.getInt(1)))
        c.close()
        return a
    }

    /** آخرین مانده‌ی ثبت‌شده‌ی یک بانک/کارت (برای تشخیص جهت تراکنش) */
    fun lastBalance(bank: String, acct: String?): Long? {
        val c = readableDatabase.rawQuery(
            "SELECT balance FROM tv WHERE bank=? AND COALESCE(acct,'')=? AND balance IS NOT NULL ORDER BY ts DESC, id DESC LIMIT 1",
            arrayOf(bank, acct ?: "")
        )
        var r = if (c.moveToFirst()) c.getLong(0) else null
        c.close()
        fixOf(bank, acct ?: "")?.let { f ->
            val c2 = readableDatabase.rawQuery(
                "SELECT MAX(ts) FROM tv WHERE bank=? AND COALESCE(acct,'')=? AND balance IS NOT NULL", arrayOf(bank, acct ?: "")
            )
            val lt = if (c2.moveToFirst()) c2.getLong(0) else 0L
            c2.close()
            if (r == null || f.second > lt) r = f.first
        }
        return r
    }

    /** پیام‌های یک شماره‌ی فرستنده (با متن کامل) */
    fun txBySender(addr: String): JSONArray {
        val c = readableDatabase.rawQuery("SELECT * FROM tx WHERE sender=? ORDER BY ts DESC LIMIT 300", arrayOf(addr))
        val a = JSONArray()
        while (c.moveToNext()) a.put(txRow(c, true))
        c.close()
        return a
    }

    private fun count(sql: String): Int {
        val c = readableDatabase.rawQuery(sql, null)
        c.moveToFirst()
        val n = c.getInt(0)
        c.close()
        return n
    }

    fun recordedCount(): Int = count("SELECT COUNT(*) FROM tv WHERE pending=0 AND category IS NOT NULL")

    /** فراموش کردن یک تراکنش بی‌جواب: دیگه پرسیده نمی‌شه (ولی در جمع دخل‌وخرج می‌مونه) */
    @Synchronized
    fun forgetPending(id: Long) {
        writableDatabase.execSQL("UPDATE tx SET pending=0, reason='__forgot' WHERE id=? AND category IS NULL", arrayOf<Any>(id))
    }

    @Synchronized
    fun forgetAllPending() {
        writableDatabase.execSQL("UPDATE tx SET pending=0, reason='__forgot' WHERE pending=1 AND category IS NULL")
    }

    /** دسته‌ها به ترتیب بیشترین استفاده */
    fun cats(): JSONArray = catsSorted()
    fun paidDebtsCount(): Int = count("SELECT COUNT(*) FROM debt WHERE paid=1")

    /** ردیف‌های سبک برای بازی: ts, kind(1=دخل), amount, pending */
    fun gameRows(since: Long): List<LongArray> {
        val c = readableDatabase.rawQuery(
            "SELECT ts, kind, amount, pending FROM tv WHERE ts>=?", arrayOf(since.toString())
        )
        val r = ArrayList<LongArray>()
        while (c.moveToNext()) r.add(longArrayOf(c.getLong(0), if (c.getString(1) == "in") 1L else 0L, c.getLong(2), c.getLong(3)))
        c.close()
        return r
    }

    // ---------- دسته‌ها ----------

    private fun catsSorted(): JSONArray {
        val c = readableDatabase.rawQuery(
            "SELECT c.name, c.icon, c.kind, (SELECT COUNT(*) FROM tx t WHERE t.category=c.name) u FROM cat c ORDER BY u DESC, c.sort, c.name", null
        )
        val a = JSONArray()
        while (c.moveToNext()) {
            a.put(JSONObject().put("name", c.getString(0)).put("icon", c.getString(1) ?: "🧩").put("kind", c.getString(2)).put("uses", c.getInt(3)))
        }
        c.close()
        return a
    }

    /** پرکاربردترین دسته‌های یک نوع (in/out) برای دکمه‌های اعلان */
    fun topCats(kind: String, n: Int): List<String> {
        val c = readableDatabase.rawQuery(
            "SELECT c.name, (SELECT COUNT(*) FROM tx t WHERE t.category=c.name) u FROM cat c " +
                "WHERE (c.kind=? OR c.kind='both') AND c.name<>'برگشتی' ORDER BY u DESC, c.sort LIMIT $n", arrayOf(kind)
        )
        val r = ArrayList<String>()
        while (c.moveToNext()) r.add(c.getString(0))
        c.close()
        return r
    }

    @Synchronized
    fun saveCat(oldName: String, name: String, icon: String, kind: String) {
        val d = writableDatabase
        if (oldName.isNotEmpty() && oldName != name) {
            d.delete("cat", "name=?", arrayOf(oldName))
            d.execSQL("UPDATE tx SET category=? WHERE category=?", arrayOf(name, oldName))
        }
        val v = ContentValues()
        v.put("name", name)
        v.put("icon", icon)
        v.put("kind", kind)
        val c = d.rawQuery("SELECT COALESCE(MAX(sort),0)+1 FROM cat", null)
        c.moveToFirst()
        v.put("sort", c.getInt(0))
        c.close()
        val n = d.update("cat", ContentValues().apply { put("icon", icon); put("kind", kind) }, "name=?", arrayOf(name))
        if (n == 0) d.insert("cat", null, v)
    }

    @Synchronized
    fun deleteCat(name: String) {
        writableDatabase.delete("cat", "name=?", arrayOf(name))
    }

    // ---------- طلب‌ها ----------

    @Synchronized
    fun addDebt(name: String, amount: Long, due: Long, note: String, mine: Long = 0): Long {
        val v = ContentValues()
        v.put("mine", mine)
        v.put("name", name)
        v.put("amount", amount)
        v.put("note", note)
        v.put("due", due)
        v.put("paid", 0)
        v.put("created", System.currentTimeMillis())
        return writableDatabase.insert("debt", null, v)
    }

    @Synchronized
    fun updateDebt(id: Long, name: String, amount: Long, due: Long, note: String, mine: Long) {
        val v = ContentValues()
        v.put("name", name); v.put("amount", amount); v.put("due", due); v.put("note", note); v.put("mine", mine)
        writableDatabase.update("debt", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun updateInst(id: Long, title: String, amount: Long, due: Long, rep: Boolean, left: Int) {
        val v = ContentValues()
        v.put("title", title); v.put("amount", amount); v.put("due", due); v.put("rep", if (rep) 1 else 0); v.put("left", left)
        writableDatabase.update("inst", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun setDebtPaid(id: Long, paid: Boolean) {
        val v = ContentValues()
        v.put("paid", if (paid) 1 else 0)
        writableDatabase.update("debt", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun deleteDebt(id: Long) {
        writableDatabase.delete("debt", "id=?", arrayOf(id.toString()))
    }

    fun debts(onlyOpen: Boolean): JSONArray {
        val sql = if (onlyOpen) "SELECT * FROM debt WHERE paid=0 ORDER BY due ASC"
        else "SELECT * FROM debt ORDER BY paid ASC, due ASC"
        val c = readableDatabase.rawQuery(sql, null)
        val a = JSONArray()
        while (c.moveToNext()) {
            val o = JSONObject()
            o.put("id", c.getLong(c.getColumnIndexOrThrow("id")))
            o.put("name", c.getString(c.getColumnIndexOrThrow("name")))
            o.put("amount", c.getLong(c.getColumnIndexOrThrow("amount")))
            o.put("note", c.getString(c.getColumnIndexOrThrow("note")) ?: "")
            o.put("due", c.getLong(c.getColumnIndexOrThrow("due")))
            o.put("paid", c.getInt(c.getColumnIndexOrThrow("paid")))
            o.put("mine", c.getLong(c.getColumnIndexOrThrow("mine")))
            a.put(o)
        }
        c.close()
        return a
    }

    // ---------- اقساط ----------

    @Synchronized
    fun addInst(title: String, amount: Long, due: Long, rep: Boolean, left: Int): Long {
        val v = ContentValues()
        v.put("title", title)
        v.put("amount", amount)
        v.put("due", due)
        v.put("rep", if (rep) 1 else 0)
        v.put("left", left)
        v.put("done", 0)
        return writableDatabase.insert("inst", null, v)
    }

    fun insts(onlyOpen: Boolean): JSONArray {
        val c = readableDatabase.rawQuery(
            if (onlyOpen) "SELECT * FROM inst WHERE done=0 ORDER BY due" else "SELECT * FROM inst ORDER BY done, due", null
        )
        val a = JSONArray()
        while (c.moveToNext()) {
            val o = JSONObject()
            o.put("id", c.getLong(c.getColumnIndexOrThrow("id")))
            o.put("title", c.getString(c.getColumnIndexOrThrow("title")))
            o.put("amount", c.getLong(c.getColumnIndexOrThrow("amount")))
            o.put("due", c.getLong(c.getColumnIndexOrThrow("due")))
            o.put("rep", c.getInt(c.getColumnIndexOrThrow("rep")))
            o.put("left", c.getInt(c.getColumnIndexOrThrow("left")))
            o.put("done", c.getInt(c.getColumnIndexOrThrow("done")))
            a.put(o)
        }
        c.close()
        return a
    }

    /** پرداخت قسط: اگه تکرارشونده باشه موعد به ماه بعد (شمسی) می‌ره، وگرنه بسته می‌شه */
    @Synchronized
    fun payInst(id: Long) {
        val d = writableDatabase
        val c = d.rawQuery("SELECT due, rep, left FROM inst WHERE id=?", arrayOf(id.toString()))
        if (!c.moveToFirst()) {
            c.close()
            return
        }
        val due = c.getLong(0)
        val rep = c.getInt(1) == 1
        val left = c.getInt(2)
        c.close()
        val v = ContentValues()
        if (rep && left != 1) {
            v.put("due", Jalali.addMonth(due))
            if (left > 1) v.put("left", left - 1)
        } else {
            v.put("done", 1)
        }
        d.update("inst", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun deleteInst(id: Long) {
        writableDatabase.delete("inst", "id=?", arrayOf(id.toString()))
    }

    companion object {
        @Volatile
        private var inst: Db? = null

        fun get(ctx: Context): Db {
            return inst ?: synchronized(this) {
                inst ?: Db(ctx.applicationContext).also { inst = it }
            }
        }
    }
}
