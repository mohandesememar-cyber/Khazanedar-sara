package app.khazanehdar

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** نرخ دلار و طلا از اینترنت؛ اگه منبع جواب نده، آخرین نرخ ذخیره‌شده نشون داده می‌شه. */
object Rates {
    private val SOURCES = listOf("https://call4.tgju.org/ajax.json", "https://call2.tgju.org/ajax.json")
    // کلید در منبع -> نام نمایشی. مقدارها ریال‌ان و به تومان تبدیل می‌شن.
    private val KEYS = listOf("price_dollar_rl" to "usd", "geram18" to "gold18", "sekee" to "coin")

    @Volatile var running = false

    private fun num(s: String?): Long? =
        s?.replace(",", "")?.replace("٬", "")?.trim()?.toDoubleOrNull()?.toLong()

    private fun fetch(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return try {
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun refresh(ctx: Context) {
        if (running) return
        running = true
        Thread {
            try {
                var body: String? = null
                for (u in SOURCES) {
                    try { body = fetch(u) } catch (e: Exception) { }
                    if (body != null) break
                }
                if (body == null) return@Thread
                val cur = JSONObject(body).optJSONObject("current") ?: return@Thread
                val old = try { JSONObject(Prefs.rates(ctx)) } catch (e: Exception) { JSONObject() }
                val out = JSONObject()
                for ((src, name) in KEYS) {
                    val o = cur.optJSONObject(src) ?: continue
                    val p = num(o.optString("p"))?.div(10) ?: continue
                    val prevO = old.optJSONObject(name)
                    var prev = prevO?.optLong("prev", 0L) ?: 0L
                    val lastP = prevO?.optLong("p", 0L) ?: 0L
                    if (lastP != 0L && lastP != p) prev = lastP
                    // تغییر اعلام‌شده‌ی خود منبع (اگه باشه) مقدم‌تره
                    val d = num(o.optString("d"))?.div(10)
                    var dir = when (o.optString("dt")) { "high" -> 1; "low" -> -1; else -> 0 }
                    var change = d ?: 0L
                    if (dir == 0 && prev != 0L) { dir = if (p > prev) 1 else if (p < prev) -1 else 0; change = Math.abs(p - prev) }
                    out.put(name, JSONObject().put("p", p).put("prev", prev).put("dir", dir).put("chg", Math.abs(change)))
                }
                if (out.length() > 0) {
                    out.put("ts", System.currentTimeMillis())
                    Prefs.setRates(ctx, out.toString())
                    // تاریخچه برای پیش‌بینی: نمونه‌ی جدید فقط وقتی قیمت عوض شده یا حداقل نیم‌ساعت گذشته
                    try {
                        val h = org.json.JSONArray(Prefs.ratesHist(ctx))
                        val now = System.currentTimeMillis()
                        val last = if (h.length() > 0) h.getJSONArray(h.length() - 1) else null
                        val u = out.optJSONObject("usd")?.optLong("p") ?: 0L
                        val g = out.optJSONObject("gold18")?.optLong("p") ?: 0L
                        val c = out.optJSONObject("coin")?.optLong("p") ?: 0L
                        if (last == null || now - last.getLong(0) > 1800000L || last.getLong(1) != u || last.getLong(2) != g) {
                            h.put(org.json.JSONArray().put(now).put(u).put(g).put(c))
                            val n = org.json.JSONArray()
                            val from = maxOf(0, h.length() - 1500)
                            for (i in from until h.length()) n.put(h.get(i))
                            Prefs.setRatesHist(ctx, n.toString())
                        }
                    } catch (e: Exception) { }
                }
            } catch (e: Throwable) {
            } finally {
                running = false
            }
        }.start()
    }
}
