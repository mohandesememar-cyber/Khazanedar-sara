package app.khazanehdar

import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** وقتی پیامک می‌رسه، حتی اگه اپ بسته باشه، اجرا می‌شه */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val sender = Sender.norm(msgs[0].originatingAddress ?: "")
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val ts = msgs[0].timestampMillis.takeIf { it > 0 } ?: System.currentTimeMillis()
        handle(ctx, sender, body, ts, true)
    }

    companion object {
        /** پردازش یک پیامک. برمی‌گردونه id ثبت‌شده یا -1 */
        fun handle(ctx: Context, sender: String, body: String, ts: Long, notify: Boolean): Long {
            val db = Db.get(ctx)
            val known = db.getSender(sender)
            if (known != null && known.second == 0) return -1 // شماره‌ی مسدودشده
            var p = SmsParser.parse(sender, body) ?: return -1
            // یادگیری از موجودی: اگه «مانده‌ی قبلی ± مبلغ = مانده‌ی جدید» باشه، جهت تراکنش قطعیه
            if (notify && p.balance != null && !p.correction) {
                val prev = db.lastBalance(p.bank ?: known?.first ?: "", p.acct)
                if (prev != null) {
                    val k = when (p.balance) {
                        prev + p.amount -> "in"
                        prev - p.amount -> "out"
                        else -> null
                    }
                    if (k != null && k != p.kind) p = p.copy(kind = k)
                }
            }
            val bank = p.bank ?: known?.first?.takeIf { it.isNotEmpty() && it != "بانک نامشخص" }
            if (known == null) db.upsertSender(sender, bank, 1)
            else if (bank != null) db.setSenderBankIfEmpty(sender, bank)
            val bankName = bank ?: "بانک نامشخص"
            val id = db.insertSms(p.ts ?: ts, bankName, p.acct, sender, p.kind, p.amount, p.balance, body, if (p.correction) 0 else 1)
            if (id <= 0) return -1
            if (p.correction) db.setReason(id, "برگشتی", "اصلاحیه/برگشت تراکنش")
            if (notify) {
                when {
                    p.correction -> Notifier.simple(
                        ctx, Notifier.NOTIF_TX + id.toInt(),
                        "🔁 اصلاحیه: ${Notifier.fa(p.amount)} تومان ${if (p.kind == "in") "برگشت خورد" else "کم شد"}",
                        "$bankName • تراکنش اصلاح و حساب‌ها درست شد."
                    )
                    bank == null -> Notifier.askBank(ctx, id, sender, p.kind, p.amount)
                    else -> Notifier.askReason(ctx, id, bankName, p.kind, p.amount)
                }
                Prefs.bumpUi(ctx)
            }
            return id
        }
    }
}

/** دکمه‌های سریع و پاسخ نوشتاری اعلان */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra(Notifier.EXTRA_ID, -1)
        if (id < 0) return
        val typed = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(Notifier.KEY_REPLY)?.toString()
        val cat = intent.getStringExtra(Notifier.EXTRA_CAT)
        val db = Db.get(ctx)
        if (intent.getStringExtra(Notifier.EXTRA_MODE) == "bank") {
            val sender = intent.getStringExtra(Notifier.EXTRA_SENDER) ?: return
            val t = typed?.trim().orEmpty()
            if (t.isEmpty()) return
            val name = if (t.startsWith("بانک") || t.startsWith("پست") || t.startsWith("بلو")) t else "بانک $t"
            db.setBankForSender(sender, name)
            val tx = db.getTx(id)
            if (tx != null) {
                Notifier.askReason(ctx, id, name, tx.getString("kind"), tx.getLong("amount"))
            }
            Prefs.bumpUi(ctx)
            return
        }
        when {
            cat != null -> db.setReason(id, cat, cat)
            !typed.isNullOrBlank() -> db.setReason(id, Category.guess(typed), typed.trim())
            else -> return
        }
        Notifier.cancel(ctx, Notifier.NOTIF_TX + id.toInt())
        Prefs.bumpUi(ctx)
    }
}

object Category {
    private val MAP = listOf(
        "کافی‌شاپ" to listOf("کافه", "کافی شاپ", "کافی‌شاپ", "قهوه", "کافی"),
        "اسنپ‌فود" to listOf("اسنپ فود", "اسنپ‌فود", "اسنپفود", "snappfood"),
        "رستوران" to listOf("رستوران", "ناهار بیرون", "شام بیرون", "فست فود", "پیتزا", "کباب", "ساندویچ"),
        "خورد و خوراک" to listOf("ناهار", "شام", "صبحانه", "غذا", "نون", "نان", "میوه", "سوپر", "خوراک", "ماست", "گوشت", "مرغ"),
        "حمل‌ونقل" to listOf("تاکسی", "اسنپ", "تپسی", "مترو", "اتوبوس", "کرایه", "عوارض", "پارکینگ"),
        "ماشین" to listOf("بنزین", "ماشین", "تعمیر", "لاستیک", "روغن", "بیمه ماشین", "کارواش"),
        "قبوض" to listOf("قبض", "برق", "گاز", "آب", "اینترنت", "شارژ", "موبایل", "تلفن"),
        "اجاره/خانه" to listOf("اجاره", "رهن", "ودیعه", "شارژ ساختمان"),
        "داروخانه" to listOf("دارو", "داروخانه"),
        "سلامت" to listOf("دکتر", "درمان", "بیمه", "دندان", "آزمایش", "ویزیت"),
        "باشگاه" to listOf("باشگاه", "ورزش", "استخر"),
        "تفریح" to listOf("سینما", "بازی", "کنسرت", "سفر", "تفریح", "نتفلیکس"),
        "آموزش" to listOf("کتاب", "کلاس", "دوره", "آموزش", "شهریه"),
        "هدیه" to listOf("هدیه", "کادو", "عیدی", "کمک"),
        "آرایشی بهداشتی" to listOf("آرایشگاه", "ارایشی", "آرایشی", "بهداشتی", "سلمونی", "شامپو", "کرم"),
        "لباس" to listOf("لباس", "کفش", "پیراهن", "شلوار", "مانتو"),
        "خرید دفتر" to listOf("دفتر", "کاغذ", "خودکار", "کارتریج", "ملزومات"),
        "خرید خونه" to listOf("خونه", "خانه", "لوازم خانگی", "یخچال", "فرش", "مبل"),
        "قسط" to listOf("قسط", "وام"),
        "طلا" to listOf("طلا", "سکه", "شمش"),
        "پس‌انداز" to listOf("پس انداز", "پس‌انداز", "پسانداز", "سپرده"),
        "قرض" to listOf("قرض", "وام دادم", "قرضی"),
        "پول توجیبی" to listOf("توجیبی", "جیبی"),
        "خرج پشمک" to listOf("پشمک"),
        "خرید" to listOf("خرید", "دیجی", "دیجیکالا", "لوازم")
    )

    fun guess(text: String): String {
        for ((cat, words) in MAP) if (words.any { text.contains(it) }) return cat
        return "متفرقه"
    }
}

/** هر روز در ساعت‌های دلخواه: یادآوری طلب‌ها، اقساط، گزارش پایان ماه */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        try {
            Notifier.scheduleDaily(ctx)
            when (intent.getStringExtra("k")) {
                "inst" -> runInst(ctx)
                else -> runDebt(ctx)
            }
        } finally {
            pending.finish()
        }
    }

    companion object {
        private const val DAY = 86400000L

        fun runInst(ctx: Context) {
            val today = Jalali.startOfDay(System.currentTimeMillis())
            val list = Db.get(ctx).insts(true)
            for (i in 0 until list.length()) {
                val o = list.getJSONObject(i)
                val days = Math.round((Jalali.startOfDay(o.getLong("due")) - today) / DAY.toDouble()).toInt()
                if (days > 7) continue // از یک هفته قبل هر روز
                val title = o.getString("title")
                val amt = Notifier.fa(o.getLong("amount"))
                val (h, t) = when {
                    days > 1 -> "⏳ ${Notifier.fa(days.toLong())} روز مانده تا قسط «$title»" to "مبلغ $amt تومان • موعد ${Notifier.dateFa(o.getLong("due"))}. یادت نره!"
                    days == 1 -> "⏰ فردا قسط «$title» موعده" to "مبلغ $amt تومان رو آماده کن."
                    days == 0 -> "💳 امروز قسط «$title» رو پرداخت کن!" to "مبلغ $amt تومان. پرداخت کن تا جریمه نشی 😬"
                    else -> "😱 قسط «$title» ${Notifier.fa((-days).toLong())} روز عقب افتاده!" to "مبلغ $amt تومان؛ هرچه زودتر پرداخت کن."
                }
                Notifier.simple(ctx, Notifier.NOTIF_INST + 100 + o.getInt("id"), h, t)
            }
            Notifier.refreshOngoing(ctx)
        }

        fun runDebt(ctx: Context) {
            val db = Db.get(ctx)
            val today = Jalali.startOfDay(System.currentTimeMillis())

            // طلب‌ها
            val debts = db.debts(true)
            for (i in 0 until debts.length()) {
                val d = debts.getJSONObject(i)
                val due = Jalali.startOfDay(d.getLong("due"))
                val name = d.getString("name")
                val amt = Notifier.fa(d.getLong("amount"))
                val late = Math.round((today - due) / DAY.toDouble()).toInt()
                val (title, text) = when {
                    late > 0 -> "😤 $name هنوز $amt تومان بدهکاره!" to
                        "${Notifier.fa(late.toLong())} روز از موعدش گذشته. وقتشه یه پیام مودبانه (ولی با نیش) بفرستی."
                    late == 0 -> "⏰ امروز روز وصول $amt تومان از $name‌ست" to
                        "امروز موعدشه. یه یادآوری دوستانه بفرست؛ پول خودش پا نداره بیاد."
                    else -> continue
                }
                Notifier.simple(ctx, Notifier.NOTIF_DEBT + 100 + d.getInt("id"), title, text)
            }

            // گزارش پایان ماه شمسی (روز آخر ماه) + جبران اگه روز آخر از دست رفته
            val j = Jalali.fromMillis(System.currentTimeMillis())
            val keyNow = "${j[0]}-${j[1]}"
            if (j[2] == Jalali.monthLen(j[0], j[1]) && Prefs.lastReport(ctx) != keyNow) {
                sendReport(ctx, j[0], j[1])
                Prefs.setLastReport(ctx, keyNow)
            } else if (j[2] <= 2) {
                val py = if (j[1] == 1) j[0] - 1 else j[0]
                val pm = if (j[1] == 1) 12 else j[1] - 1
                val keyPrev = "$py-$pm"
                if (Prefs.lastReport(ctx) != keyPrev && Prefs.lastReport(ctx) != keyNow) {
                    sendReport(ctx, py, pm)
                    Prefs.setLastReport(ctx, keyPrev)
                }
            }

            // اگه تراکنش بی‌جواب مونده، یه تلنگر
            val pc = db.pendingCount()
            if (pc > 0) {
                Notifier.simple(
                    ctx, Notifier.NOTIF_REPORT + 1, "🧐 ${Notifier.fa(pc.toLong())} تا تراکنش منتظر توضیح توئه",
                    "بیا بگو این پول‌ها کجا رفتن یا از کجا اومدن؛ حسابدار بدون جواب دق می‌کنه."
                )
            }
        }

        private fun sendReport(ctx: Context, jy: Int, jm: Int) {
            val r = Suggest.forMonth(ctx, jy, jm)
            if (r.getLong("in") == 0L && r.getLong("out") == 0L) return
            val ex = try { Report.make(ctx, jy, jm) } catch (e: Exception) { null }
            val note = if (ex?.optBoolean("ok") == true) "\n📄 فایل PDF و Word آمار این ماه توی پوشه‌ی Download/KhazanehdarSara ذخیره شد." else ""
            Notifier.simple(
                ctx, Notifier.NOTIF_REPORT,
                "📜 گزارش ${Jalali.MONTHS[jm - 1]} ${Notifier.fa(jy.toLong())} آماده‌ست (نمودار و پیشنهاد)",
                Suggest.text(r) + note, intArrayOf(jy, jm)
            )
        }
    }
}

/** بعد از ریبوت یا آپدیت اپ، آلارم‌ها و اعلان دائمی دوباره تنظیم می‌شه */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifier.scheduleDaily(ctx)
        Notifier.refreshOngoing(ctx)
    }
}
