package app.khazanehdar

/** نتیجه‌ی تشخیص پیامک بانکی. مبلغ‌ها به تومان. bank=null یعنی بانک معلوم نیست. */
data class Parsed(
    val bank: String?,
    val acct: String?,
    val kind: String,
    val amount: Long,
    val balance: Long?,
    val correction: Boolean,
    val ts: Long? = null
)

object SmsParser {

    private val BANKS = listOf(
        "ملت" to "بانک ملت", "ملی" to "بانک ملی", "پارسیان" to "بانک پارسیان",
        "سامان" to "بانک سامان", "صادرات" to "بانک صادرات", "تجارت" to "بانک تجارت",
        "پاسارگاد" to "بانک پاسارگاد", "رفاه" to "بانک رفاه", "کشاورزی" to "بانک کشاورزی",
        "مسکن" to "بانک مسکن", "سپه" to "بانک سپه", "شهر" to "بانک شهر", "آینده" to "بانک آینده",
        "اقتصاد نوین" to "بانک اقتصاد نوین", "سینا" to "بانک سینا", "کارآفرین" to "بانک کارآفرین",
        "دی" to "بانک دی", "بلو" to "بلوبانک", "قوامین" to "بانک قوامین",
        "ایران زمین" to "بانک ایران زمین", "پست بانک" to "پست بانک", "مهر ایران" to "بانک مهر",
        "رسالت" to "بانک رسالت", "توسعه" to "بانک توسعه تعاون", "گردشگری" to "بانک گردشگری",
        "سرمایه" to "بانک سرمایه", "خاورمیانه" to "بانک خاورمیانه", "ایران ونزوئلا" to "بانک ایران ونزوئلا"
    )
    private val LATIN = listOf(
        "mellat" to "بانک ملت", "bmi" to "بانک ملی", "melli" to "بانک ملی", "parsian" to "بانک پارسیان",
        "saman" to "بانک سامان", "pasargad" to "بانک پاسارگاد", "blu" to "بلوبانک",
        "tejarat" to "بانک تجارت", "saderat" to "بانک صادرات", "refah" to "بانک رفاه",
        "keshavarzi" to "بانک کشاورزی", "maskan" to "بانک مسکن", "sepah" to "بانک سپه",
        "shahr" to "بانک شهر", "ayandeh" to "بانک آینده", "sina" to "بانک سینا"
    )
    private val IN_W = listOf("واریز", "دریافت", "افزایش", "بستانکار", "حقوق", "سپرده گذاری", "سپرده‌گذاری", "شارژ حساب")
    private val OUT_W = listOf("برداشت", "خرید", "پرداخت", "انتقال", "کاهش", "کسر", "بدهکار", "قبض", "خروج", "پایا", "ساتنا", "پل")
    private val MONEY_W = listOf("مانده", "موجودی", "برداشت", "واریز", "خرید", "پرداخت", "انتقال", "مبلغ", "پایا", "ساتنا", "بدهکار", "بستانکار", "حواله")

    // رمز پویا / کد تایید: هیچ‌وقت تراکنش حساب نمی‌شن
    private val OTP_W = listOf(
        "رمز پویا", "رمز دوم", "رمز یکبار", "رمز یک بار", "رمز ورود", "رمز عبور", "کد تایید", "کد تأیید",
        "کد فعال", "کد ورود", "رمز "
    )
    // تراکنش ناموفق
    private val FAIL_W = listOf("ناموفق", "نا موفق", "نامعتبر", "رد شد", "عدم موفقیت", "ناکافی", "خطا ")
    // اصلاحیه / برگشت
    private val CORR_W = listOf("برگشت", "اصلاحیه", "ابطال", "عودت", "استرداد", "اصلاح ")
    private val CORR_IN = listOf(
        "برگشت از", "برگشت خرید", "برگشت پرداخت", "برگشت برداشت", "برگشت وجه", "ابطال خرید",
        "ابطال برداشت", "ابطال پرداخت", "عودت", "استرداد"
    )

    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when (ch) {
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                'ي' -> sb.append('ی')
                'ك' -> sb.append('ک')
                '٬', '،' -> sb.append(',')
                '\u200e', '\u200f', '\u202a', '\u202b', '\u202c', '\u202d', '\u202e', '\u2066', '\u2067', '\u2068', '\u2069', '\ufeff' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    // ---- بانک شهر: پیام ساختاریافته «واریز به:… / مبلغ:… / موجودی:… / ساعت تاریخ» ----
    private val SH_AMT = Regex("""مبلغ\s*[:：]\s*(\d[\d,]*)""")
    private val SH_BAL = Regex("""(?:موجودی|مانده)\s*[:：]\s*(\d[\d,]*)""")
    private val SH_KIND = Regex("""(واریز|برداشت)\s*(?:به|از)?\s*[:：]""")
    private val SH_DATE = Regex("""(\d{1,2}):(\d{2})(?::(\d{2}))?\s+(\d{4})/(\d{1,2})/(\d{1,2})""")

    private fun shahr(t: String): Parsed? {
        val am = SH_AMT.find(t) ?: return null
        val k = SH_KIND.find(t) ?: return null
        var amount = am.groupValues[1].replace(",", "").toLongOrNull() ?: return null
        var bal = SH_BAL.find(t)?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull()
        if (!t.contains("تومان")) { amount /= 10; bal = bal?.div(10) }
        if (amount <= 0L) return null
        var ts: Long? = null
        SH_DATE.find(t)?.let { m ->
            try {
                val jy = m.groupValues[4].toInt(); val jm = m.groupValues[5].toInt(); val jd = m.groupValues[6].toInt()
                if (jy in 1380..1500 && jm in 1..12 && jd in 1..31) {
                    val g = Jalali.j2g(jy, jm, jd)
                    val c = java.util.Calendar.getInstance()
                    c.clear()
                    c.set(g[0], g[1] - 1, g[2], m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].ifEmpty { "0" }.toInt())
                    ts = c.timeInMillis
                }
            } catch (e: Exception) { }
        }
        return Parsed("بانک شهر", null, if (k.groupValues[1] == "واریز") "in" else "out", amount, bal, false, ts)
    }

    private fun isFa(c: Char) = c in 'ء'..'ي' || c in 'پ'..'ی'

    fun findBank(hay: String): String? {
        for ((k, v) in BANKS) {
            var i = hay.indexOf(k)
            while (i >= 0) {
                val before = if (i > 0) hay[i - 1] else ' '
                val after = if (i + k.length < hay.length) hay[i + k.length] else ' '
                if (!isFa(before) && !isFa(after)) return v
                i = hay.indexOf(k, i + 1)
            }
        }
        val low = hay.lowercase()
        for ((k, v) in LATIN) if (low.contains(k)) return v
        return null
    }

    // الگوها یک بار ساخته می‌شن (ساخت دوباره‌شون برای هزاران پیامک کند بود)
    private val BAL_RE = Regex("""(?:مانده|موجودی)[^\d\-+]{0,15}(\d[\d,]*)""")
    private val AMT_RE = Regex("""([+\-])?\s*(\d{1,3}(?:,\d{3})+|\d+)\s*([+\-])?""")
    private val CTX_RE = Regex("""(کارت|حساب|شماره|تلفن|پیگیری)\D{0,6}$""")

    // «واریز به: ...» یعنی پول اومده؛ «برداشت از: ...» یعنی رفته (حتی اگه «انتقال» یا «پایا» قبلش باشه)
    private val LABEL_RE = Regex("""(واریز|برداشت)\s*(?:به|از)?\s*[:：]""")

    private val ACCT1 = Regex("""[*•xX]{2,}\s*(\d{3,4})""")
    private val ACCT2 = Regex("""(\d{3,4})\s*[*•xX]{2,}""")
    private val ACCT3 = Regex("""(?:کارت|حساب)\s*[:：]?\s*(\d[\d\-/.]{3,})""")

    private fun findAcct(t: String): String? {
        ACCT1.find(t)?.let { return it.groupValues[1].takeLast(4) }
        ACCT2.find(t)?.let { return it.groupValues[1].takeLast(4) }
        ACCT3.find(t)?.let {
            val d = it.groupValues[1].filter { c -> c.isDigit() }
            if (d.length >= 4) return d.takeLast(4)
        }
        return null
    }

    fun parse(sender: String, body: String): Parsed? {
        val t = normalize(body)
        if (MONEY_W.none { t.contains(it) }) return null
        val low = t.lowercase()
        val hasBalance = t.contains("مانده") || t.contains("موجودی")
        val otp = OTP_W.any { t.contains(it) } || low.contains("cvv") || low.contains("otp")
        // پیامک رمز: فقط اگه «مانده» داشته باشه (یعنی واقعاً تراکنش حساب بوده) ادامه می‌دیم
        if (otp && !hasBalance) return null
        if (FAIL_W.any { t.contains(it) }) return null
        // پیام‌های «باکس» (مثلاً بلوبانک) حساب اصلی رو تغییر نمی‌دن
        if (t.contains("باکس") || low.contains("box")) return null

        val bank = findBank("$t $sender")
        if (bank == "بانک شهر") shahr(t)?.let { return it }
        val acct = findAcct(t)

        var balance: Long? = null
        var rest = t
        val bm = BAL_RE.find(t)
        if (bm != null) {
            balance = bm.groupValues[1].replace(",", "").toLongOrNull()
            rest = t.substring(0, bm.range.first) + " " + t.substring(bm.range.last + 1)
        }

        fun firstPos(words: List<String>): Int? =
            words.map { rest.indexOf(it) }.filter { it >= 0 }.minOrNull()

        val correction = CORR_W.any { t.contains(it) }
        val ii = firstPos(IN_W)
        val oi = firstPos(OUT_W)
        var kind: String? = null
        var kpos = 0
        if (ii != null && (oi == null || ii < oi)) { kind = "in"; kpos = ii }
        else if (oi != null) { kind = "out"; kpos = oi }
        LABEL_RE.find(rest)?.let { m ->
            kind = if (m.groupValues[1] == "واریز") "in" else "out"
            kpos = m.range.first
        }
        // «برگشت خرید» یعنی پول برگشته به حساب
        if (correction && CORR_IN.any { t.contains(it) }) kind = "in"

        data class C(val pos: Int, val value: Long, val sign: String?, val hasComma: Boolean)

        val cands = ArrayList<C>()
        for (m in AMT_RE.findAll(rest)) {
            val g = m.groups[2]!!
            val raw = g.value
            val s = g.range.first
            val e = g.range.last + 1
            val before = if (s > 0) rest[s - 1] else ' '
            val after = if (e < rest.length) rest[e] else ' '
            if (before == '*' || before == '/' || after == '/' || after == '*') continue
            val hasComma = raw.contains(',')
            if (!hasComma && raw.length < 5) continue
            if (!hasComma) {
                val ctx = rest.substring(maxOf(0, s - 12), s)
                if (CTX_RE.containsMatchIn(ctx)) continue
            }
            val sign = m.groups[1]?.value ?: m.groups[3]?.value
            val v = raw.replace(",", "").toLongOrNull() ?: continue
            cands.add(C(s, v, sign, hasComma))
        }
        if (cands.isEmpty()) return null

        val pick = cands.firstOrNull { it.pos >= kpos && it.hasComma }
            ?: cands.firstOrNull { it.pos >= kpos }
            ?: cands.first()

        if (kind == null) {
            kind = when (pick.sign) {
                "+" -> "in"
                "-" -> "out"
                else -> return null
            }
        }

        // اگه واحد نوشته نشده باشه، ریال فرض می‌کنیم (اکثر بانک‌ها ریال می‌فرستن)
        val isToman = t.contains("تومان")
        var amount = pick.value
        if (!isToman) {
            amount /= 10
            balance = balance?.div(10)
        }
        if (amount <= 0L) return null
        return Parsed(bank, acct, kind, amount, balance, correction)
    }
}

object Sender {
    /** شماره‌ی فرستنده رو یکسان می‌کنه (+98 و 0 اول حذف می‌شه) */
    fun norm(a: String): String {
        var s = a.trim()
        // فرستنده‌ی حرفی (مثل Bank Shahr): بزرگ/کوچک و فاصله مهم نیست
        if (s.any { it.isLetter() }) return s.lowercase().filter { it.isLetterOrDigit() }
        if (s.isNotEmpty() && s.all { it.isDigit() || it == '+' }) {
            s = s.removePrefix("+98").removePrefix("0098")
            if (s.startsWith("98") && s.length >= 10) s = s.substring(2)
            if (s.startsWith("09")) s = s.substring(1)
        }
        return s
    }
}
