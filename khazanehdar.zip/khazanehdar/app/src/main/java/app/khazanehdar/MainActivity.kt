package app.khazanehdar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingOpen: String = ""

    private val impTotal = java.util.concurrent.atomic.AtomicInteger(0)
    private val impDone = java.util.concurrent.atomic.AtomicInteger(0)
    private val impAdded = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var impRunning = false
    @Volatile private var scanRunning = false
    @Volatile private var scanResult = "[]"
    private val scanDone = java.util.concurrent.atomic.AtomicInteger(0)
    private val scanTotal = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var impFinished = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        readIntent(intent)
        web.loadUrl("file:///android_asset/index.html")
        Notifier.ensureChannel(this)
        Notifier.scheduleDaily(this)
        Notifier.refreshOngoing(this)
    }

    private fun readIntent(i: Intent?) {
        if (i == null) return
        when (i.getStringExtra("open")) {
            "report" -> pendingOpen = "report,${i.getIntExtra("y", 0)},${i.getIntExtra("m", 0)}"
            "tx" -> pendingOpen = "tx,${i.getLongExtra("id", -1)}"
        }
        i.removeExtra("open")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }

    override fun onResume() {
        super.onResume()
        Notifier.refreshOngoing(this)
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }

    override fun onBackPressed() {
        web.evaluateJavascript("(window.onNativeBack && window.onNativeBack()) ? 1 : 0") { r ->
            if (r != "1") runOnUiThread { super.onBackPressed() }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode != REQ_FONT && requestCode != REQ_STAMP) || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val kind = if (requestCode == REQ_FONT) "font" else "stamp"
        val target = File(filesDir, if (kind == "font") "nastaliq.ttf" else "stamp.png")
        var ok = false
        try {
            contentResolver.openInputStream(uri)?.use { ins -> target.outputStream().use { out -> ins.copyTo(out) } }
            ok = target.length() > 0
            if (ok && kind == "font") {
                try {
                    Typeface.createFromFile(target)
                } catch (e: Exception) {
                    ok = false
                    target.delete()
                }
            }
        } catch (e: Exception) {
            ok = false
        }
        web.evaluateJavascript("window.onFilePicked && window.onFilePicked('$kind', $ok)", null)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    inner class Bridge {
        private val db get() = Db.get(this@MainActivity)

        // ---------- دسترسی‌ها ----------

        @JavascriptInterface
        fun permState(): String {
            val o = JSONObject()
            o.put("sms", has(Manifest.permission.RECEIVE_SMS) && has(Manifest.permission.READ_SMS))
            o.put("notif", Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS))
            val pm = getSystemService(PowerManager::class.java)
            o.put("battery", Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(packageName))
            return o.toString()
        }

        @JavascriptInterface
        fun requestPerms() {
            runOnUiThread {
                val need = ArrayList<String>()
                for (p in listOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)) if (!has(p)) need.add(p)
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
            }
        }

        /** شیائومی (MIUI/HyperOS) برنامه‌ها رو پشت‌زمینه می‌کشه؛ این صفحه‌ی تنظیمات رو باز می‌کنیم */
        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                try {
                    val i = Intent()
                    i.setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                    startActivity(i)
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    } catch (e2: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun requestBatteryExemption() {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                        startActivity(i)
                    }
                } catch (e: Exception) {
                }
            }
        }

        // ---------- زمان و تاریخ ----------

        @JavascriptInterface
        fun uiVer(): String = Prefs.uiVer(this@MainActivity).toString()

        @JavascriptInterface
        fun consumeOpen(): String {
            val r = pendingOpen
            pendingOpen = ""
            return r
        }

        @JavascriptInterface
        fun today(): String {
            val j = Jalali.fromMillis(System.currentTimeMillis())
            return JSONArray(listOf(j[0], j[1], j[2])).toString()
        }

        @JavascriptInterface
        fun jToMs(jy: Int, jm: Int, jd: Int): String {
            val g = Jalali.j2g(jy, jm, jd)
            val c = java.util.Calendar.getInstance()
            c.clear()
            c.set(g[0], g[1] - 1, g[2], 12, 0, 0)
            return c.timeInMillis.toString()
        }

        @JavascriptInterface
        fun msToJ(ms: String): String {
            val j = Jalali.fromMillis(ms.toLong())
            return JSONArray(listOf(j[0], j[1], j[2])).toString()
        }

        @JavascriptInterface
        fun monthLen(jy: Int, jm: Int): Int = Jalali.monthLen(jy, jm)

        // ---------- تراکنش‌ها ----------

        @JavascriptInterface
        fun month(jy: Int, jm: Int): String {
            val ny = if (jm == 12) jy + 1 else jy
            val nm = if (jm == 12) 1 else jm + 1
            return db.txRange(Jalali.monthStart(jy, jm), Jalali.monthStart(ny, nm)).toString()
        }

        @JavascriptInterface
        fun pending(): String = db.pending().toString()

        @JavascriptInterface
        fun txGet(id: String): String = db.getTx(id.toLong())?.toString() ?: "{}"

        @JavascriptInterface
        fun setReason(id: String, cat: String, reason: String) {
            db.setReason(id.toLong(), cat, reason)
            Notifier.cancel(this@MainActivity, Notifier.NOTIF_TX + id.toLong().toInt())
        }

        @JavascriptInterface
        fun updateTx(id: String, ms: String, bank: String, kind: String, amount: String, cat: String, reason: String) {
            db.updateTx(id.toLong(), ms.toLong(), bank, kind, amount.toLong(), cat, reason)
            Notifier.cancel(this@MainActivity, Notifier.NOTIF_TX + id.toLong().toInt())
        }

        @JavascriptInterface
        fun guessCategory(text: String): String = Category.guess(text)

        @JavascriptInterface
        fun addManual(kind: String, amount: String, cat: String, reason: String, ms: String) {
            db.insertManual(ms.toLong(), kind, amount.toLong(), cat, reason)
        }

        @JavascriptInterface
        fun deleteTx(id: String) {
            db.deleteTx(id.toLong())
            Notifier.cancel(this@MainActivity, Notifier.NOTIF_TX + id.toLong().toInt())
        }

        // ---------- بانک‌ها و شماره‌ها ----------

        @JavascriptInterface
        fun banks(): String = db.bankSummary().toString()

        @JavascriptInterface
        fun bankTx(bank: String, acct: String): String = db.txByBank(bank, acct).toString()

        @JavascriptInterface
        fun senders(): String = db.senders().toString()

        @JavascriptInterface
        fun unknownSenders(): String = db.unknownSenders().toString()

        @JavascriptInterface
        fun addSender(addr: String, bank: String) {
            val a = Sender.norm(addr)
            if (a.isEmpty()) return
            db.upsertSender(a, if (bank.isBlank()) null else bank, 1)
        }

        @JavascriptInterface
        fun setBankForSender(addr: String, bank: String) {
            val name = bank.trim()
            if (name.isEmpty()) return
            db.setBankForSender(addr, if (name.startsWith("بانک") || name.startsWith("پست") || name.startsWith("بلو")) name else "بانک $name")
        }

        /** دیگه از این شماره چیزی نیار (اختیاری: تراکنش‌های قبلی‌اش هم پاک بشه) */
        @JavascriptInterface
        fun blockSender(addr: String, deleteTx: Boolean) {
            db.upsertSender(addr, db.getSender(addr)?.first, 0)
            if (deleteTx) db.deleteTxBySender(addr)
        }

        @JavascriptInterface
        fun unblockSender(addr: String) = db.setSenderEnabled(addr, true)

        @JavascriptInterface
        fun removeSender(addr: String) = blockSender(addr, false)

        @JavascriptInterface
        fun senderMsgs(addr: String): String = db.txBySender(addr).toString()

        /** حذف گروهی: آرایه‌ی JSON از شماره‌ها */
        @JavascriptInterface
        fun removeSenders(json: String) {
            val a = org.json.JSONArray(json)
            for (i in 0 until a.length()) blockSender(a.getString(i), false)
        }

        @JavascriptInterface
        fun blockSenders(json: String, deleteTx: Boolean) {
            val a = org.json.JSONArray(json)
            for (i in 0 until a.length()) blockSender(a.getString(i), deleteTx)
        }

        // ---------- دسته‌ها ----------

        @JavascriptInterface
        fun cats(): String = db.cats().toString()

        @JavascriptInterface
        fun saveCat(old: String, name: String, icon: String, kind: String) {
            if (name.isBlank()) return
            db.saveCat(old, name.trim(), icon.ifBlank { "🧩" }, kind)
        }

        @JavascriptInterface
        fun deleteCat(name: String) = db.deleteCat(name)

        // ---------- طلب‌ها و اقساط ----------

        @JavascriptInterface
        fun debts(): String = db.debts(false).toString()

        @JavascriptInterface
        fun addDebt2(name: String, amount: String, due: String, note: String, mine: String) {
            db.addDebt(name, amount.toLongOrNull() ?: 0L, due.toLong(), note, mine.toLongOrNull() ?: 0L)
        }

        @JavascriptInterface
        fun updateDebt(id: String, name: String, amount: String, due: String, note: String, mine: String) {
            db.updateDebt(id.toLong(), name, amount.toLongOrNull() ?: 0L, due.toLong(), note, mine.toLongOrNull() ?: 0L)
        }

        @JavascriptInterface
        fun updateInst(id: String, title: String, amount: String, due: String, rep: Boolean, left: Int) {
            db.updateInst(id.toLong(), title, amount.toLongOrNull() ?: 0L, due.toLong(), rep, left)
            Notifier.refreshOngoing(this@MainActivity)
        }

        @JavascriptInterface
        fun addDebt(name: String, amount: String, due: String, note: String) {
            db.addDebt(name, amount.toLong(), due.toLong(), note)
        }

        @JavascriptInterface
        fun setDebtPaid(id: String, paid: Boolean) = db.setDebtPaid(id.toLong(), paid)

        @JavascriptInterface
        fun deleteDebt(id: String) = db.deleteDebt(id.toLong())

        @JavascriptInterface
        fun insts(): String = db.insts(false).toString()

        @JavascriptInterface
        fun addInst(title: String, amount: String, due: String, rep: Boolean, left: Int) {
            db.addInst(title, amount.toLong(), due.toLong(), rep, left)
            Notifier.refreshOngoing(this@MainActivity)
        }

        @JavascriptInterface
        fun payInst(id: String) {
            db.payInst(id.toLong())
            Prefs.bumpInstPaid(this@MainActivity)
            Notifier.refreshOngoing(this@MainActivity)
        }

        @JavascriptInterface
        fun deleteInst(id: String) {
            db.deleteInst(id.toLong())
            Notifier.refreshOngoing(this@MainActivity)
        }

        @JavascriptInterface
        fun getTimes(): String = JSONObject()
            .put("dh", Prefs.debtH(this@MainActivity)).put("dm", Prefs.debtM(this@MainActivity))
            .put("ih", Prefs.instH(this@MainActivity)).put("im", Prefs.instM(this@MainActivity)).toString()

        @JavascriptInterface
        fun setTimes(dh: Int, dm: Int, ih: Int, im: Int) {
            Prefs.setDebtTime(this@MainActivity, dh, dm)
            Prefs.setInstTime(this@MainActivity, ih, im)
            Notifier.scheduleDaily(this@MainActivity)
        }

        // ---------- گزارش ----------

        @JavascriptInterface
        fun suggest(jy: Int, jm: Int): String = Suggest.forMonth(this@MainActivity, jy, jm).toString()

        // ---------- پیامک‌های قدیمی ----------

        /**
         * همه‌ی پیامک‌های بانکی صندوق ورودی رو در پس‌زمینه می‌خونه (همه‌ی نوشتن‌ها در یک تراکنش دیتابیس)؛
         * فقط ۱۰۰ تای آخر منتظر سوال می‌مونن. پیشرفت با importStatus() پرسیده می‌شه.
         */
        @JavascriptInterface
        fun startImport(): String {
            if (!has(Manifest.permission.READ_SMS)) return "noperm"
            if (impRunning) return "running"
            impRunning = true
            impFinished = false
            impTotal.set(0)
            impDone.set(0)
            impAdded.set(0)
            Thread {
                try {
                    val d = db.writableDatabase
                    val c = contentResolver.query(
                        Uri.parse("content://sms/inbox"),
                        arrayOf("address", "body", "date"),
                        null, null, "date ASC"
                    )
                    if (c != null) {
                        c.use { cur ->
                            impTotal.set(cur.count)
                            d.beginTransaction()
                            try {
                                var n = 0
                                while (cur.moveToNext()) {
                                    val addr = Sender.norm(cur.getString(0) ?: "")
                                    val body = cur.getString(1) ?: ""
                                    val ts = cur.getLong(2)
                                    try {
                                        if (SmsReceiver.handle(this@MainActivity, addr, body, ts, false) > 0) impAdded.incrementAndGet()
                                    } catch (e: Exception) {
                                    }
                                    n++
                                    impDone.set(n)
                                }
                                d.setTransactionSuccessful()
                            } finally {
                                d.endTransaction()
                            }
                        }
                        db.keepLastPending(100)
                        Prefs.setImported(this@MainActivity)
                        Prefs.bumpUi(this@MainActivity)
                    }
                } catch (e: Exception) {
                } finally {
                    impRunning = false
                    impFinished = true
                }
            }.start()
            return "started"
        }

        @JavascriptInterface
        fun importStatus(): String = JSONObject()
            .put("running", impRunning).put("finished", impFinished)
            .put("total", impTotal.get()).put("done", impDone.get()).put("added", impAdded.get()).toString()


        // ---------- رفرش: پیدا کردن فرستنده‌های جدید ----------

        private val LOOSE_W = listOf("ریال", "تومان", "مانده", "موجودی", "واریز", "برداشت", "مبلغ", "پایا", "ساتنا", "خرید", "پرداخت", "انتقال")

        /** همه‌ی صندوق ورودی رو می‌گرده و فرستنده‌هایی که هنوز نه قبول شدن نه مسدود رو لیست می‌کنه */
        @JavascriptInterface
        fun scanSenders(): String {
            if (!has(Manifest.permission.READ_SMS)) return "noperm"
            if (scanRunning) return "running"
            scanRunning = true
            scanDone.set(0); scanTotal.set(0); scanResult = "[]"
            Thread {
                try {
                    class G(var n: Int = 0, var last: Long = 0, var bank: String? = null, var sample: String = "", var parsed: Int = 0)
                    val map = LinkedHashMap<String, G>()
                    val c = contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), null, null, "date DESC")
                    c?.use { cur ->
                        scanTotal.set(cur.count)
                        var n = 0
                        while (cur.moveToNext()) {
                            n++; scanDone.set(n)
                            val addr = Sender.norm(cur.getString(0) ?: "")
                            if (addr.isEmpty() || db.getSender(addr) != null) continue
                            val body = cur.getString(1) ?: ""
                            val t = SmsParser.normalize(body)
                            val p = try { SmsParser.parse(addr, body) } catch (e: Exception) { null }
                            val alpha = addr.any { it.isLetter() }
                            val loose = (alpha || p != null) && t.count { it.isDigit() } >= 4 && LOOSE_W.any { t.contains(it) } &&
                                !(t.contains("رمز") || t.contains("کد "))
                            if (p == null && !loose) continue
                            val g = map.getOrPut(addr) { G() }
                            g.n++
                            if (p != null) g.parsed++
                            if (g.last == 0L) { g.last = cur.getLong(2); g.sample = body.take(110) }
                            if (g.bank == null) g.bank = p?.bank ?: SmsParser.findBank("$t $addr")
                        }
                    }
                    val a = org.json.JSONArray()
                    map.entries.sortedByDescending { it.value.n }.forEach { (k, g) ->
                        a.put(JSONObject().put("addr", k).put("count", g.n).put("parsed", g.parsed)
                            .put("bank", g.bank ?: "").put("sample", g.sample).put("last", g.last))
                    }
                    scanResult = a.toString()
                } catch (e: Exception) {
                } finally {
                    scanRunning = false
                }
            }.start()
            return "started"
        }

        @JavascriptInterface
        fun scanStatus(): String = JSONObject().put("running", scanRunning)
            .put("total", scanTotal.get()).put("done", scanDone.get()).put("result", org.json.JSONArray(scanResult)).toString()

        /** قبول فرستنده‌های انتخاب‌شده: [{addr,bank}] → اضافه می‌شن و پیامک‌هاشون خونده می‌شه */
        @JavascriptInterface
        fun acceptSenders(json: String): String {
            val a = org.json.JSONArray(json)
            val set = HashSet<String>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val addr = o.getString("addr")
                val bank = o.optString("bank", "").ifBlank { null }
                db.upsertSender(addr, bank, 1)
                set.add(addr)
            }
            if (set.isEmpty() || impRunning) return "ok"
            impRunning = true; impFinished = false; impTotal.set(0); impDone.set(0); impAdded.set(0)
            Thread {
                try {
                    val d = db.writableDatabase
                    contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), null, null, "date ASC")?.use { cur ->
                        impTotal.set(cur.count)
                        d.beginTransaction()
                        try {
                            var n = 0
                            while (cur.moveToNext()) {
                                n++; impDone.set(n)
                                val addr = Sender.norm(cur.getString(0) ?: "")
                                if (addr !in set) continue
                                try {
                                    if (SmsReceiver.handle(this@MainActivity, addr, cur.getString(1) ?: "", cur.getLong(2), false) > 0) impAdded.incrementAndGet()
                                } catch (e: Exception) { }
                            }
                            d.setTransactionSuccessful()
                        } finally { d.endTransaction() }
                    }
                    db.keepLastPending(100)
                    Prefs.bumpUi(this@MainActivity)
                } catch (e: Exception) {
                } finally { impRunning = false; impFinished = true }
            }.start()
            return "started"
        }

        /** رد کردن فرستنده‌ها: مسدود می‌شن و دیگه تو رفرش نمیان */
        @JavascriptInterface
        fun rejectSenders(json: String) {
            val a = org.json.JSONArray(json)
            for (i in 0 until a.length()) db.upsertSender(a.getString(i), null, 0)
        }

        // ---------- فراموش کردن تراکنش‌های بی‌جواب ----------

        @JavascriptInterface
        fun forgetPending(id: Long) { db.forgetPending(id); Prefs.bumpUi(this@MainActivity) }

        @JavascriptInterface
        fun forgetAllPending() { db.forgetAllPending(); Prefs.bumpUi(this@MainActivity) }


        // ---------- اخبار پیش‌بینی ----------
        @JavascriptInterface
        fun refreshNews() = News.refresh(this@MainActivity)

        @JavascriptInterface
        fun newsBusy(): Boolean = News.running

        @JavascriptInterface
        fun news(): String = Prefs.news(this@MainActivity)

        // ---------- پیامک‌های صندوق ورودی (انتخاب دستی) ----------

        /** آخرین پیامک‌های صندوق؛ q = عبارت جستجو در فرستنده/متن */
        @JavascriptInterface
        fun inboxMsgs(q: String, limit: Int): String {
            val out = org.json.JSONArray()
            if (!has(Manifest.permission.READ_SMS)) return out.toString()
            val qq = q.trim().lowercase()
            try {
                contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), null, null, "date DESC")?.use { cur ->
                    var scanned = 0
                    while (cur.moveToNext() && out.length() < limit && scanned < 30000) {
                        scanned++
                        val raw = cur.getString(0) ?: ""
                        val body = cur.getString(1) ?: ""
                        if (qq.isNotEmpty() && !raw.lowercase().contains(qq) && !body.lowercase().contains(qq)) continue
                        val key = Sender.norm(raw)
                        val p = try { SmsParser.parse(key, body) } catch (e: Exception) { null }
                        val kn = db.getSender(key)
                        out.put(JSONObject().put("addr", raw).put("key", key).put("body", body).put("ts", cur.getLong(2))
                            .put("ok", p != null).put("bank", p?.bank ?: kn?.first ?: "").put("kind", p?.kind ?: "")
                            .put("amount", p?.amount ?: 0L).put("state", if (kn == null) "new" else if (kn.second == 0) "blocked" else "ok"))
                    }
                }
            } catch (e: Exception) { }
            return out.toString()
        }

        /** ثبت دستی یک پیامک: {addr, body, ts, bank, kind, amount(تومان)} */
        @JavascriptInterface
        fun addFromSms(json: String): String {
            return try {
                val o = JSONObject(json)
                val key = Sender.norm(o.getString("addr"))
                val body = o.getString("body")
                val p = try { SmsParser.parse(key, body) } catch (e: Exception) { null }
                val kind = o.optString("kind").ifBlank { p?.kind ?: "" }
                val amount = if (o.optLong("amount") > 0) o.getLong("amount") else (p?.amount ?: 0L)
                if (kind.isBlank() || amount <= 0) return "need"
                val bank = o.optString("bank").ifBlank { p?.bank ?: "" }.ifBlank { "بانک نامشخص" }
                db.upsertSender(key, bank.takeIf { it != "بانک نامشخص" }, 1)
                val id = db.insertSms(p?.ts ?: o.optLong("ts", System.currentTimeMillis()), bank, p?.acct, key, kind, amount, p?.balance, body, 1)
                Prefs.bumpUi(this@MainActivity)
                if (id > 0) "ok" else "dup"
            } catch (e: Exception) { "err" }
        }

        /** اصلاح دستی موجودی بانک */
        @JavascriptInterface
        fun setBankBalance(bank: String, acct: String, toman: Long) {
            db.setBalance(bank, acct, toman)
            Prefs.bumpUi(this@MainActivity)
        }

        /** همه‌ی پیامک‌های یک فرستنده به یک بانک نسبت داده بشه */
        @JavascriptInterface
        fun assignSenderBank(addr: String, bank: String) {
            val key = Sender.norm(addr)
            db.upsertSender(key, bank, 1)
            db.setBankForSender(key, bank)
            Prefs.bumpUi(this@MainActivity)
        }

        @JavascriptInterface
        fun alreadyImported(): Boolean = Prefs.imported(this@MainActivity)

        /** برای تست دستی: یه پیامک ساختگی از بانک رو پردازش می‌کنه */
        @JavascriptInterface
        fun simulateSms(body: String): String {
            // فقط تشخیص رو نشون می‌ده؛ هیچ تراکنشی ثبت نمی‌شه
            return if (SmsParser.parse("TEST", body) != null) "OK" else "NO"
        }

        // ---------- فاکتور ----------

        @JavascriptInterface
        fun invoiceStatus(): String = JSONObject()
            .put("font", Invoice.hasFont(this@MainActivity)).put("stamp", Invoice.hasStamp(this@MainActivity)).toString()

        @JavascriptInterface
        fun deleteStamp() { try { java.io.File(filesDir, "stamp.png").delete() } catch (e: Exception) { } }

        @JavascriptInterface
        fun invoiceCfg(): String = Prefs.invoiceCfg(this@MainActivity)

        @JavascriptInterface
        fun setInvoiceCfg(json: String) = Prefs.setInvoiceCfg(this@MainActivity, json)

        @JavascriptInterface
        fun pickFile(kind: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = if (kind == "stamp") "image/*" else "*/*"
                try {
                    startActivityForResult(i, if (kind == "stamp") REQ_STAMP else REQ_FONT)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun makeInvoice(json: String): String {
            val d = JSONObject(json)
            val r = Invoice.make(this@MainActivity, d)
            if (r.optBoolean("ok")) {
                try {
                    var sum = 0L
                    val items = d.optJSONArray("items")
                    if (items != null) for (i in 0 until items.length()) sum += items.getJSONObject(i).optLong("amount")
                    val fin = maxOf(0L, sum - d.optLong("discount"))
                    val h = org.json.JSONArray(Prefs.invHist(this@MainActivity))
                    val e = JSONObject().put("ts", System.currentTimeMillis()).put("date", d.optString("date"))
                        .put("name", d.optString("name")).put("total", fin).put("unit", d.optString("unit"))
                        .put("png", r.optString("png")).put("pdf", r.optString("pdf"))
                    val n = org.json.JSONArray()
                    n.put(e)
                    for (i in 0 until minOf(h.length(), 299)) n.put(h.get(i))
                    Prefs.setInvHist(this@MainActivity, n.toString())
                    Prefs.bumpUi(this@MainActivity)
                } catch (e: Exception) {
                }
            }
            return r.toString()
        }

        /** خروجی PDF و Word آمار یک ماه شمسی */
        @JavascriptInterface
        fun exportReport(y: Int, m: Int): String = Report.make(this@MainActivity, y, m).toString()

        @JavascriptInterface
        fun invHist(): String = Prefs.invHist(this@MainActivity)

        @JavascriptInterface
        fun delInvHist(ts: String) {
            val h = org.json.JSONArray(Prefs.invHist(this@MainActivity))
            val n = org.json.JSONArray()
            for (i in 0 until h.length()) if (h.getJSONObject(i).optLong("ts").toString() != ts) n.put(h.get(i))
            Prefs.setInvHist(this@MainActivity, n.toString())
        }

        // ---------- بازی و نرخ‌ها ----------

        @JavascriptInterface
        fun trend(jy: Int, jm: Int, n: Int): String {
            val l = ArrayList<JSONObject>()
            var y = jy; var mo = jm
            for (i in 0 until n) {
                val ny = if (mo == 12) y + 1 else y
                val nm = if (mo == 12) 1 else mo + 1
                val s = db.summary(Jalali.monthStart(y, mo), Jalali.monthStart(ny, nm))
                l.add(JSONObject().put("y", y).put("m", mo).put("in", s.getLong("in")).put("out", s.getLong("out")))
                mo--; if (mo == 0) { mo = 12; y-- }
            }
            val a = org.json.JSONArray()
            for (o in l.reversed()) a.put(o)
            return a.toString()
        }

        @JavascriptInterface
        fun gstate(): String = Prefs.gstate(this@MainActivity)

        @JavascriptInterface
        fun setGstate(j: String) = Prefs.setGstate(this@MainActivity, j)

        @JavascriptInterface
        fun ratesHist(): String = Prefs.ratesHist(this@MainActivity)

        @JavascriptInterface
        fun copyText(t: String) {
            runOnUiThread {
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("khazane", t))
            }
        }

        @JavascriptInterface
        fun game(): String = Game.stats(this@MainActivity).toString()

        @JavascriptInterface
        fun gameAck(level: Int) = Prefs.setLvlSeen(this@MainActivity, level)

        @JavascriptInterface
        fun rates(): String = Prefs.rates(this@MainActivity)

        @JavascriptInterface
        fun refreshRates() = Rates.refresh(this@MainActivity)

        @JavascriptInterface
        fun ratesBusy(): Boolean = Rates.running

        @JavascriptInterface
        fun openUri(uri: String, mime: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(Uri.parse(uri), mime)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(i)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun shareUri(uri: String, mime: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = mime
                    i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "ارسال فاکتور"))
                } catch (e: Exception) {
                }
            }
        }
    }

    companion object {
        const val REQ_FONT = 11
        const val REQ_STAMP = 12
    }
}
