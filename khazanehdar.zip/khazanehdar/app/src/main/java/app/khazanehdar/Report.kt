package app.khazanehdar

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import org.json.JSONObject
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** گزارش پایان ماه: یک مدل مشترک که هم PDF می‌شه هم Word (docx) */
object Report {
    class Section(val title: String, val rows: List<Pair<String, String>>)
    class Model(val title: String, val sub: String, val sections: List<Section>)

    private fun fa(n: Long) = Notifier.fa(n)

    fun build(ctx: Context, jy: Int, jm: Int): Model {
        val db = Db.get(ctx)
        val from = Jalali.monthStart(jy, jm)
        val ny = if (jm == 12) jy + 1 else jy
        val nm = if (jm == 12) 1 else jm + 1
        val to = Jalali.monthStart(ny, nm)
        val s = db.summary(from, to)
        val inc = s.getLong("in")
        val out = s.getLong("out")
        val net = inc - out
        val secs = ArrayList<Section>()

        val rate = if (inc > 0) Math.round(net * 100.0 / inc) else 0L
        secs.add(
            Section(
                "خلاصه‌ی ماه",
                listOf(
                    "کل درآمد (دخل)" to "${fa(inc)} تومان",
                    "کل هزینه (خرج)" to "${fa(out)} تومان",
                    (if (net >= 0) "پس‌انداز ماه" else "کسری ماه") to "${fa(Math.abs(net))} تومان",
                    "نرخ پس‌انداز" to "٪${fa(rate)}"
                )
            )
        )

        val oc = db.catSums(from, to, "out")
        if (oc.isNotEmpty()) secs.add(Section("هزینه‌ها به تفکیک دسته", oc.map { (c, v) ->
            c to "${fa(v)} تومان (٪${fa(if (out > 0) Math.round(v * 100.0 / out) else 0L)})"
        }))
        val ic = db.catSums(from, to, "in")
        if (ic.isNotEmpty()) secs.add(Section("درآمدها به تفکیک منبع", ic.map { (c, v) ->
            c to "${fa(v)} تومان (٪${fa(if (inc > 0) Math.round(v * 100.0 / inc) else 0L)})"
        }))

        // موجودی بانک‌ها
        val banks = db.bankSummary()
        val brows = ArrayList<Pair<String, String>>()
        var total = 0L
        for (i in 0 until banks.length()) {
            val b = banks.getJSONObject(i)
            if (!b.has("balance")) continue
            val name = b.getString("bank") + (if (b.getString("acct").isNotEmpty()) " (" + fa(b.getString("acct").toLongOrNull() ?: 0L).replace("٬", "") + ")" else "")
            brows.add(name to "${fa(b.getLong("balance"))} تومان")
            total += b.getLong("balance")
        }
        if (brows.isNotEmpty()) {
            brows.add("جمع موجودی همه‌ی بانک‌ها" to "${fa(total)} تومان")
            secs.add(Section("موجودی بانک‌ها (آخرین مانده‌ی ثبت‌شده)", brows))
        }

        // پرخرج‌ترین‌ها
        val txs = db.txRange(from, to)
        val list = ArrayList<JSONObject>()
        for (i in 0 until txs.length()) list.add(txs.getJSONObject(i))
        val top = list.filter { it.getString("kind") == "out" }.sortedByDescending { it.getLong("amount") }.take(5)
        if (top.isNotEmpty()) secs.add(Section("پنج خرج بزرگ ماه", top.map {
            val t = it.optString("reason").ifBlank { it.optString("category").ifBlank { it.optString("bank") } }
            t to "${fa(it.getLong("amount"))} تومان"
        }))
        secs.add(Section("آمار", listOf("تعداد تراکنش‌ها" to fa(list.size.toLong()))))

        // طلب‌ها و اقساط
        val debts = db.debts(true)
        var dsum = 0L
        for (i in 0 until debts.length()) {
            val d = debts.getJSONObject(i)
            dsum += if (d.optLong("mine") > 0) d.getLong("amount") - d.optLong("mine") else d.getLong("amount")
        }
        val insts = db.insts(true)
        var isum = 0L
        for (i in 0 until insts.length()) isum += insts.getJSONObject(i).getLong("amount")
        secs.add(
            Section(
                "طلب‌ها و اقساط",
                listOf(
                    "طلب‌های باز (${fa(debts.length().toLong())} مورد)" to "${fa(dsum)} تومان",
                    "اقساط باقی‌مانده (${fa(insts.length().toLong())} مورد)" to "${fa(isum)} تومان"
                )
            )
        )
        return Model("گزارش مالی ${Jalali.MONTHS[jm - 1]} ${fa(jy.toLong()).replace("٬", "")}", "خزانه‌دار", secs)
    }

    // ---------- PDF ----------
    private fun writePdf(m: Model, os: OutputStream) {
        val W = 595
        val H = 842
        val mg = 40f
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var cv = page.canvas
        var y = 60f
        fun p(size: Float, bold: Boolean, color: Int, al: Paint.Align) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; textAlign = al
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        fun next() {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            cv = page.canvas
            y = 50f
        }
        cv.drawText(m.title, W - mg, y, p(22f, true, Color.parseColor("#14213D"), Paint.Align.RIGHT))
        y += 22f
        cv.drawText(m.sub, W - mg, y, p(12f, false, Color.GRAY, Paint.Align.RIGHT))
        y += 26f
        for (s in m.sections) {
            if (y > H - 110) next()
            val bar = Paint().apply { color = Color.parseColor("#E8EEF9") }
            cv.drawRect(mg, y - 16f, W - mg, y + 8f, bar)
            cv.drawText(s.title, W - mg - 8f, y, p(14f, true, Color.parseColor("#1D4ED8"), Paint.Align.RIGHT))
            y += 28f
            for ((k, v) in s.rows) {
                if (y > H - 50) next()
                cv.drawText(k, W - mg - 8f, y, p(12f, false, Color.BLACK, Paint.Align.RIGHT))
                cv.drawText(v, mg + 8f, y, p(12f, true, Color.parseColor("#111111"), Paint.Align.LEFT))
                val ln = Paint().apply { color = Color.parseColor("#DDDDDD"); strokeWidth = 0.6f }
                cv.drawLine(mg, y + 6f, W - mg, y + 6f, ln)
                y += 22f
            }
            y += 12f
        }
        doc.finishPage(page)
        doc.writeTo(os)
        doc.close()
    }

    // ---------- Word (docx) ----------
    private fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun run(t: String, bold: Boolean = false, sz: Int = 24, color: String? = null) =
        "<w:r><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/>" + (if (bold) "<w:b/><w:bCs/>" else "") +
            (if (color != null) "<w:color w:val=\"$color\"/>" else "") +
            "<w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/><w:rtl/></w:rPr><w:t xml:space=\"preserve\">${x(t)}</w:t></w:r>"

    private fun para(t: String, bold: Boolean = false, sz: Int = 24, color: String? = null) =
        "<w:p><w:pPr><w:bidi/></w:pPr>${run(t, bold, sz, color)}</w:p>"

    private fun cell(t: String, bold: Boolean, w: Int) =
        "<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/></w:tcPr>${para(t, bold, 22)}</w:tc>"

    private fun writeDocx(m: Model, os: OutputStream) {
        val body = StringBuilder()
        body.append(para(m.title, true, 40, "14213D"))
        body.append(para(m.sub, false, 22, "666666"))
        for (s in m.sections) {
            body.append(para(s.title, true, 28, "1D4ED8"))
            body.append("<w:tbl><w:tblPr><w:tblW w:w=\"9000\" w:type=\"dxa\"/><w:bidiVisual/><w:tblBorders>")
            for (e in listOf("top", "left", "bottom", "right", "insideH", "insideV"))
                body.append("<w:$e w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"CCCCCC\"/>")
            body.append("</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w=\"5200\"/><w:gridCol w:w=\"3800\"/></w:tblGrid>")
            for ((k, v) in s.rows) body.append("<w:tr>${cell(k, false, 5200)}${cell(v, true, 3800)}</w:tr>")
            body.append("</w:tbl>")
            body.append("<w:p/>")
        }
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body" +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1000\" w:right=\"1200\" w:bottom=\"1000\" w:left=\"1200\" w:header=\"500\" w:footer=\"500\" w:gutter=\"0\"/><w:bidi/></w:sectPr>" +
            "</w:body></w:document>"
        ZipOutputStream(os).use { z ->
            fun put(n: String, c: String) {
                z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            put(
                "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
            )
            put(
                "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
            )
            put("word/document.xml", doc)
        }
    }

    /** PDF و Word رو می‌سازه و تو Download/Khazanehdar ذخیره می‌کنه */
    fun make(ctx: Context, jy: Int, jm: Int): JSONObject {
        val r = JSONObject()
        try {
            val m = build(ctx, jy, jm)
            val base = "khazanehdar-report-$jy-${if (jm < 10) "0$jm" else "$jm"}"
            val dir = "Download/KhazanehdarSara"
            val pdf = Invoice.save(ctx, "$base.pdf", "application/pdf", false, dir) { writePdf(m, it) }
            val docx = Invoice.save(
                ctx, "$base.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", false, dir
            ) { writeDocx(m, it) }
            r.put("ok", pdf != null && docx != null).put("pdf", pdf?.toString() ?: "").put("docx", docx?.toString() ?: "")
        } catch (e: Exception) {
            r.put("ok", false).put("err", e.toString())
        }
        return r
    }
}
